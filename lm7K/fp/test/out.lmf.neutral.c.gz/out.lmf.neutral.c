rdcmd:  lmfa --no-iactiv c -vzbak=0
 -----------------------  START LMFA (80000K)  -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 rrrrrrrrrrrrrrrrrrrrrrrrcd= @CAT@HEADER  sc C atom @CAT@VERS    LMASA-6 LMF-6 LM:7 FP:7 @CAT@IO      SHOW=F HELP=F VERBOS=30 40 60 60 WKP=F @CAT@TESTLMF lmfa --no-iactiv c -vzbak=0 lmf  --no-iactiv c -vzbak=0 @CAT@TESTION lmfa --no-iactiv c -vzbak=1 lmf  --no-iactiv c -vzbak=1 @CAT@CLEAN   rm -f ctrl.c moms.c atm.c mixm.c rst.c save.c log.c hssn.c wkp.c bsmv.c syml.c bnds.c @CAT@OPTIONS NSPIN=2 REL=t FRZ=0 NRMIX=2 TPAN=0 HF=hf ESP=F XCN=0 LMH=0 XCFUN=2 FORCES=12 PFLOAT=0 @CAT@SYMGRP  find @CAT@ITER    MIX=A2,b=.5 CONV=1e-5 CONVC=.0005 NIT=nit @CAT@MIX     MODE=A2,b=.5 CONV=1e-5 CONVC=.0005 ELIND=-1 NMIX=2 @CAT@HAM     NSPIN=2  REL=t XCFUN=2 FTMESH=50 50 50  TOL=1E-6 FRZ=f FORCES=12 ELIND=-1 CONV=1e-5 CONVC=.0005 @CAT@STRUC   NBAS=1 NSPEC=1 NL=lmxa+1 ALAT=10/2^(1/3) PLAT=   1 1 0  1 0 1  0 1 1 @CAT@FIT     WVS=1 1  NFIT=2 EFIT=-.5 -2 @CAT@BZ      NKABC=nk nk nk  BZJOB=f GETQP=f METAL=2 TETRA=t  SAVDOS=f DOS=ef0-1.5 ef0+0.5 EF0=ef0 DELEF=.2 W=.004 NPTS=200 NEVMX=5 EFMAX=5 ZBAK=zbak @CAT@SITE    ATOM=C POS=  0   0   0 @CAT@SPEC   ATOM=C Z=6 R=3 EREF=-74.9949 A=0.02  LMXA=lmxa RMXA=0.6 P=2.9,2.85,3.18,4.12 IDMOD=0,1 RSMH= 1.3 1.1 -1 -1  EH= -0.7,-0.2,0 0 MMOM=0,2 RSMH2=0.8 0.8 EH2= -1.5,-1 @CAT@CONST   ef0=0 nk=4 rsma=.6 lmxa=3  nit=10 hf=f zbak=0 @CAT@START   NIT=nit @CAT@EOF
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMFA  vn 7.00(LMFA 7.0)  verb 30,40,60
 pot:      spin-pol, XC:BH
 end of rdctrl2 in imfav7
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137
 goto mksym

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 end of mksym x
 goto defspc
 end of defspc
 goto freeat

conf:SPEC_ATOM= C : --- Table for atomic configuration ---
conf int(P)z = int(P) where P is replaced by PZ if it is semicore
conf:  isp  l  int(P) int(P)z    Qval    Qcore   CoreConf
conf:    1  0       2  2        1.000    1.000 => 1,
conf:    1  1       2  2        2.000    0.000 => 
conf:    1  2       3  3        0.000    0.000 => 
conf:    1  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------
conf:    2  0       2  2        1.000    1.000 => 1,
conf:    2  1       2  2        0.000    0.000 => 
conf:    2  2       3  3        0.000    0.000 => 
conf:    2  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
 xxx goto vxc0sp
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30
 xxx goto vxc0sp


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001
 tailsm: init
 tailsm:xxx1
 tailsm:xxx2

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753709   qtot  1.997279
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 tailsm: end
 end of freats: spid=C       

  Write mtopara.* ...
 Exit 0 LMFA 
 wkinfo:  used       82 K  workspace of    80000 K   in     0 K calls
rdcmd:  lmf  --no-iactiv c -vzbak=0
 -----------------------  START LMF (300000K)  -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 rrrrrrrrrrrrrrrrrrrrrrrrcd= @CAT@HEADER  sc C atom @CAT@VERS    LMASA-6 LMF-6 LM:7 FP:7 @CAT@IO      SHOW=F HELP=F VERBOS=30 40 60 60 WKP=F @CAT@TESTLMF lmfa --no-iactiv c -vzbak=0 lmf  --no-iactiv c -vzbak=0 @CAT@TESTION lmfa --no-iactiv c -vzbak=1 lmf  --no-iactiv c -vzbak=1 @CAT@CLEAN   rm -f ctrl.c moms.c atm.c mixm.c rst.c save.c log.c hssn.c wkp.c bsmv.c syml.c bnds.c @CAT@OPTIONS NSPIN=2 REL=t FRZ=0 NRMIX=2 TPAN=0 HF=hf ESP=F XCN=0 LMH=0 XCFUN=2 FORCES=12 PFLOAT=0 @CAT@SYMGRP  find @CAT@ITER    MIX=A2,b=.5 CONV=1e-5 CONVC=.0005 NIT=nit @CAT@MIX     MODE=A2,b=.5 CONV=1e-5 CONVC=.0005 ELIND=-1 NMIX=2 @CAT@HAM     NSPIN=2  REL=t XCFUN=2 FTMESH=50 50 50  TOL=1E-6 FRZ=f FORCES=12 ELIND=-1 CONV=1e-5 CONVC=.0005 @CAT@STRUC   NBAS=1 NSPEC=1 NL=lmxa+1 ALAT=10/2^(1/3) PLAT=   1 1 0  1 0 1  0 1 1 @CAT@FIT     WVS=1 1  NFIT=2 EFIT=-.5 -2 @CAT@BZ      NKABC=nk nk nk  BZJOB=f GETQP=f METAL=2 TETRA=t  SAVDOS=f DOS=ef0-1.5 ef0+0.5 EF0=ef0 DELEF=.2 W=.004 NPTS=200 NEVMX=5 EFMAX=5 ZBAK=zbak @CAT@SITE    ATOM=C POS=  0   0   0 @CAT@SPEC   ATOM=C Z=6 R=3 EREF=-74.9949 A=0.02  LMXA=lmxa RMXA=0.6 P=2.9,2.85,3.18,4.12 IDMOD=0,1 RSMH= 1.3 1.1 -1 -1  EH= -0.7,-0.2,0 0 MMOM=0,2 RSMH2=0.8 0.8 EH2= -1.5,-1 @CAT@CONST   ef0=0 nk=4 rsma=.6 lmxa=3  nit=10 hf=f zbak=0 @CAT@START   NIT=nit @CAT@EOF
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMF  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 
 goto setcg
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 
 lstar xxx=          -2
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F
 lstar xxx=          -2

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 gvlist: cutoff radius  13.994 gives  45911   recips of max 125000
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363587    3.701843    2.363561    1.338282
 amom    1.810990    1.143831    1.810990    1.143831    0.667159

 Smooth charge on mesh:            2.661718    moment    1.332841
 Sum of local charges:             1.338282    moments   0.667159
 Total valence charge:             4.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           0.000000
 Deviation from neutrality:       -0.000000
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 1 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338282     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.063910   charge     2.661718
 smooth rhoeps =   -1.494901 (  -1.109320,  -0.385581)
         rhomu =   -1.946550 (  -1.522780,  -0.423770)
       avg vxc =   -0.191348 (  -0.218128,  -0.164568)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.341410   -3.941483  -14.282893     -2.908176   -0.943828   -3.852003

 local terms:     true           smooth         local
 rhoeps:        -9.536045      -1.428951      -8.107094
 rhomu:         -7.422765      -1.450795      -5.971970
 spin2:         -5.125221      -0.410320      -4.714901
 total:        -12.547986      -1.861115     -10.686870
 val*vef       -14.282893      -6.925497      -7.357396
 val chg:        3.701843       2.363561       1.338282
 val mom:        1.810990       1.143831       0.667159    core:  -0.000000
 core chg:       2.000000       2.000000      -0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.589352    0.102212   -0.581577
 1      3.000000    1.000000    -5.887832    7.119796    0.144160   -0.533282
 2      3.000000    1.000000     4.727244   27.134665    0.465946   -0.095778
 3      3.000000    1.000000     7.577135   37.213691    0.543677   -0.062061

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.437705    0.107908   -0.555887
 1      3.000000    1.000000    -5.887832    7.130043    0.153492   -0.500465
 2      3.000000    1.000000     4.727244   27.482684    0.468116   -0.093876
 3      3.000000    1.000000     7.577135   37.415022    0.544672   -0.061530

 Energy terms:             smooth           local           total
   rhoval*vef             -3.931613       -10.430885       -14.362499
   rhoval*ves             -5.058553        -5.181775       -10.240327
   psnuc*ves               9.186373      -278.836573      -269.650199
   utot                    2.063910      -142.009174      -139.945263
   rho*exc                -1.494901        -8.107094        -9.601995
   rho*vxc                -1.946550       -10.686870       -12.633421
   valence chg             2.661718         1.338282         4.000000
   valence mag             1.332841         0.667159         2.000000
   core charge             2.000000        -0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...
 Start second band pass ...
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4290
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686856    3.838083   -0.151227      1.796589    2.141131   -0.344542
       contr. to mm extrapolated for r>rmt:   0.163680 est. true mm = 1.960270
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85523  sum tc=    31.38701  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78555  sum tc=    31.54499  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.957935   -1.038744    2.900000    2.914621    2.500000    2.914621
 spn 2 0    0.945133   -0.836887    2.900000    2.908183    2.500000    2.908183
 1     1    1.783776   -0.429110    2.850000    2.889411    2.250000    2.850000
 spn 2 1    0.000000   -1.101865    2.850000    2.167565    2.250000    2.850000
 2     0    0.000011   -0.813692    3.180000    3.132790    3.147584    3.147584
 spn 2 0    0.000000   -1.175532    3.180000    3.108512    3.147584    3.147584
 3     0    0.000001   -0.763293    4.120000    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.128828    4.120000    4.085128    4.102416    4.102416

 Harris energy:
 sumev=       -2.743233  val*vef=     -14.362499   sumtv=      11.619265
 sumec=      -39.640777  cor*vef=    -102.572782   ttcor=      62.932005
 rhoeps=      -9.601995     utot=    -139.945263    ehar=     -74.995989

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00   -0.00    0.00    -0.00    0.00   -0.00
 shift forces to make zero average correction:           -0.00    0.00   -0.00

 srhov:     -7.491267     -6.856027    -14.347295 sumev=   -2.743233   sumtv=   11.604061

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.042660   -0.151227     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008341  avg sphere pot= 0.014058  vconst=-0.008341
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.531027   charge     4.151227
 smooth rhoeps =   -3.081515 (  -2.415640,  -0.665875)
         rhomu =   -4.025458 (  -3.336127,  -0.689331)
       avg vxc =   -0.206216 (  -0.237894,  -0.174538)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.331832   -3.946568  -14.278400     -7.320814   -1.729922   -9.050735

 local terms:     true           smooth         local
 rhoeps:        -9.525314      -3.014713      -6.510601
 rhomu:         -7.408850      -3.263013      -4.145837
 spin2:         -5.125107      -0.675917      -4.449191
 total:        -12.533957      -3.938930      -8.595028
 val*vef       -14.278400      -8.607508      -5.670893
 val chg:        3.686856       3.838083      -0.151227
 val mom:        1.796589       2.141131      -0.344542    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.130114        -5.227666       -14.357779
   rhoval*ves             -4.661428        -5.587080       -10.248508
   psnuc*ves              11.723481      -281.355166      -269.631684
   utot                    3.531027      -143.471123      -139.940096
   rho*exc                -3.081515        -6.510601        -9.592116
   rho*vxc                -4.025458        -8.595028       -12.620486
   valence chg             4.151227        -0.151227         4.000000
   valence mag             2.344542        -0.344542         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.604061  sumtc=        62.932006   ekin=       74.536067
 rhoep=       -9.592116   utot=      -139.940096   ehks=      -74.996145
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  249.65990618631614     ,-1.19195650183730476E-026)   249.65990618631614                0
 mixrho: sum smrnew new  = (  405.98552049586101     ,-1.95613748669381007E-017)   405.98552049586101                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=1.35e-2
 mixrho: (warning) scr. and lin-mixed densities had 1625 and 405 negative points
 AMIX: nmix=0 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=6.75e-3
 unscreened rms difference:  smooth  0.010354   local  0.036279
   screened rms difference:  smooth  0.010366   local  0.036279   tot  0.013495
 mixrho: sum smrho output= (  327.82272820895946     ,-9.78068743272649187E-018)   327.82272820895946                0

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=      -0.001089   ehk=      -0.001245
h zbak=0 mmom=1.9999996 ehf=-.0010887 ehk=-.0012453
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 2 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.167431    0.593528     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008356  avg sphere pot= 0.016799  vconst=-0.008356
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.743363   charge     3.406472
 smvxcm (warning) mesh density negative at 37543 points:  rhomin=-5.54e-6
 smooth rhoeps =   -2.247130 (  -1.725336,  -0.521795)
         rhomu =   -2.931571 (  -2.377887,  -0.553684)
       avg vxc =   -0.191396 (  -0.225052,  -0.157740)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336776   -3.945468  -14.282244     -4.949777   -1.314639   -6.264415

 local terms:     true           smooth         local
 rhoeps:        -9.532961      -2.180844      -7.352117
 rhomu:         -7.417504      -2.305475      -5.112029
 spin2:         -5.126437      -0.540186      -4.586251
 total:        -12.543941      -2.845661      -9.698281
 val*vef       -14.282244      -7.814990      -6.467254
 val chg:        3.697600       3.104073       0.593528
 val mom:        1.803790       1.642481       0.161309    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.914621 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.915138    7.418302    0.092820   -0.587641
 1      3.000000    1.000000    -5.887832    7.121418    0.144054   -0.533608
 2      3.000000    1.000000     6.000000   29.630950    0.492412   -0.085937
 3      3.000000    1.000000     9.000000   40.184999    0.569710   -0.056283

 potpus  spin 2 : pnu = 2.908183 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.110306    7.331756    0.102466   -0.559526
 1      3.000000    1.000000    -5.887832    7.130564    0.153438   -0.500623
 2      3.000000    1.000000     6.000000   29.973160    0.494326   -0.084382
 3      3.000000    1.000000     9.000000   40.379853    0.570594   -0.055847

 Energy terms:             smooth           local           total
   rhoval*vef             -6.344148        -8.017826       -14.361975
   rhoval*ves             -4.963150        -5.280235       -10.243385
   psnuc*ves              10.449875      -280.096506      -269.646631
   utot                    2.743363      -142.688371      -139.945008
   rho*exc                -2.247130        -7.352117        -9.599248
   rho*vxc                -2.931571        -9.698281       -12.629851
   valence chg             3.406472         0.593528         4.000000
   valence mag             1.838691         0.161309         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.430662
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0412 -0.4294 -0.4294 -0.4294  0.1305  0.5276  0.5276  0.5276
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8396 -0.2382 -0.2382 -0.2382  0.2119  0.6260  0.6260  0.6260
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4294
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431114;   4.000000 electrons
         Sum occ. bands:   -2.745703, incl. Bloechl correction: -0.000181
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687098    3.837352   -0.150254      1.796463    2.125039   -0.328576
       contr. to mm extrapolated for r>rmt:   0.163703 est. true mm = 1.960166
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85641  sum tc=    31.38705  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78678  sum tc=    31.54486  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958012   -1.039323    2.914621    2.914624    2.500000    2.914624
 spn 2 0    0.945317   -0.837839    2.908183    2.908288    2.500000    2.908288
 1     1    1.783756   -0.429712    2.850000    2.889347    2.250000    2.850000
 spn 2 1    0.000000   -1.074197    2.850000    2.172044    2.250000    2.850000
 2     0    0.000012   -0.813133    3.147584    3.132771    3.147584    3.147584
 spn 2 0    0.000000   -1.179997    3.147584    3.108348    3.147584    3.147584
 3     0    0.000001   -0.762432    4.102416    4.096166    4.102416    4.102416
 spn 2 0    0.000000   -1.130139    4.102416    4.085107    4.102416    4.102416

 Harris energy:
 sumev=       -2.745703  val*vef=     -14.361975   sumtv=      11.616272
 sumec=      -39.643187  cor*vef=    -102.575192   ttcor=      62.932005
 rhoeps=      -9.599248     utot=    -139.945008    ehar=     -74.995978

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00    0.00    0.00     0.00   -0.00   -0.00
 shift forces to make zero average correction:            0.00   -0.00   -0.00

 srhov:     -8.352118     -6.003966    -14.356084 sumev=   -2.745703   sumtv=   11.610381

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.042386   -0.150254     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008311  avg sphere pot= 0.014078  vconst=-0.008311
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.523004   charge     4.150254
 smooth rhoeps =   -3.079167 (  -2.406440,  -0.672727)
         rhomu =   -4.022226 (  -3.323773,  -0.698453)
       avg vxc =   -0.206177 (  -0.237860,  -0.174494)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.334487   -3.948304  -14.282791     -7.290813   -1.756275   -9.047088

 local terms:     true           smooth         local
 rhoeps:        -9.526260      -3.012437      -6.513823
 rhomu:         -7.409670      -3.250705      -4.158965
 spin2:         -5.125534      -0.685087      -4.440447
 total:        -12.535203      -3.935792      -8.599412
 val*vef       -14.282791      -8.607208      -5.675583
 val chg:        3.687098       3.837352      -0.150254
 val mom:        1.796463       2.125039      -0.328576    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.126380        -5.235703       -14.362083
   rhoval*ves             -4.664274        -5.587488       -10.251762
   psnuc*ves              11.710283      -281.349396      -269.639113
   utot                    3.523004      -143.468442      -139.945438
   rho*exc                -3.079167        -6.513823        -9.592990
   rho*vxc                -4.022226        -8.599412       -12.621638
   valence chg             4.150254        -0.150254         4.000000
   valence mag             2.328576        -0.328576         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.610381  sumtc=        62.931909   ekin=       74.542290
 rhoep=       -9.592990   utot=      -139.945438   ehks=      -74.996137
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  327.82272820895935     ,-9.78068743811857803E-018)   327.82272820895935                0
 mixrho: sum smrnew new  = (  404.92684146749724     ,-3.95269595747012294E-018)   404.92684146749724                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=6.68e-3  last it=1.35e-2
 mixrho: (warning) scr. and lin-mixed densities had 767 and 611 negative points
 AMIX: nmix=1 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=3.34e-3
   tj:-0.97958
 unscreened rms difference:  smooth  0.005189   local  0.017940
   screened rms difference:  smooth  0.005197   local  0.017940   tot  0.006681
 mixrho: sum smrho output= (  404.13964521019767     ,-4.01219851913814389E-018)   404.13964521019767                0

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=      -0.001078   ehk=      -0.001237
 From last iter    ehf=      -0.001089   ehk=      -0.001245
 diffe(q)=  0.000010 (0.006681)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0010784 ehk=-.0012368
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 3 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.040244   -0.142660     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.009580  avg sphere pot= 0.014106  vconst=-0.009580
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.512169   charge     4.142660
 smvxcm (warning) mesh density negative at 43201 points:  rhomin=-9.17e-6
 smooth rhoeps =   -3.073343 (  -2.400813,  -0.672530)
         rhomu =   -4.014649 (  -3.315911,  -0.698738)
       avg vxc =   -0.196505 (  -0.232583,  -0.160428)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.334729   -3.950260  -14.284989     -7.264869   -1.753163   -9.018032

 local terms:     true           smooth         local
 rhoeps:        -9.529501      -3.006704      -6.522798
 rhomu:         -7.412108      -3.242987      -4.169121
 spin2:         -5.127314      -0.685252      -4.442062
 total:        -12.539422      -3.928238      -8.611183
 val*vef       -14.284989      -8.601089      -5.683900
 val chg:        3.691758       3.834418      -0.142660
 val mom:        1.796538       2.120112      -0.323574    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000004

 potpus  spin 1 : pnu = 2.914624 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.915539    7.422444    0.092756   -0.587896
 1      3.000000    1.000000    -5.887832    7.123612    0.143940   -0.533940
 2      3.000000    1.000000     6.000000   29.623161    0.492356   -0.085975
 3      3.000000    1.000000     9.000000   40.179239    0.569679   -0.056297

 potpus  spin 2 : pnu = 2.908288 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.122534    7.332771    0.102355   -0.559707
 1      3.000000    1.000000    -5.887832    7.131787    0.153370   -0.500795
 2      3.000000    1.000000     6.000000   29.968299    0.494291   -0.084405
 3      3.000000    1.000000     9.000000   40.376179    0.570573   -0.055856

 Energy terms:             smooth           local           total
   rhoval*vef             -9.097743        -5.266958       -14.364701
   rhoval*ves             -4.666152        -5.584076       -10.250228
   psnuc*ves              11.690491      -281.337562      -269.647071
   utot                    3.512169      -143.460819      -139.948650
   rho*exc                -3.073343        -6.522798        -9.596141
   rho*vxc                -4.014649        -8.611183       -12.625832
   valence chg             4.142660        -0.142660         4.000000
   valence mag             2.323574        -0.323574         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.431114
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0417 -0.4297 -0.4297 -0.4297  0.1295  0.5272  0.5272  0.5272
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8405 -0.2389 -0.2389 -0.2389  0.2124  0.6264  0.6264  0.6264
 Est Ef = -0.431 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4297
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431468;   4.000000 electrons
         Sum occ. bands:   -2.747832, incl. Bloechl correction: -0.000184
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687332    3.841340   -0.154008      1.796391    2.115312   -0.318921
       contr. to mm extrapolated for r>rmt:   0.163651 est. true mm = 1.960042
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85702  sum tc=    31.38682  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78739  sum tc=    31.54451  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958114   -1.039806    2.914624    2.914668    2.500000    2.914668
 spn 2 0    0.945470   -0.838720    2.908288    2.908375    2.500000    2.908375
 1     1    1.783735   -0.430247    2.850000    2.889281    2.250000    2.850000
 spn 2 1    0.000000   -1.072409    2.850000    2.172389    2.250000    2.850000
 2     0    0.000012   -0.811998    3.147584    3.132774    3.147584    3.147584
 spn 2 0    0.000000   -1.180240    3.147584    3.108338    3.147584    3.147584
 3     0    0.000001   -0.761039    4.102416    4.096169    4.102416    4.102416
 spn 2 0    0.000000   -1.130238    4.102416    4.085103    4.102416    4.102416

 Harris energy:
 sumev=       -2.747832  val*vef=     -14.364701   sumtv=      11.616869
 sumec=      -39.644412  cor*vef=    -102.576369   ttcor=      62.931957
 rhoeps=      -9.596141     utot=    -139.948650    ehar=     -74.995965

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00   -0.00   -0.00    -0.00    0.00    0.00
 shift forces to make zero average correction:           -0.00    0.00    0.00

 srhov:     -9.136221     -5.227408    -14.363628 sumev=   -2.747832   sumtv=   11.615796

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043445   -0.154008     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008285  avg sphere pot= 0.014093  vconst=-0.008285
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.516866   charge     4.154008
 smooth rhoeps =   -3.083529 (  -2.404304,  -0.679226)
         rhomu =   -4.027838 (  -3.321121,  -0.706718)
       avg vxc =   -0.206163 (  -0.237849,  -0.174477)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336834   -3.949621  -14.286455     -7.285271   -1.780057   -9.065328

 local terms:     true           smooth         local
 rhoeps:        -9.527095      -3.016874      -6.510220
 rhomu:         -7.410434      -3.248107      -4.162327
 spin2:         -5.125867      -0.693393      -4.432474
 total:        -12.536302      -3.941500      -8.594801
 val*vef       -14.286455      -8.614855      -5.671600
 val chg:        3.687332       3.841340      -0.154008
 val mom:        1.796391       2.115312      -0.318921    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.144530        -5.221128       -14.365658
   rhoval*ves             -4.666219        -5.588164       -10.254383
   psnuc*ves              11.699952      -281.344575      -269.644623
   utot                    3.516866      -143.466369      -139.949503
   rho*exc                -3.083529        -6.510220        -9.593750
   rho*vxc                -4.027838        -8.594801       -12.622640
   valence chg             4.154008        -0.154008         4.000000
   valence mag             2.318921        -0.318921         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.615796  sumtc=        62.931331   ekin=       74.547127
 rhoep=       -9.593750   utot=      -139.949503   ehks=      -74.996126
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  404.13964521019767     ,-4.01219854024271225E-018)   404.13964521019767                0
 mixrho: sum smrnew new  = (  404.55806695482300     ,-1.15710534625625754E-017)   404.55806695482300                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=1.20e-4  last it=6.68e-3
 mixrho: (warning) scr. and lin-mixed densities had 0 and 177 negative points
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=6.01e-5
   tj:-1.27791   0.62413
 unscreened rms difference:  smooth  0.000120   local  0.000266
   screened rms difference:  smooth  0.000121   local  0.000266   tot  0.000120
 mixrho: sum smrho output= (  405.11406389013308     ,-1.02150332152394785E-017)   405.11406389013308                0

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=      -0.001065   ehk=      -0.001226
 From last iter    ehf=      -0.001078   ehk=      -0.001237
 diffe(q)=  0.000014 (0.000120)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0010647 ehk=-.0012256
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 4 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044601   -0.158106     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.009023  avg sphere pot= 0.014073  vconst=-0.009023
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.521949   charge     4.158106
 smvxcm (warning) mesh density negative at 31975 points:  rhomin=-6.89e-6
 smooth rhoeps =   -3.090030 (  -2.410153,  -0.679877)
         rhomu =   -4.036404 (  -3.329159,  -0.707245)
       avg vxc =   -0.199977 (  -0.235238,  -0.164716)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336543   -3.950504  -14.287047     -7.301891   -1.779836   -9.081727

 local terms:     true           smooth         local
 rhoeps:        -9.528670      -3.023375      -6.505295
 rhomu:         -7.411560      -3.256184      -4.155376
 spin2:         -5.126790      -0.693842      -4.432948
 total:        -12.538350      -3.950026      -8.588324
 val*vef       -14.287047      -8.619030      -5.668017
 val chg:        3.689760       3.847865      -0.158106
 val mom:        1.796357       2.120076      -0.323720    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914668 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.921389    7.422920    0.092714   -0.587963
 1      3.000000    1.000000    -5.887832    7.124247    0.143917   -0.534001
 2      3.000000    1.000000     6.000000   29.621221    0.492343   -0.085984
 3      3.000000    1.000000     9.000000   40.177822    0.569671   -0.056300

 potpus  spin 2 : pnu = 2.908375 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.132644    7.332748    0.102279   -0.559798
 1      3.000000    1.000000    -5.887832    7.132446    0.153342   -0.500862
 2      3.000000    1.000000     6.000000   29.966002    0.494275   -0.084416
 3      3.000000    1.000000     9.000000   40.374451    0.570564   -0.055860

 Energy terms:             smooth           local           total
   rhoval*vef             -9.161210        -5.205320       -14.366530
   rhoval*ves             -4.662109        -5.591088       -10.253197
   psnuc*ves              11.706007      -281.354294      -269.648287
   utot                    3.521949      -143.472691      -139.950742
   rho*exc                -3.090030        -6.505295        -9.595325
   rho*vxc                -4.036404        -8.588324       -12.624728
   valence chg             4.158106        -0.158106         4.000000
   valence mag             2.323719        -0.323720         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.431468
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0418 -0.4298 -0.4298 -0.4298  0.1293  0.5273  0.5273  0.5273
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8405 -0.2389 -0.2389 -0.2389  0.2111  0.6260  0.6260  0.6260
 Est Ef = -0.431 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4298
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431533;   4.000000 electrons
         Sum occ. bands:   -2.748162, incl. Bloechl correction: -0.000185
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687306    3.841254   -0.153948      1.796331    2.114852   -0.318520
       contr. to mm extrapolated for r>rmt:   0.163654 est. true mm = 1.959986
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85690  sum tc=    31.38667  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78725  sum tc=    31.54438  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958146   -1.039915    2.914668    2.914687    2.500000    2.914687
 spn 2 0    0.945487   -0.838794    2.908375    2.908376    2.500000    2.908376
 1     1    1.783660   -0.430386    2.850000    2.889254    2.250000    2.850000
 spn 2 1    0.000000   -1.086676    2.850000    2.170035    2.250000    2.850000
 2     0    0.000012   -0.811746    3.147584    3.132775    3.147584    3.147584
 spn 2 0    0.000000   -1.179676    3.147584    3.108345    3.147584    3.147584
 3     0    0.000001   -0.760726    4.102416    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.130165    4.102416    4.085096    4.102416    4.102416

 Harris energy:
 sumev=       -2.748162  val*vef=     -14.366530   sumtv=      11.618368
 sumec=      -39.644144  cor*vef=    -102.575788   ttcor=      62.931644
 rhoeps=      -9.595325     utot=    -139.950742    ehar=     -74.996055

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00   -0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.150323     -5.214244    -14.364567 sumev=   -2.748162   sumtv=   11.616405

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043428   -0.153948     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008267  avg sphere pot= 0.014101  vconst=-0.008267
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.514380   charge     4.153948
 smooth rhoeps =   -3.083807 (  -2.404360,  -0.679447)
         rhomu =   -4.028204 (  -3.321212,  -0.706991)
       avg vxc =   -0.206178 (  -0.237869,  -0.174487)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337005   -3.949878  -14.286883     -7.285779   -1.780734   -9.066514

 local terms:     true           smooth         local
 rhoeps:        -9.527145      -3.017153      -6.509993
 rhomu:         -7.410453      -3.248194      -4.162259
 spin2:         -5.125915      -0.693672      -4.432243
 total:        -12.536368      -3.941866      -8.594502
 val*vef       -14.286883      -8.616364      -5.670519
 val chg:        3.687306       3.841254      -0.153948
 val mom:        1.796331       2.114852      -0.318520    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.145712        -5.220370       -14.366082
   rhoval*ves             -4.667359        -5.587370       -10.254729
   psnuc*ves              11.696120      -281.340946      -269.644826
   utot                    3.514380      -143.464158      -139.949777
   rho*exc                -3.083807        -6.509993        -9.593800
   rho*vxc                -4.028204        -8.594502       -12.622705
   valence chg             4.153948        -0.153948         4.000000
   valence mag             2.318520        -0.318520         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.616405  sumtc=        62.931049   ekin=       74.547454
 rhoep=       -9.593800   utot=      -139.949777   ehks=      -74.996123
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  405.11406389013320     ,-1.02150332146906039E-017)   405.11406389013320                0
 mixrho: sum smrnew new  = (  404.52921699823571     ,-3.76533570818095363E-017)   404.52921699823571                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=4.77e-5  last it=1.20e-4
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=2.38e-5
   tj:-0.30540   0.01065
 unscreened rms difference:  smooth  0.000031   local  0.000146
   screened rms difference:  smooth  0.000027   local  0.000146   tot  0.000048
 mixrho: sum smrho output= (  404.55646871656461     ,-2.86822599993815005E-017)   404.55646871656461                0

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=      -0.001155   ehk=      -0.001223
 From last iter    ehf=      -0.001065   ehk=      -0.001226
 diffe(q)= -0.000090 (0.000048)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0011549 ehk=-.0012228
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 5 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043542   -0.154353     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008695  avg sphere pot= 0.014098  vconst=-0.008695
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.514656   charge     4.154353
 smvxcm (warning) mesh density negative at 21263 points:  rhomin=-4.85e-6
 smooth rhoeps =   -3.085130 (  -2.405070,  -0.680060)
         rhomu =   -4.029940 (  -3.322177,  -0.707763)
       avg vxc =   -0.202142 (  -0.236393,  -0.167892)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337092   -3.950444  -14.287537     -7.286199   -1.781886   -9.068085

 local terms:     true           smooth         local
 rhoeps:        -9.528144      -3.018473      -6.509671
 rhomu:         -7.411204      -3.249182      -4.162021
 spin2:         -5.126465      -0.694402      -4.432063
 total:        -12.537668      -3.943584      -8.594085
 val*vef       -14.287537      -8.616775      -5.670762
 val chg:        3.688744       3.843097      -0.154353
 val mom:        1.796348       2.114898      -0.318551    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914687 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.923947    7.423233    0.092693   -0.588006
 1      3.000000    1.000000    -5.887832    7.124533    0.143901   -0.534046
 2      3.000000    1.000000     6.000000   29.620181    0.492336   -0.085989
 3      3.000000    1.000000     9.000000   40.177081    0.569667   -0.056302

 potpus  spin 2 : pnu = 2.908376 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.132829    7.333369    0.102267   -0.559841
 1      3.000000    1.000000    -5.887832    7.132720    0.153323   -0.500916
 2      3.000000    1.000000     6.000000   29.964701    0.494266   -0.084422
 3      3.000000    1.000000     9.000000   40.373500    0.570559   -0.055862

 Energy terms:             smooth           local           total
   rhoval*vef             -9.147444        -5.219453       -14.366897
   rhoval*ves             -4.666195        -5.588064       -10.254259
   psnuc*ves              11.695507      -281.343224      -269.647717
   utot                    3.514656      -143.465644      -139.950988
   rho*exc                -3.085130        -6.509671        -9.594801
   rho*vxc                -4.029940        -8.594085       -12.624025
   valence chg             4.154353        -0.154353         4.000000
   valence mag             2.318551        -0.318551         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.431533
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0419 -0.4299 -0.4299 -0.4299  0.1292  0.5274  0.5274  0.5274
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8406 -0.2389 -0.2389 -0.2389  0.2102  0.6257  0.6257  0.6257
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4299
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431621;   4.000000 electrons
         Sum occ. bands:   -2.748547, incl. Bloechl correction: -0.000185
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687373    3.842458   -0.155086      1.796374    2.115757   -0.319383
       contr. to mm extrapolated for r>rmt:   0.163601 est. true mm = 1.959976
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85702  sum tc=    31.38664  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78736  sum tc=    31.54436  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958168   -1.040029    2.914687    2.914700    2.500000    2.914700
 spn 2 0    0.945499   -0.838887    2.908376    2.908377    2.500000    2.908377
 1     1    1.783693   -0.430503    2.850000    2.889254    2.250000    2.850000
 spn 2 1    0.000000   -1.095684    2.850000    2.168600    2.250000    2.850000
 2     0    0.000012   -0.811661    3.147584    3.132775    3.147584    3.147584
 spn 2 0    0.000000   -1.179350    3.147584    3.108351    3.147584    3.147584
 3     0    0.000001   -0.760622    4.102416    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.130203    4.102416    4.085091    4.102416    4.102416

 Harris energy:
 sumev=       -2.748547  val*vef=     -14.366897   sumtv=      11.618350
 sumec=      -39.644381  cor*vef=    -102.575728   ttcor=      62.931347
 rhoeps=      -9.594801     utot=    -139.950988    ehar=     -74.996092

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00   -0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.150707     -5.215260    -14.365967 sumev=   -2.748547   sumtv=   11.617420

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043749   -0.155086     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008267  avg sphere pot= 0.014102  vconst=-0.008267
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.513913   charge     4.155085
 smooth rhoeps =   -3.085537 (  -2.405825,  -0.679711)
         rhomu =   -4.030476 (  -3.323252,  -0.707224)
       avg vxc =   -0.206175 (  -0.237864,  -0.174486)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337497   -3.950056  -14.287553     -7.290689   -1.781398   -9.072087

 local terms:     true           smooth         local
 rhoeps:        -9.527326      -3.018902      -6.508424
 rhomu:         -7.410644      -3.250256      -4.160388
 spin2:         -5.125962      -0.693909      -4.432053
 total:        -12.536606      -3.944164      -8.592441
 val*vef       -14.287553      -8.618648      -5.668905
 val chg:        3.687373       3.842458      -0.155086
 val mom:        1.796374       2.115757      -0.319383    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.151262        -5.215466       -14.366729
   rhoval*ves             -4.667348        -5.587829       -10.255177
   psnuc*ves              11.695174      -281.341162      -269.645988
   utot                    3.513913      -143.464496      -139.950582
   rho*exc                -3.085537        -6.508424        -9.593961
   rho*vxc                -4.030476        -8.592441       -12.622917
   valence chg             4.155085        -0.155086         4.000000
   valence mag             2.319383        -0.319383         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.617420  sumtc=        62.931002   ekin=       74.548422
 rhoep=       -9.593961   utot=      -139.950582   ehks=      -74.996121
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  404.55646871656467     ,-2.86822600079903642E-017)   404.55646871656467                0
 mixrho: sum smrnew new  = (  404.65425953690652     ,-2.06229766391019899E-019)   404.65425953690652                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.91e-5  last it=4.77e-5
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=9.54e-6
   tj: 0.18832  -0.06252
 unscreened rms difference:  smooth  0.000016   local  0.000035
   screened rms difference:  smooth  0.000016   local  0.000035   tot  0.000019
 mixrho: sum smrho output= (  404.66214027804176     ,-1.66472989546765958E-017)   404.66214027804176                0

 iors  : write restart file (binary, mesh density) 

   it  5  of 10    ehf=      -0.001192   ehk=      -0.001221
 From last iter    ehf=      -0.001155   ehk=      -0.001223
 diffe(q)= -0.000037 (0.000019)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0011923 ehk=-.001221
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 6 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043828   -0.155365     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008587  avg sphere pot= 0.014097  vconst=-0.008587
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.514826   charge     4.155365
 smvxcm (warning) mesh density negative at 16055 points:  rhomin=-3.86e-6
 smooth rhoeps =   -3.086300 (  -2.406099,  -0.680201)
         rhomu =   -4.031473 (  -3.323617,  -0.707857)
       avg vxc =   -0.203044 (  -0.236797,  -0.169291)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337310   -3.950407  -14.287718     -7.290261   -1.782449   -9.072710

 local terms:     true           smooth         local
 rhoeps:        -9.527969      -3.019649      -6.508320
 rhomu:         -7.411093      -3.250622      -4.160472
 spin2:         -5.126348      -0.694509      -4.431838
 total:        -12.537441      -3.945131      -8.592310
 val*vef       -14.287718      -8.618426      -5.669292
 val chg:        3.688397       3.843762      -0.155365
 val mom:        1.796351       2.115581      -0.319230    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914700 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.925664    7.423267    0.092681   -0.588023
 1      3.000000    1.000000    -5.887832    7.124640    0.143896   -0.534061
 2      3.000000    1.000000     6.000000   29.619815    0.492334   -0.085991
 3      3.000000    1.000000     9.000000   40.176815    0.569666   -0.056303

 potpus  spin 2 : pnu = 2.908377 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.132970    7.333568    0.102262   -0.559855
 1      3.000000    1.000000    -5.887832    7.132818    0.153316   -0.500933
 2      3.000000    1.000000     6.000000   29.964268    0.494263   -0.084424
 3      3.000000    1.000000     9.000000   40.373178    0.570558   -0.055863

 Energy terms:             smooth           local           total
   rhoval*vef             -9.152020        -5.215008       -14.367028
   rhoval*ves             -4.666263        -5.588361       -10.254624
   psnuc*ves              11.695916      -281.343347      -269.647431
   utot                    3.514826      -143.465854      -139.951028
   rho*exc                -3.086300        -6.508320        -9.594620
   rho*vxc                -4.031473        -8.592310       -12.623783
   valence chg             4.155365        -0.155365         4.000000
   valence mag             2.319229        -0.319230         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.431621
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0420 -0.4299 -0.4299 -0.4299  0.1292  0.5274  0.5274  0.5274
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8407 -0.2390 -0.2390 -0.2390  0.2098  0.6256  0.6256  0.6256
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4299
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431646;   4.000000 electrons
         Sum occ. bands:   -2.748658, incl. Bloechl correction: -0.000185
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687399    3.842961   -0.155562      1.796394    2.116176   -0.319783
       contr. to mm extrapolated for r>rmt:   0.163580 est. true mm = 1.959973
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85706  sum tc=    31.38663  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78739  sum tc=    31.54436  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958175   -1.040063    2.914700    2.914704    2.500000    2.914704
 spn 2 0    0.945502   -0.838914    2.908377    2.908377    2.500000    2.908377
 1     1    1.783708   -0.430537    2.850000    2.889255    2.250000    2.850000
 spn 2 1    0.000000   -1.099148    2.850000    2.168058    2.250000    2.850000
 2     0    0.000012   -0.811628    3.147584    3.132775    3.147584    3.147584
 spn 2 0    0.000000   -1.179225    3.147584    3.108353    3.147584    3.147584
 3     0    0.000001   -0.760583    4.102416    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.130233    4.102416    4.085089    4.102416    4.102416

 Harris energy:
 sumev=       -2.748658  val*vef=     -14.367028   sumtv=      11.618371
 sumec=      -39.644448  cor*vef=    -102.575622   ttcor=      62.931174
 rhoeps=      -9.594620     utot=    -139.951028    ehar=     -74.996103

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00    0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.153517     -5.212906    -14.366423 sumev=   -2.748658   sumtv=   11.617765

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043883   -0.155562     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008268  avg sphere pot= 0.014102  vconst=-0.008268
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.513834   charge     4.155562
 smooth rhoeps =   -3.086245 (  -2.406445,  -0.679800)
         rhomu =   -4.031407 (  -3.324114,  -0.707293)
       avg vxc =   -0.206174 (  -0.237862,  -0.174486)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337672   -3.950104  -14.287777     -7.292765   -1.781597   -9.074362

 local terms:     true           smooth         local
 rhoeps:        -9.527391      -3.019618      -6.507773
 rhomu:         -7.410715      -3.251126      -4.159589
 spin2:         -5.125976      -0.693980      -4.431997
 total:        -12.536691      -3.945105      -8.591585
 val*vef       -14.287777      -8.619538      -5.668238
 val chg:        3.687399       3.842961      -0.155562
 val mom:        1.796394       2.116176      -0.319783    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.153529        -5.213415       -14.366944
   rhoval*ves             -4.667298        -5.588023       -10.255321
   psnuc*ves              11.694965      -281.341362      -269.646397
   utot                    3.513834      -143.464693      -139.950859
   rho*exc                -3.086245        -6.507773        -9.594018
   rho*vxc                -4.031407        -8.591585       -12.622993
   valence chg             4.155562        -0.155562         4.000000
   valence mag             2.319782        -0.319783         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.617765  sumtc=        62.930991   ekin=       74.548757
 rhoep=       -9.594018   utot=      -139.950859   ehks=      -74.996120
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  404.66214027804176     ,-1.66472989426098342E-017)   404.66214027804176                0
 mixrho: sum smrnew new  = (  404.70900250567030     , 2.11507715809739781E-017)   404.70900250567030                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.29e-5  last it=1.91e-5
 AMIX: condition of normal eqns >100000. Reducing nmix to 1
 AMIX: nmix=1 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=6.47e-6
   tj:-1.74003
 unscreened rms difference:  smooth  0.000011   local  0.000024
   screened rms difference:  smooth  0.000010   local  0.000024   tot  0.000013
 mixrho: sum smrho output= (  404.82514478163586     , 3.13032245522417337E-017)   404.82514478163586                0

 iors  : write restart file (binary, mesh density) 

   it  6  of 10    ehf=      -0.001203   ehk=      -0.001220
 From last iter    ehf=      -0.001192   ehk=      -0.001221
 diffe(q)= -0.000010 (0.000013)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0012027 ehk=-.0012204
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 7 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044221   -0.156758     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008363  avg sphere pot= 0.014099  vconst=-0.008363
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.514365   charge     4.156758
 smvxcm (warning) mesh density negative at 5903 points:  rhomin=-1.57e-6
 smooth rhoeps =   -3.087970 (  -2.407742,  -0.680228)
         rhomu =   -4.033669 (  -3.325914,  -0.707755)
       avg vxc =   -0.205063 (  -0.237547,  -0.172580)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337838   -3.950303  -14.288140     -7.296845   -1.782718   -9.079563

 local terms:     true           smooth         local
 rhoeps:        -9.527653      -3.021340      -6.506313
 rhomu:         -7.410921      -3.252930      -4.157991
 spin2:         -5.126113      -0.694432      -4.431680
 total:        -12.537033      -3.947362      -8.589671
 val*vef       -14.288140      -8.621221      -5.666919
 val chg:        3.687710       3.844468      -0.156758
 val mom:        1.796393       2.116837      -0.320444    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914704 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.926289    7.423592    0.092673   -0.588045
 1      3.000000    1.000000    -5.887832    7.124862    0.143887   -0.534087
 2      3.000000    1.000000     6.000000   29.619093    0.492329   -0.085995
 3      3.000000    1.000000     9.000000   40.176283    0.569663   -0.056304

 potpus  spin 2 : pnu = 2.908377 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.132976    7.333993    0.102255   -0.559879
 1      3.000000    1.000000    -5.887832    7.133028    0.153304   -0.500964
 2      3.000000    1.000000     6.000000   29.963415    0.494257   -0.084428
 3      3.000000    1.000000     9.000000   40.372538    0.570554   -0.055864

 Energy terms:             smooth           local           total
   rhoval*vef             -9.158765        -5.208578       -14.367343
   rhoval*ves             -4.666755        -5.588632       -10.255387
   psnuc*ves              11.695486      -281.342953      -269.647467
   utot                    3.514365      -143.465793      -139.951427
   rho*exc                -3.087970        -6.506313        -9.594283
   rho*vxc                -4.033669        -8.589671       -12.623340
   valence chg             4.156758        -0.156758         4.000000
   valence mag             2.320444        -0.320444         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.431646
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0420 -0.4299 -0.4299 -0.4299  0.1292  0.5275  0.5275  0.5275
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8407 -0.2390 -0.2390 -0.2390  0.2090  0.6254  0.6254  0.6254
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4299
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431685;   4.000000 electrons
         Sum occ. bands:   -2.748832, incl. Bloechl correction: -0.000186
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687456    3.844162   -0.156706      1.796439    2.117165   -0.320726
       contr. to mm extrapolated for r>rmt:   0.163531 est. true mm = 1.959971
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85708  sum tc=    31.38660  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78741  sum tc=    31.54434  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958191   -1.040121    2.914704    2.914714    2.500000    2.914714
 spn 2 0    0.945508   -0.838953    2.908377    2.908377    2.500000    2.908377
 1     1    1.783745   -0.430593    2.850000    2.889258    2.250000    2.850000
 spn 2 1    0.000000   -1.106106    2.850000    2.166981    2.250000    2.850000
 2     0    0.000012   -0.811560    3.147584    3.132775    3.147584    3.147584
 spn 2 0    0.000000   -1.178963    3.147584    3.108358    3.147584    3.147584
 3     0    0.000001   -0.760498    4.102416    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.130306    4.102416    4.085084    4.102416    4.102416

 Harris energy:
 sumev=       -2.748832  val*vef=     -14.367343   sumtv=      11.618511
 sumec=      -39.644494  cor*vef=    -102.575577   ttcor=      62.931083
 rhoeps=      -9.594283     utot=    -139.951427    ehar=     -74.996116

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00    0.00    0.00     0.00   -0.00   -0.00
 shift forces to make zero average correction:            0.00   -0.00   -0.00

 srhov:     -9.159019     -5.208237    -14.367256 sumev=   -2.748832   sumtv=   11.618425

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044206   -0.156706     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008271  avg sphere pot= 0.014101  vconst=-0.008271
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.513882   charge     4.156706
 smooth rhoeps =   -3.087896 (  -2.407886,  -0.680010)
         rhomu =   -4.033577 (  -3.326116,  -0.707461)
       avg vxc =   -0.206171 (  -0.237856,  -0.174486)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.338017   -3.950180  -14.288196     -7.297588   -1.782091   -9.079679

 local terms:     true           smooth         local
 rhoeps:        -9.527520      -3.021285      -6.506235
 rhomu:         -7.410860      -3.253147      -4.157713
 spin2:         -5.126001      -0.694149      -4.431851
 total:        -12.536861      -3.947296      -8.589565
 val*vef       -14.288196      -8.621515      -5.666682
 val chg:        3.687456       3.844162      -0.156706
 val mom:        1.796439       2.117165      -0.320726    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.158827        -5.208518       -14.367345
   rhoval*ves             -4.667087        -5.588493       -10.255579
   psnuc*ves              11.694850      -281.341964      -269.647114
   utot                    3.513882      -143.465228      -139.951347
   rho*exc                -3.087896        -6.506235        -9.594131
   rho*vxc                -4.033577        -8.589565       -12.623142
   valence chg             4.156706        -0.156706         4.000000
   valence mag             2.320726        -0.320726         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.618425  sumtc=        62.930934   ekin=       74.549358
 rhoep=       -9.594131   utot=      -139.951347   ehks=      -74.996119
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  404.82514478163586     , 3.13032245386409582E-017)   404.82514478163586                0
 mixrho: sum smrnew new  = (  404.83946325695734     , 3.66371749216320240E-017)   404.83946325695734                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=4.34e-6  last it=1.29e-5
 AMIX: condition of normal eqns >100000. Reducing nmix to 1
 AMIX: nmix=1 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=2.17e-6
   tj:-0.43203
 unscreened rms difference:  smooth  0.000003   local  0.000009
   screened rms difference:  smooth  0.000003   local  0.000009   tot  0.000004
 mixrho: sum smrho output= (  404.89570734495800     , 4.76735303114998220E-017)   404.89570734495800                0

 iors  : write restart file (binary, mesh density) 

   it  7  of 10    ehf=      -0.001216   ehk=      -0.001219
 From last iter    ehf=      -0.001203   ehk=      -0.001220
 diffe(q)= -0.000013 (0.000004)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0012161 ehk=-.0012192
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 8 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044368   -0.157280     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008268  avg sphere pot= 0.014100  vconst=-0.008268
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.514042   charge     4.157280
 smvxcm (warning) mesh density negative at 1403 points:  rhomin=-3.62e-7
 smooth rhoeps =   -3.088644 (  -2.408476,  -0.680168)
         rhomu =   -4.034558 (  -3.326939,  -0.707619)
       avg vxc =   -0.206004 (  -0.237841,  -0.174167)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.338114   -3.950228  -14.288343     -7.299682   -1.782565   -9.082247

 local terms:     true           smooth         local
 rhoeps:        -9.527539      -3.022029      -6.505509
 rhomu:         -7.410879      -3.253967      -4.156912
 spin2:         -5.126007      -0.694306      -4.431701
 total:        -12.536886      -3.948273      -8.588613
 val*vef       -14.288343      -8.622395      -5.665947
 val chg:        3.687435       3.844715      -0.157280
 val mom:        1.796435       2.117486      -0.321051    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914714 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.927556    7.423628    0.092665   -0.588056
 1      3.000000    1.000000    -5.887832    7.124959    0.143883   -0.534096
 2      3.000000    1.000000     6.000000   29.618803    0.492327   -0.085996
 3      3.000000    1.000000     9.000000   40.176066    0.569662   -0.056304

 potpus  spin 2 : pnu = 2.908377 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.132984    7.334162    0.102253   -0.559887
 1      3.000000    1.000000    -5.887832    7.133122    0.153300   -0.500974
 2      3.000000    1.000000     6.000000   29.963078    0.494255   -0.084430
 3      3.000000    1.000000     9.000000   40.372280    0.570553   -0.055865

 Energy terms:             smooth           local           total
   rhoval*vef             -9.161397        -5.206096       -14.367494
   rhoval*ves             -4.666988        -5.588719       -10.255707
   psnuc*ves              11.695072      -281.342561      -269.647489
   utot                    3.514042      -143.465640      -139.951598
   rho*exc                -3.088644        -6.505509        -9.594153
   rho*vxc                -4.034558        -8.588613       -12.623172
   valence chg             4.157280        -0.157280         4.000000
   valence mag             2.321051        -0.321051         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.431685
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0420 -0.4299 -0.4299 -0.4299  0.1292  0.5276  0.5276  0.5276
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8407 -0.2390 -0.2390 -0.2390  0.2087  0.6253  0.6253  0.6253
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4299
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431693;   4.000000 electrons
         Sum occ. bands:   -2.748869, incl. Bloechl correction: -0.000186
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687482    3.844774   -0.157292      1.796459    2.117595   -0.321135
       contr. to mm extrapolated for r>rmt:   0.163511 est. true mm = 1.959971
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85708  sum tc=    31.38658  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78740  sum tc=    31.54433  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958197   -1.040138    2.914714    2.914718    2.500000    2.914718
 spn 2 0    0.945511   -0.838958    2.908377    2.908378    2.500000    2.908378
 1     1    1.783762   -0.430608    2.850000    2.889261    2.250000    2.850000
 spn 2 1    0.000000   -1.108724    2.850000    2.166579    2.250000    2.850000
 2     0    0.000012   -0.811529    3.147584    3.132774    3.147584    3.147584
 spn 2 0    0.000000   -1.178863    3.147584    3.108360    3.147584    3.147584
 3     0    0.000001   -0.760462    4.102416    4.096169    4.102416    4.102416
 spn 2 0    0.000000   -1.130334    4.102416    4.085082    4.102416    4.102416

 Harris energy:
 sumev=       -2.748869  val*vef=     -14.367494   sumtv=      11.618624
 sumec=      -39.644479  cor*vef=    -102.575487   ttcor=      62.931008
 rhoeps=      -9.594153     utot=    -139.951598    ehar=     -74.996119

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00    0.00    0.00     0.00   -0.00    0.00
 shift forces to make zero average correction:            0.00   -0.00    0.00

 srhov:     -9.161525     -5.206017    -14.367542 sumev=   -2.748869   sumtv=   11.618673

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044371   -0.157292     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008272  avg sphere pot= 0.014100  vconst=-0.008272
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.514010   charge     4.157292
 smooth rhoeps =   -3.088705 (  -2.408559,  -0.680146)
         rhomu =   -4.034640 (  -3.327054,  -0.707586)
       avg vxc =   -0.206170 (  -0.237854,  -0.174486)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.338146   -3.950204  -14.288350     -7.299859   -1.782466   -9.082325

 local terms:     true           smooth         local
 rhoeps:        -9.527572      -3.022102      -6.505470
 rhomu:         -7.410919      -3.254093      -4.156826
 spin2:         -5.126010      -0.694276      -4.431734
 total:        -12.536929      -3.948368      -8.588561
 val*vef       -14.288350      -8.622443      -5.665907
 val chg:        3.687482       3.844774      -0.157292
 val mom:        1.796459       2.117595      -0.321135    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.161465        -5.206025       -14.367491
   rhoval*ves             -4.666944        -5.588724       -10.255668
   psnuc*ves              11.694964      -281.342348      -269.647385
   utot                    3.514010      -143.465536      -139.951526
   rho*exc                -3.088705        -6.505470        -9.594176
   rho*vxc                -4.034640        -8.588561       -12.623201
   valence chg             4.157292        -0.157292         4.000000
   valence mag             2.321135        -0.321135         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.618673  sumtc=        62.930910   ekin=       74.549583
 rhoep=       -9.594176   utot=      -139.951526   ehks=      -74.996119
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  404.89570734495805     , 4.76735303067514217E-017)   404.89570734495805                0
 mixrho: sum smrnew new  = (  404.90166897622288     , 5.67688312142826061E-018)   404.90166897622288                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=9.32e-7  last it=4.34e-6
 AMIX: condition of normal eqns >100000. Reducing nmix to 1
 AMIX: nmix=1 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=4.66e-7
   tj:-0.08442
 unscreened rms difference:  smooth  0.000001   local  0.000002
   screened rms difference:  smooth  0.000000   local  0.000002   tot  0.000001
 mixrho: sum smrho output= (  404.90430257798999     , 2.60593781356563640E-017)   404.90430257798999                0

 iors  : write restart file (binary, mesh density) 

   it  8  of 10    ehf=      -0.001219   ehk=      -0.001219
 From last iter    ehf=      -0.001216   ehk=      -0.001219
 diffe(q)= -0.000002 (0.000001)    tol= 0.000010 (0.000500)   more=F
c zbak=0 mmom=1.9999997 ehf=-.0012186 ehk=-.0012188
 Exit 0 LMF 
 wkinfo:  used    10994 K  workspace of   300000 K   in     3 K calls
