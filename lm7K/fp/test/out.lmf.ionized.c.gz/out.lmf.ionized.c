rdcmd:  lmfa --no-iactiv c -vzbak=1
 -----------------------  START LMFA (80000K)  -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 rrrrrrrrrrrrrrrrrrrrrrrrcd= @CAT@HEADER  sc C atom @CAT@VERS    LMASA-6 LMF-6 LM:7 FP:7 @CAT@IO      SHOW=F HELP=F VERBOS=30 40 60 60 WKP=F @CAT@TESTLMF lmfa --no-iactiv c -vzbak=0 lmf  --no-iactiv c -vzbak=0 @CAT@TESTION lmfa --no-iactiv c -vzbak=1 lmf  --no-iactiv c -vzbak=1 @CAT@CLEAN   rm -f ctrl.c moms.c atm.c mixm.c rst.c save.c log.c hssn.c wkp.c bsmv.c syml.c bnds.c @CAT@OPTIONS NSPIN=2 REL=t FRZ=0 NRMIX=2 TPAN=0 HF=hf ESP=F XCN=0 LMH=0 XCFUN=2 FORCES=12 PFLOAT=0 @CAT@SYMGRP  find @CAT@ITER    MIX=A2,b=.5 CONV=1e-5 CONVC=.0005 NIT=nit @CAT@MIX     MODE=A2,b=.5 CONV=1e-5 CONVC=.0005 ELIND=-1 NMIX=2 @CAT@HAM     NSPIN=2  REL=t XCFUN=2 FTMESH=50 50 50  TOL=1E-6 FRZ=f FORCES=12 ELIND=-1 CONV=1e-5 CONVC=.0005 @CAT@STRUC   NBAS=1 NSPEC=1 NL=lmxa+1 ALAT=10/2^(1/3) PLAT=   1 1 0  1 0 1  0 1 1 @CAT@FIT     WVS=1 1  NFIT=2 EFIT=-.5 -2 @CAT@BZ      NKABC=nk nk nk  BZJOB=f GETQP=f METAL=2 TETRA=t  SAVDOS=f DOS=ef0-1.5 ef0+0.5 EF0=ef0 DELEF=.2 W=.004 NPTS=200 NEVMX=5 EFMAX=5 ZBAK=zbak @CAT@SITE    ATOM=C POS=  0   0   0 @CAT@SPEC   ATOM=C Z=6 R=3 EREF=-74.9949 A=0.02  LMXA=lmxa RMXA=0.6 P=2.9,2.85,3.18,4.12 IDMOD=0,1 RSMH= 1.3 1.1 -1 -1  EH= -0.7,-0.2,0 0 MMOM=0,2 RSMH2=0.8 0.8 EH2= -1.5,-1 @CAT@CONST   ef0=0 nk=4 rsma=.6 lmxa=3  nit=10 hf=f zbak=0 @CAT@START   NIT=nit @CAT@EOF
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMFA  vn 7.00(LMFA 7.0)  verb 30,40,60
 pot:      spin-pol, XC:BH
 end of rdctrl2 in imfav7
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137
 goto mksym

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 end of mksym x
 goto defspc
 end of defspc
 goto freeat

conf:SPEC_ATOM= C : --- Table for atomic configuration ---
conf int(P)z = int(P) where P is replaced by PZ if it is semicore
conf:  isp  l  int(P) int(P)z    Qval    Qcore   CoreConf
conf:    1  0       2  2        1.000    1.000 => 1,
conf:    1  1       2  2        2.000    0.000 => 
conf:    1  2       3  3        0.000    0.000 => 
conf:    1  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------
conf:    2  0       2  2        1.000    1.000 => 1,
conf:    2  1       2  2        0.000    0.000 => 
conf:    2  2       3  3        0.000    0.000 => 
conf:    2  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
 xxx goto vxc0sp
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
 xxx goto vxc0sp
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30
 xxx goto vxc0sp


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001
 tailsm: init
 tailsm:xxx1
 tailsm:xxx2

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753709   qtot  1.997279
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 tailsm: end
 end of freats: spid=C       

  Write mtopara.* ...
 Exit 0 LMFA 
 wkinfo:  used       82 K  workspace of    80000 K   in     0 K calls
rdcmd:  lmf  --no-iactiv c -vzbak=1
 -----------------------  START LMF (300000K)  -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 rrrrrrrrrrrrrrrrrrrrrrrrcd= @CAT@HEADER  sc C atom @CAT@VERS    LMASA-6 LMF-6 LM:7 FP:7 @CAT@IO      SHOW=F HELP=F VERBOS=30 40 60 60 WKP=F @CAT@TESTLMF lmfa --no-iactiv c -vzbak=0 lmf  --no-iactiv c -vzbak=0 @CAT@TESTION lmfa --no-iactiv c -vzbak=1 lmf  --no-iactiv c -vzbak=1 @CAT@CLEAN   rm -f ctrl.c moms.c atm.c mixm.c rst.c save.c log.c hssn.c wkp.c bsmv.c syml.c bnds.c @CAT@OPTIONS NSPIN=2 REL=t FRZ=0 NRMIX=2 TPAN=0 HF=hf ESP=F XCN=0 LMH=0 XCFUN=2 FORCES=12 PFLOAT=0 @CAT@SYMGRP  find @CAT@ITER    MIX=A2,b=.5 CONV=1e-5 CONVC=.0005 NIT=nit @CAT@MIX     MODE=A2,b=.5 CONV=1e-5 CONVC=.0005 ELIND=-1 NMIX=2 @CAT@HAM     NSPIN=2  REL=t XCFUN=2 FTMESH=50 50 50  TOL=1E-6 FRZ=f FORCES=12 ELIND=-1 CONV=1e-5 CONVC=.0005 @CAT@STRUC   NBAS=1 NSPEC=1 NL=lmxa+1 ALAT=10/2^(1/3) PLAT=   1 1 0  1 0 1  0 1 1 @CAT@FIT     WVS=1 1  NFIT=2 EFIT=-.5 -2 @CAT@BZ      NKABC=nk nk nk  BZJOB=f GETQP=f METAL=2 TETRA=t  SAVDOS=f DOS=ef0-1.5 ef0+0.5 EF0=ef0 DELEF=.2 W=.004 NPTS=200 NEVMX=5 EFMAX=5 ZBAK=zbak @CAT@SITE    ATOM=C POS=  0   0   0 @CAT@SPEC   ATOM=C Z=6 R=3 EREF=-74.9949 A=0.02  LMXA=lmxa RMXA=0.6 P=2.9,2.85,3.18,4.12 IDMOD=0,1 RSMH= 1.3 1.1 -1 -1  EH= -0.7,-0.2,0 0 MMOM=0,2 RSMH2=0.8 0.8 EH2= -1.5,-1 @CAT@CONST   ef0=0 nk=4 rsma=.6 lmxa=3  nit=10 hf=f zbak=0 @CAT@START   NIT=nit @CAT@EOF
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMF  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 
 goto setcg
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 
 lstar xxx=          -2
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F
 lstar xxx=          -2

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 gvlist: cutoff radius  13.994 gives  45911   recips of max 125000
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363587    3.701843    2.363561    1.338282
 amom    1.810990    1.143831    1.810990    1.143831    0.667159
 Uniform density added to neutralize background, q=1.000000

 Smooth charge on mesh:            1.661718    moment    1.332841
 Sum of local charges:             1.338282    moments   0.667159
 Total valence charge:             3.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           1.000000
 Deviation from neutrality:       -0.000000
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 1 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338282     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      2.063910   charge     2.661718
 smvxcm (warning) mesh density negative at 201254 points:  rhomin=-5e-4
 smooth rhoeps =   -1.385796 (  -1.043174,  -0.342622)
         rhomu =   -1.806539 (  -1.431678,  -0.374861)
       avg vxc =   -0.082065 (  -0.095983,  -0.068146)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       128
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.261804   -3.876233  -14.138038     -2.842621   -0.891813   -3.734435

 local terms:     true           smooth         local
 rhoeps:        -9.464952      -1.364263      -8.100688
 rhomu:         -7.369404      -1.402026      -5.967378
 spin2:         -5.086143      -0.375091      -4.711052
 total:        -12.455547      -1.777117     -10.678430
 val*vef       -14.138038      -6.807929      -7.330109
 val chg:        3.588746       2.250464       1.338282
 val mom:        1.810990       1.143831       0.667159    core:  -0.000000
 core chg:       2.000000       2.000000      -0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.622125    0.101666   -0.583560
 1      3.000000    1.000000    -5.887832    7.139035    0.143256   -0.535856
 2      3.000000    1.000000     4.727244   27.072458    0.465408   -0.096156
 3      3.000000    1.000000     7.577135   37.163437    0.543349   -0.062204

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.498210    0.106861   -0.559304
 1      3.000000    1.000000    -5.887832    7.161455    0.151762   -0.504954
 2      3.000000    1.000000     4.727244   27.365015    0.467061   -0.094577
 3      3.000000    1.000000     7.577135   37.316588    0.544000   -0.061810

 Energy terms:             smooth           local           total
   rhoval*vef             -3.784995       -10.403599       -14.188594
   rhoval*ves             -5.058553        -5.181775       -10.240327
   psnuc*ves               9.186373      -278.836573      -269.650199
   utot                    2.063910      -142.009174      -139.945263
   rho*exc                -1.385796        -8.100688        -9.486484
   rho*vxc                -1.806539       -10.678430       -12.484969
   valence chg             1.661718         1.338282         3.000000
   valence mag             1.332841         0.667159         2.000000
   core charge             2.000000        -0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0318 -0.4143 -0.4143 -0.4143  0.2634  0.6583  0.6583  0.6583
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8236 -0.2132 -0.2132 -0.2132  0.3259  0.7397  0.7397  0.7397
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.415970;   3.000000 electrons
         Sum occ. bands:   -2.271237, incl. Bloechl correction: -0.000057
         Mag. moment:       1.000000

 Saved qp weights ...
 Start second band pass ...
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0318 -0.4143 -0.4143 -0.4143  0.2634  0.6583  0.6583  0.6583
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8236 -0.2132 -0.2132 -0.2132  0.3259  0.7397  0.7397  0.7397
 Est Ef = -0.416 < evl(3)=-0.414 ... using qval=3.0, revise to -0.4143
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.415970;   3.000000 electrons
         Sum occ. bands:   -2.271237, incl. Bloechl correction: -0.000057
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.831916    4.874552   -2.042636      0.924612    1.907970   -0.983357
       contr. to mm extrapolated for r>rmt:   0.058538 est. true mm = 0.983151
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85491  sum tc=    31.38764  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78517  sum tc=    31.54593  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.963385   -1.028882    2.900000    2.919100    2.500000    2.919100
 spn 2 0    0.953652   -0.821345    2.900000    2.914124    2.500000    2.914124
 1     1    0.914877   -0.410818    2.850000    2.900121    2.250000    2.850000
 spn 2 1    0.000000   -0.978105    2.850000    2.184937    2.250000    2.850000
 2     0    0.000002   -0.817015    3.180000    3.131388    3.147584    3.147584
 spn 2 0    0.000000   -1.162024    3.180000    3.107693    3.147584    3.147584
 3     0    0.000000   -0.783442    4.120000    4.095082    4.102416    4.102416
 spn 2 0    0.000000   -1.113934    4.120000    4.084684    4.102416    4.102416

 Harris energy:
 sumev=       -2.271237  val*vef=     -14.188594   sumtv=      11.917358
 sumec=      -39.640082  cor*vef=    -102.572087   ttcor=      62.932005
 rhoeps=      -9.486484     utot=    -139.945263    ehar=     -74.582385

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00   -0.00    -0.00    0.00   -0.00     0.00   -0.00    0.00
 shift forces to make zero average correction:            0.00   -0.00    0.00

 srhov:    -11.239199     -0.362424    -11.601622 sumev=   -2.271237   sumtv=    9.330386

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.576217   -2.042636     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.115542  avg sphere pot= 0.011444  vconst= 0.115542
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.970593   charge     6.042635
 smooth rhoeps =   -4.637055 (  -3.231622,  -1.405433)
         rhomu =   -6.063111 (  -4.470142,  -1.592969)
       avg vxc =   -0.180429 (  -0.200501,  -0.160356)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.170058   -4.411161  -12.581219    -12.679251   -5.190450  -17.869701

 local terms:     true           smooth         local
 rhoeps:        -8.634165      -4.606299      -4.027866
 rhomu:         -6.241551      -4.440757      -1.800794
 spin2:         -5.123932      -1.582535      -3.541397
 total:        -11.365483      -6.023292      -5.342191
 val*vef       -12.581219      -9.873371      -2.707848
 val chg:        2.831916       4.874552      -2.042636
 val mom:        0.924612       1.907970      -0.983357    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -17.892603         5.288468       -12.604135
   rhoval*ves             -3.717635        -5.854124        -9.571759
   psnuc*ves              15.658820      -282.083829      -266.425009
   utot                    5.970593      -143.968977      -137.998384
   rho*exc                -4.637055        -4.027866        -8.664921
   rho*vxc                -6.063111        -5.342191       -11.405302
   valence chg             5.042635        -2.042636         3.000000
   valence mag             1.983357        -0.983357         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=        9.330386  sumtc=        62.933572   ekin=       72.263958
 rhoep=       -8.664921   utot=      -137.998384   ehks=      -74.399347
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  187.15990618631650     , 1.11757184885562098E-026)   262.83352871097014            93611
 mixrho: sum smrnew new  = (  439.12452661897828     ,-1.20790536825580343E-016)   439.12452661897828                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=3.03e-2
 mixrho: (warning) scr. and lin-mixed densities had 81221 and 91739 negative poi
 AMIX: nmix=0 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=1.51e-2
 unscreened rms difference:  smooth  0.024268   local  0.078359
   screened rms difference:  smooth  0.024805   local  0.078359   tot  0.030253
 mixrho: sum smrho output= (  313.14222938088693     ,-6.03952684098432705E-017)   373.52419150099217            87497

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=       0.412515   ehk=       0.595553
h zbak=1 mmom=.9999997 ehf=.4125146 ehk=.5955527
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 2 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.099347   -0.352177     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.014890  avg sphere pot= 0.015492  vconst= 0.014890
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      3.632830   charge     4.352177
 smvxcm (warning) mesh density negative at 184710 points:  rhomin=-5.16e-4
 smooth rhoeps =   -2.984289 (  -2.104261,  -0.880027)
         rhomu =   -3.895837 (  -2.901650,  -0.994187)
       avg vxc =   -0.104547 (  -0.116508,  -0.092586)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.322965   -4.225495  -13.548460     -7.028892   -2.760722   -9.789614

 local terms:     true           smooth         local
 rhoeps:        -9.150184      -2.947457      -6.202727
 rhomu:         -6.872281      -2.863021      -4.009260
 spin2:         -5.168896      -0.984878      -4.184018
 total:        -12.041177      -3.847899      -8.193278
 val*vef       -13.548460      -8.719262      -4.829198
 val chg:        3.365684       3.717861      -0.352177
 val mom:        1.367801       1.525900      -0.158099    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.919100 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -11.548561    7.576327    0.084501   -0.618779
 1      3.000000    1.000000    -5.887832    7.147665    0.133798   -0.573354
 2      3.000000    1.000000     6.000000   29.266836    0.490316   -0.087655
 3      3.000000    1.000000     9.000000   39.975127    0.568742   -0.056761

 potpus  spin 2 : pnu = 2.914124 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.848787    7.465994    0.091788   -0.594849
 1      3.000000    1.000000    -5.887832    7.105617    0.141349   -0.544479
 2      3.000000    1.000000     6.000000   29.557886    0.491946   -0.086285
 3      3.000000    1.000000     9.000000   40.137030    0.569467   -0.056394

 Energy terms:             smooth           local           total
   rhoval*vef             -9.872390        -3.758847       -13.631237
   rhoval*ves             -4.891312        -5.147591       -10.038903
   psnuc*ves              12.156972      -280.500951      -268.343979
   utot                    3.632830      -142.824271      -139.191441
   rho*exc                -2.984289        -6.202727        -9.187016
   rho*vxc                -3.895837        -8.193278       -12.089116
   valence chg             3.352177        -0.352177         3.000000
   valence mag             1.658099        -0.158099         1.500000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.41597
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1539 -0.5351 -0.5351 -0.5351  0.2375  0.6146  0.6146  0.6146
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.9884 -0.3731 -0.3731 -0.3731  0.2850  0.6760  0.6760  0.6760
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.535712;   3.000000 electrons
         Sum occ. bands:   -2.677860, incl. Bloechl correction: -0.000037
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.871442    5.682248   -2.810806      0.945164    1.927069   -0.981905
       contr. to mm extrapolated for r>rmt:   0.044430 est. true mm = 0.989594
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.16288  sum tc=    31.43930  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.10851  sum tc=    31.56522  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.969792   -1.151455    2.919100    2.921811    2.500000    2.921811
 spn 2 0    0.963139   -0.985832    2.914124    2.918176    2.500000    2.918176
 1     1    0.938509   -0.529486    2.850000    2.907426    2.250000    2.850000
 spn 2 1    0.000000   -0.378790    2.850000    2.891129    2.250000    2.850000
 2     0    0.000001   -0.857342    3.147584    3.130184    3.147584    3.147584
 spn 2 0    0.000000   -1.251074    3.147584    3.106605    3.147584    3.147584
 3     0    0.000000   -0.830711    4.102416    4.094254    4.102416    4.102416
 spn 2 0    0.000000   -1.189193    4.102416    4.084335    4.102416    4.102416

 Harris energy:
 sumev=       -2.677860  val*vef=     -13.631237   sumtv=      10.953376
 sumec=      -40.271398  cor*vef=    -103.204148   ttcor=      62.932750
 rhoeps=      -9.187016     utot=    -139.191441    ehar=     -74.492331

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00    0.00     0.00    0.00    0.00    -0.00   -0.00   -0.00
 shift forces to make zero average correction:           -0.00   -0.00   -0.00

 srhov:    -18.007828      5.247341    -12.760486 sumev=   -2.677860   sumtv=   10.082626

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.792914   -2.810806     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.113461  avg sphere pot= 0.011068  vconst= 0.113461
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.854662   charge     6.810806
 smooth rhoeps =   -5.915150 (  -3.931396,  -1.983753)
         rhomu =   -7.739218 (  -5.421071,  -2.318147)
       avg vxc =   -0.168945 (  -0.186752,  -0.151138)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.576443   -4.618797  -13.195241    -15.008121   -7.354381  -22.362502

 local terms:     true           smooth         local
 rhoeps:        -8.749537      -5.892673      -2.856864
 rhomu:         -6.351092      -5.399857      -0.951236
 spin2:         -5.166251      -2.310259      -2.855992
 total:        -11.517343      -7.710115      -3.807228
 val*vef       -13.195241     -11.534761      -1.660480
 val chg:        2.871442       5.682248      -2.810806
 val mom:        0.945164       1.927069      -0.981905    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -22.379778         9.167240       -13.212538
   rhoval*ves             -3.699379        -6.360460       -10.059839
   psnuc*ves              15.408703      -282.846380      -267.437677
   utot                    5.854662      -144.603420      -138.748758
   rho*exc                -5.915150        -2.856864        -8.772014
   rho*vxc                -7.739218        -3.807228       -11.546446
   valence chg             5.810806        -2.810806         3.000000
   valence mag             1.981905        -0.981905         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.082626  sumtc=        63.004518   ekin=       73.087144
 rhoep=       -8.772014   utot=      -138.748758   ehks=      -74.433628
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  313.14222938088739     ,-6.03952684004889086E-017)   373.52419150099195            87497
 mixrho: sum smrnew new  = (  487.04443660259437     , 1.79983743469448334E-017)   487.04443660259437                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=2.30e-2  last it=3.03e-2
 mixrho: (warning) scr. and lin-mixed densities had 79169 and 86729 negative poi
 AMIX: nmix=1 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=1.15e-2
   tj:-1.96334
 unscreened rms difference:  smooth  0.021245   local  0.055280
   screened rms difference:  smooth  0.021518   local  0.055280   tot  0.022982
 mixrho: sum smrho output= (  570.80797177766567     , 5.57582545485479561E-017)   591.77178872672528            67299

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=       0.502569   ehk=       0.561272
 From last iter    ehf=       0.412515   ehk=       0.595553
 diffe(q)=  0.090055 (0.022982)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5025692 ehk=.5612724
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 3 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.126984   -3.995055     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.082406  avg sphere pot= 0.008939  vconst= 0.082406
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      6.802613   charge     7.995055
 smvxcm (warning) mesh density negative at 135582 points:  rhomin=-4.03e-4
 smooth rhoeps =   -7.779609 (  -5.063118,  -2.716490)
         rhomu =  -10.184462 (  -6.974620,  -3.209842)
       avg vxc =   -0.148861 (  -0.154299,  -0.143424)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.288723   -4.973849  -13.262572    -19.470321  -10.093415  -29.563736

 local terms:     true           smooth         local
 rhoeps:        -8.754613      -7.727492      -1.027121
 rhomu:         -6.242595      -6.938413       0.695818
 spin2:         -5.280402      -3.178617      -2.101786
 total:        -11.522998     -10.117030      -1.405968
 val*vef       -13.262572     -13.082777      -0.179795
 val chg:        2.925781       6.920836      -3.995055
 val mom:        0.741592       2.120300      -1.378708    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.921811 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -11.966458    7.862545    0.076944   -0.655419
 1      3.000000    1.000000    -5.887832    7.285036    0.122169   -0.621380
 2      3.000000    1.000000     6.000000   28.766151    0.487408   -0.090117
 3      3.000000    1.000000     9.000000   39.686471    0.567443   -0.057426

 potpus  spin 2 : pnu = 2.918176 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -11.412268    7.739431    0.082176   -0.635390
 1      3.000000    1.000000    -5.887832    7.206548    0.128061   -0.596345
 2      3.000000    1.000000     6.000000   29.015674    0.488857   -0.088876
 3      3.000000    1.000000     9.000000   39.825847    0.568083   -0.057102

 Energy terms:             smooth           local           total
   rhoval*vef            -29.643893        16.301131       -13.342763
   rhoval*ves             -2.896100        -7.276542       -10.172641
   psnuc*ves              16.501325      -283.910797      -267.409471
   utot                    6.802613      -145.593669      -138.791056
   rho*exc                -7.779609        -1.027121        -8.806730
   rho*vxc               -10.184462        -1.405968       -11.590430
   valence chg             6.995055        -3.995055         3.000000
   valence mag             2.137873        -1.378708         0.759165
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.535712
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2926 -0.6731 -0.6731 -0.6731  0.2427  0.5962  0.5962  0.5962
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1896 -0.5700 -0.5700 -0.5700  0.2549  0.6144  0.6144  0.6144
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.673234;   3.000000 electrons
         Sum occ. bands:   -3.155366, incl. Bloechl correction: -0.000014
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.908869    6.671364   -3.762495      0.962686    1.869071   -0.906385
       contr. to mm extrapolated for r>rmt:   0.032150 est. true mm = 0.994836
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.45972  sum tc=    31.46443  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.42281  sum tc=    31.55206  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976938   -1.290827    2.921811    2.925706    2.500000    2.925706
 spn 2 0    0.973091   -1.187691    2.918176    2.923291    2.500000    2.923291
 1     1    0.958839   -0.668049    2.850000    2.914776    2.250000    2.850000
 spn 2 1    0.000000   -0.557789    2.850000    2.916559    2.250000    2.850000
 2     0    0.000000   -0.889352    3.147584    3.127961    3.147584    3.147584
 spn 2 0    0.000000   -1.340931    3.147584    3.104838    3.147584    3.147584
 3     0    0.000000   -0.865635    4.102416    4.093010    4.102416    4.102416
 spn 2 0    0.000000   -0.865635    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -3.155366  val*vef=     -13.342763   sumtv=      10.187397
 sumec=      -40.882531  cor*vef=    -103.851133   ttcor=      62.968602
 rhoeps=      -8.806730     utot=    -138.791056    ehar=     -74.441788

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00    0.00     0.00   -0.00    0.00    -0.00    0.00   -0.00
 shift forces to make zero average correction:           -0.00    0.00   -0.00

 srhov:    -29.861126     15.763803    -14.097323 sumev=   -3.155366   sumtv=   10.941957

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.061380   -3.762495     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.112356  avg sphere pot= 0.011058  vconst= 0.112356
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.553384   charge     7.762495
 smooth rhoeps =   -7.652959 (  -4.822273,  -2.830685)
         rhomu =  -10.020182 (  -6.611620,  -3.408561)
       avg vxc =   -0.154686 (  -0.169897,  -0.139475)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.008505   -4.857464  -13.865970    -17.703555  -10.278058  -27.981614

 local terms:     true           smooth         local
 rhoeps:        -8.873000      -7.637907      -1.235092
 rhomu:         -6.467176      -6.597521       0.130345
 spin2:         -5.212695      -3.403171      -1.809524
 total:        -11.679871     -10.000691      -1.679180
 val*vef       -13.865970     -13.940831       0.074861
 val chg:        2.908869       6.671364      -3.762495
 val mom:        0.962686       1.869071      -0.906385    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -27.993590        14.115614       -13.877975
   rhoval*ves             -3.820299        -6.769506       -10.589805
   psnuc*ves              14.927066      -283.361568      -268.434502
   utot                    5.553384      -145.065537      -139.512153
   rho*exc                -7.652959        -1.235092        -8.888051
   rho*vxc               -10.020182        -1.679180       -11.699361
   valence chg             6.762495        -3.762495         3.000000
   valence mag             1.906385        -0.906385         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.941957  sumtc=        63.016484   ekin=       73.958442
 rhoep=       -8.888051   utot=      -139.512153   ehks=      -74.441763
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  570.80797177766578     , 5.57582545477541895E-017)   591.77178872672516            67299
 mixrho: sum smrnew new  = (  541.80496507212354     ,-5.56524616402860635E-017)   541.80496507212354                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=4.63e-3  last it=2.30e-2
 mixrho: (warning) scr. and lin-mixed densities had 48589 and 65031 negative poi
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=2.32e-3
   tj:-1.20886   0.96520
 unscreened rms difference:  smooth  0.002873   local  0.011985
   screened rms difference:  smooth  0.002846   local  0.011985   tot  0.004633
 mixrho: sum smrho output= (  510.44382953394643     ,-3.26019164417137620E-017)   526.29210090354616            73263

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=       0.553112   ehk=       0.553137
 From last iter    ehf=       0.502569   ehk=       0.561272
 diffe(q)=  0.050543 (0.004633)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5531125 ehk=.5531372
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 4 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.917370   -3.251992     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.086310  avg sphere pot= 0.011333  vconst= 0.086310
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.453854   charge     7.251992
 smvxcm (warning) mesh density negative at 152232 points:  rhomin=-2.87e-4
 smooth rhoeps =   -6.828534 (  -4.380990,  -2.447545)
         rhomu =   -8.937096 (  -6.017983,  -2.919114)
       avg vxc =   -0.124706 (  -0.133566,  -0.115846)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.911266   -4.774819  -13.686085    -16.088055   -8.831666  -24.919721

 local terms:     true           smooth         local
 rhoeps:        -8.891093      -6.800660      -2.090432
 rhomu:         -6.482897      -5.993913      -0.488985
 spin2:         -5.219907      -2.907099      -2.312808
 total:        -11.702804      -8.901012      -2.801792
 val*vef       -13.686085     -12.876591      -0.809494
 val chg:        2.992540       6.244532      -3.251992
 val mom:        0.981949       1.866431      -0.884482    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.925706 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.619210    7.745276    0.076344   -0.643200
 1      3.000000    1.000000    -5.887832    7.268839    0.126141   -0.602554
 2      3.000000    1.000000     6.000000   28.865828    0.487845   -0.089644
 3      3.000000    1.000000     9.000000   39.724977    0.567553   -0.057343

 potpus  spin 2 : pnu = 2.923291 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.206856    7.601606    0.081133   -0.622226
 1      3.000000    1.000000    -5.887832    7.202376    0.132712   -0.575628
 2      3.000000    1.000000     6.000000   29.131521    0.489376   -0.088337
 3      3.000000    1.000000     9.000000   39.872887    0.568230   -0.057000

 Energy terms:             smooth           local           total
   rhoval*vef            -24.972009        11.233611       -13.738398
   rhoval*ves             -3.905497        -6.524714       -10.430211
   psnuc*ves              14.813205      -283.006490      -268.193285
   utot                    5.453854      -144.765602      -139.311748
   rho*exc                -6.828534        -2.090432        -8.918967
   rho*vxc                -8.937096        -2.801792       -11.738889
   valence chg             6.251992        -3.251992         3.000000
   valence mag             1.915110        -0.884482         1.030627
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.673234
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2322 -0.6104 -0.6104 -0.6104  0.2726  0.6332  0.6332  0.6332
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1019 -0.4808 -0.4808 -0.4808  0.3001  0.6700  0.6700  0.6700
 Est Ef = -0.673 < evl(3)=-0.610 ... using qval=3.0, revise to -0.6104
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.610642;   3.000000 electrons
         Sum occ. bands:   -2.944624, incl. Bloechl correction: -0.000019
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.899777    6.589940   -3.690163      0.958795    1.943850   -0.985055
       contr. to mm extrapolated for r>rmt:   0.035172 est. true mm = 0.993967
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.29290  sum tc=    31.42910  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.24627  sum tc=    31.53558  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.975147   -1.230239    2.925706    2.924932    2.500000    2.924932
 spn 2 0    0.970491   -1.099752    2.923291    2.922126    2.500000    2.922126
 1     1    0.954138   -0.605017    2.850000    2.913328    2.250000    2.850000
 spn 2 1    0.000000   -0.472146    2.850000    2.910680    2.250000    2.850000
 2     0    0.000001   -0.862279    3.147584    3.128540    3.147584    3.147584
 spn 2 0    0.000000   -1.288079    3.147584    3.105345    3.147584    3.147584
 3     0    0.000000   -0.825577    4.102416    4.093620    4.102416    4.102416
 spn 2 0    0.000000   -0.825577    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.944624  val*vef=     -13.738398   sumtv=      10.793774
 sumec=      -40.539168  cor*vef=    -103.531718   ttcor=      62.992550
 rhoeps=      -8.918967     utot=    -139.311748    ehar=     -74.444390

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00    0.00    -0.00   -0.00   -0.00
 shift forces to make zero average correction:           -0.00   -0.00   -0.00

 srhov:    -26.899872     13.333759    -13.566113 sumev=   -2.944624   sumtv=   10.621489

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.040976   -3.690163     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.112111  avg sphere pot= 0.010809  vconst= 0.112111
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.777532   charge     7.690163
 smooth rhoeps =   -7.460538 (  -4.764218,  -2.696321)
         rhomu =   -9.767463 (  -6.543924,  -3.223539)
       avg vxc =   -0.158544 (  -0.174290,  -0.142798)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.848778   -4.765630  -13.614409    -17.711873   -9.878441  -27.590314

 local terms:     true           smooth         local
 rhoeps:        -8.828749      -7.443667      -1.385082
 rhomu:         -6.426611      -6.528111       0.101501
 spin2:         -5.194923      -3.217505      -1.977418
 total:        -11.621534      -9.745617      -1.875917
 val*vef       -13.614409     -13.540516      -0.073892
 val chg:        2.899777       6.589940      -3.690163
 val mom:        0.958795       1.943850      -0.985055    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -27.603704        13.975876       -13.627828
   rhoval*ves             -3.674362        -6.711419       -10.385781
   psnuc*ves              15.229426      -283.210286      -267.980860
   utot                    5.777532      -144.960853      -139.183321
   rho*exc                -7.460538        -1.385082        -8.845620
   rho*vxc                -9.767463        -1.875917       -11.643380
   valence chg             6.690163        -3.690163         3.000000
   valence mag             1.985055        -0.985055         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.621489  sumtc=        62.964678   ekin=       73.586167
 rhoep=       -8.845620   utot=      -139.183321   ehks=      -74.442773
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  510.44382953394631     ,-3.26019164361621780E-017)   526.29210090354604            73263
 mixrho: sum smrnew new  = (  542.20110877870843     ,-4.00348795573200688E-017)   542.20110877870843                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=4.34e-3  last it=4.63e-3
 mixrho: (warning) scr. and lin-mixed densities had 69807 and 73869 negative poi
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=2.17e-3
   tj:-0.15163  -0.27093
 unscreened rms difference:  smooth  0.004238   local  0.009883
   screened rms difference:  smooth  0.004283   local  0.009883   tot  0.004337
 mixrho: sum smrho output= (  555.97491304348102     ,-4.59297605140423578E-017)   559.31829778135102            42029

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=       0.550510   ehk=       0.552127
 From last iter    ehf=       0.553112   ehk=       0.553137
 diffe(q)= -0.002603 (0.004337)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5505096 ehk=.5521266
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 5 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.106150   -3.921199     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.107910  avg sphere pot= 0.010635  vconst= 0.107910
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.801926   charge     7.921199
 smvxcm (warning) mesh density negative at 90714 points:  rhomin=-1.45e-4
 smooth rhoeps =   -7.872732 (  -4.983395,  -2.889338)
         rhomu =  -10.308472 (  -6.838361,  -3.470111)
       avg vxc =   -0.146225 (  -0.155431,  -0.137018)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.892070   -4.844204  -13.736275    -18.439801  -10.547484  -28.987286

 local terms:     true           smooth         local
 rhoeps:        -8.845843      -7.851753      -0.994090
 rhomu:         -6.430371      -6.820456       0.390085
 spin2:         -5.213625      -3.460851      -1.752775
 total:        -11.643996     -10.281307      -1.362690
 val*vef       -13.736275     -14.038593       0.302318
 val chg:        2.906103       6.827302      -3.921199
 val mom:        0.937877       1.939965      -1.002088    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.924932 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.484075    7.821075    0.076069   -0.647410
 1      3.000000    1.000000    -5.887832    7.312358    0.124524   -0.608364
 2      3.000000    1.000000     6.000000   28.752792    0.487080   -0.090231
 3      3.000000    1.000000     9.000000   39.647664    0.567156   -0.057528

 potpus  spin 2 : pnu = 2.922126 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.016911    7.683209    0.081033   -0.626422
 1      3.000000    1.000000    -5.887832    7.242318    0.130953   -0.581585
 2      3.000000    1.000000     6.000000   29.014004    0.488589   -0.088931
 3      3.000000    1.000000     9.000000   39.792198    0.567818   -0.057191

 Energy terms:             smooth           local           total
   rhoval*vef            -29.010264        15.250979       -13.759285
   rhoval*ves             -3.645221        -6.851943       -10.497164
   psnuc*ves              15.249072      -283.416374      -268.167302
   utot                    5.801926      -145.134159      -139.332233
   rho*exc                -7.872732        -0.994090        -8.866822
   rho*vxc               -10.308472        -1.362690       -11.671162
   valence chg             6.921199        -3.921199         3.000000
   valence mag             1.974400        -1.002088         0.972311
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.610642
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2437 -0.6210 -0.6210 -0.6210  0.2782  0.6405  0.6405  0.6405
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1166 -0.4940 -0.4940 -0.4940  0.3035  0.6736  0.6736  0.6736
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.621227;   3.000000 electrons
         Sum occ. bands:   -2.981439, incl. Bloechl correction: -0.000022
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.904515    6.792188   -3.887673      0.960769    1.947000   -0.986230
       contr. to mm extrapolated for r>rmt:   0.033560 est. true mm = 0.994330
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.30778  sum tc=    31.42564  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26173  sum tc=    31.53079  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976241   -1.241952    2.924932    2.925655    2.500000    2.925655
 spn 2 0    0.971872   -1.114650    2.922126    2.922954    2.500000    2.922954
 1     1    0.956401   -0.616216    2.850000    2.914192    2.250000    2.850000
 spn 2 1    0.000000   -0.472377    2.850000    2.923111    2.250000    2.850000
 2     0    0.000001   -0.853432    3.147584    3.128301    3.147584    3.147584
 spn 2 0    0.000000   -1.286232    3.147584    3.104983    3.147584    3.147584
 3     0    0.000000   -0.823506    4.102416    4.093277    4.102416    4.102416
 spn 2 0    0.000000   -0.823506    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.981439  val*vef=     -13.759285   sumtv=      10.777846
 sumec=      -40.569512  cor*vef=    -103.548125   ttcor=      62.978613
 rhoeps=      -8.866822     utot=    -139.332233    ehar=     -74.442597

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00    0.00    -0.00   -0.00   -0.00
 shift forces to make zero average correction:           -0.00   -0.00   -0.00

 srhov:    -28.881328     15.183776    -13.697553 sumev=   -2.981439   sumtv=   10.716114

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.096692   -3.887673     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111979  avg sphere pot= 0.010794  vconst= 0.111979
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.752543   charge     7.887673
 smooth rhoeps =   -7.822437 (  -4.958441,  -2.863997)
         rhomu =  -10.242664 (  -6.805249,  -3.437415)
       avg vxc =   -0.156871 (  -0.172422,  -0.141320)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.894917   -4.791039  -13.685956    -18.328565  -10.449198  -28.777762

 local terms:     true           smooth         local
 rhoeps:        -8.842661      -7.806510      -1.036151
 rhomu:         -6.439654      -6.790322       0.350668
 spin2:         -5.200177      -3.431718      -1.768459
 total:        -11.639832     -10.222040      -1.417791
 val*vef       -13.685956     -14.020485       0.334529
 val chg:        2.904515       6.792188      -3.887673
 val mom:        0.960769       1.947000      -0.986230    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -28.790431        15.091775       -13.698656
   rhoval*ves             -3.678541        -6.762074       -10.440615
   psnuc*ves              15.183628      -283.256748      -268.073120
   utot                    5.752543      -145.009411      -139.256867
   rho*exc                -7.822437        -1.036151        -8.858588
   rho*vxc               -10.242664        -1.417791       -11.660456
   valence chg             6.887673        -3.887673         3.000000
   valence mag             1.986230        -0.986230         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.716114  sumtc=        62.956427   ekin=       73.672541
 rhoep=       -8.858588   utot=      -139.256867   ehks=      -74.442915
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  555.97491304348091     ,-4.59297605301773243E-017)   559.31829778135091            42029
 mixrho: sum smrnew new  = (  554.61893845884049     ,-2.38370607976218472E-016)   554.61893845884049                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=2.88e-4  last it=4.34e-3
 mixrho: (warning) scr. and lin-mixed densities had 31085 and 39893 negative poi
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=1.44e-4
   tj: 0.05063  -0.01812
 unscreened rms difference:  smooth  0.000245   local  0.000816
   screened rms difference:  smooth  0.000231   local  0.000816   tot  0.000288
 mixrho: sum smrho output= (  553.81162824642809     ,-1.39368088152864770E-016)   556.13991806054844            39161

 iors  : write restart file (binary, mesh density) 

   it  5  of 10    ehf=       0.552303   ehk=       0.551985
 From last iter    ehf=       0.550510   ehk=       0.552127
 diffe(q)=  0.001794 (0.000288)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5523033 ehk=.5519854
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 6 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.095363   -3.882959     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.108534  avg sphere pot= 0.010746  vconst= 0.108534
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.758880   charge     7.882959
 smvxcm (warning) mesh density negative at 88866 points:  rhomin=-1.05e-4
 smooth rhoeps =   -7.816494 (  -4.952378,  -2.864116)
         rhomu =  -10.234718 (  -6.796416,  -3.438302)
       avg vxc =   -0.142332 (  -0.152894,  -0.131770)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.898018   -4.814968  -13.712986    -18.302467  -10.444497  -28.746964

 local terms:     true           smooth         local
 rhoeps:        -8.847508      -7.797636      -1.049872
 rhomu:         -6.438817      -6.779659       0.340841
 spin2:         -5.207343      -3.430638      -1.776705
 total:        -11.646160     -10.210297      -1.435863
 val*vef       -13.712986     -13.998491       0.285505
 val chg:        2.910209       6.793168      -3.882959
 val mom:        0.952150       1.940614      -0.988464    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.925655 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.610148    7.813842    0.075614   -0.647515
 1      3.000000    1.000000    -5.887832    7.313207    0.124551   -0.608194
 2      3.000000    1.000000     6.000000   28.751723    0.487057   -0.090239
 3      3.000000    1.000000     9.000000   39.645414    0.567137   -0.057534

 potpus  spin 2 : pnu = 2.922954 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.151316    7.675525    0.080487   -0.626639
 1      3.000000    1.000000    -5.887832    7.243988    0.130949   -0.581528
 2      3.000000    1.000000     6.000000   29.010843    0.488549   -0.088951
 3      3.000000    1.000000     9.000000   39.788172    0.567788   -0.057202

 Energy terms:             smooth           local           total
   rhoval*vef            -28.766924        15.033946       -13.732978
   rhoval*ves             -3.675230        -6.794349       -10.469579
   psnuc*ves              15.192990      -283.319994      -268.127004
   utot                    5.758880      -145.057171      -139.298291
   rho*exc                -7.816494        -1.049872        -8.866366
   rho*vxc               -10.234718        -1.435863       -11.670581
   valence chg             6.882959        -3.882959         3.000000
   valence mag             1.978027        -0.988464         0.989563
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.621227
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2434 -0.6205 -0.6205 -0.6205  0.2823  0.6450  0.6450  0.6450
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1145 -0.4918 -0.4918 -0.4918  0.3107  0.6811  0.6811  0.6811
 Est Ef = -0.621 < evl(3)=-0.621 ... using qval=3.0, revise to -0.6205
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.620785;   3.000000 electrons
         Sum occ. bands:   -2.978580, incl. Bloechl correction: -0.000021
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.904926    6.850247   -3.945321      0.960912    1.950678   -0.989766
       contr. to mm extrapolated for r>rmt:   0.033476 est. true mm = 0.994388
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.30934  sum tc=    31.42772  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26302  sum tc=    31.53318  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976308   -1.241587    2.925655    2.925747    2.500000    2.925747
 spn 2 0    0.972007   -1.112554    2.922954    2.923103    2.500000    2.923103
 1     1    0.956611   -0.615745    2.850000    2.914357    2.250000    2.850000
 spn 2 1    0.000000   -0.468823    2.850000    2.924408    2.250000    2.850000
 2     0    0.000001   -0.854134    3.147584    3.128248    3.147584    3.147584
 spn 2 0    0.000000   -1.285789    3.147584    3.104913    3.147584    3.147584
 3     0    0.000000   -0.828446    4.102416    4.093143    4.102416    4.102416
 spn 2 0    0.000000   -0.828446    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.978580  val*vef=     -13.732978   sumtv=      10.754398
 sumec=      -40.572355  cor*vef=    -103.539876   ttcor=      62.967520
 rhoeps=      -8.866366     utot=    -139.298291    ehar=     -74.442739

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00    0.00    -0.00   -0.00   -0.00
 shift forces to make zero average correction:           -0.00   -0.00   -0.00

 srhov:    -29.084903     15.387953    -13.696949 sumev=   -2.978580   sumtv=   10.718370

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.112954   -3.945321     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111885  avg sphere pot= 0.010729  vconst= 0.111885
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.779579   charge     7.945320
 smooth rhoeps =   -7.918678 (  -5.010717,  -2.907961)
         rhomu =  -10.368981 (  -6.875563,  -3.493417)
       avg vxc =   -0.156777 (  -0.172325,  -0.141229)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.895570   -4.791795  -13.687365    -18.516467  -10.613819  -29.130286

 local terms:     true           smooth         local
 rhoeps:        -8.843432      -7.902826      -0.940606
 rhomu:         -6.440251      -6.860703       0.420453
 spin2:         -5.200596      -3.487750      -1.712845
 total:        -11.640846     -10.348454      -1.292393
 val*vef       -13.687365     -14.123646       0.436281
 val chg:        2.904926       6.850247      -3.945321
 val mom:        0.960912       1.950678      -0.989766    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.142906        15.442889       -13.700017
   rhoval*ves             -3.655432        -6.786006       -10.441438
   psnuc*ves              15.214590      -283.298966      -268.084376
   utot                    5.779579      -145.042486      -139.262907
   rho*exc                -7.918678        -0.940606        -8.859284
   rho*vxc               -10.368981        -1.292393       -11.661373
   valence chg             6.945320        -3.945321         3.000000
   valence mag             1.989766        -0.989766         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.718370  sumtc=        62.960899   ekin=       73.679269
 rhoep=       -8.859284   utot=      -139.262907   ehks=      -74.442923
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  553.81162824642820     ,-1.39368088165523670E-016)   556.13991806054867            39161
 mixrho: sum smrnew new  = (  558.44288919426151     ,-5.84941133384288954E-017)   558.44288919426151                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=6.76e-4  last it=2.88e-4
 mixrho: (warning) scr. and lin-mixed densities had 31367 and 37997 negative poi
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=3.38e-4
   tj: 0.32777  -0.09983
 unscreened rms difference:  smooth  0.000695   local  0.001446
   screened rms difference:  smooth  0.000698   local  0.001446   tot  0.000676
 mixrho: sum smrho output= (  558.83039083491246     ,-1.19347321853798817E-016)   560.01427153024599            25551

 iors  : write restart file (binary, mesh density) 

   it  6  of 10    ehf=       0.552161   ehk=       0.551977
 From last iter    ehf=       0.552303   ehk=       0.551985
 diffe(q)= -0.000142 (0.000676)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5521608 ehk=.5519774
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 7 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.115738   -3.955188     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.110951  avg sphere pot= 0.010697  vconst= 0.110951
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.787207   charge     7.955188
 smvxcm (warning) mesh density negative at 57548 points:  rhomin=-6.89e-5
 smooth rhoeps =   -7.935061 (  -5.019859,  -2.915202)
         rhomu =  -10.390465 (  -6.888046,  -3.502420)
       avg vxc =   -0.153394 (  -0.164218,  -0.142569)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.897402   -4.811392  -13.708794    -18.554319  -10.638353  -29.192672

 local terms:     true           smooth         local
 rhoeps:        -8.843779      -7.917366      -0.926413
 rhomu:         -6.436643      -6.872108       0.435466
 spin2:         -5.204672      -3.495441      -1.709232
 total:        -11.641315     -10.367549      -1.273766
 val*vef       -13.708794     -14.137171       0.428377
 val chg:        2.903235       6.858423      -3.955188
 val mom:        0.952787       1.948980      -0.996194    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.925747 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.626282    7.820185    0.075480   -0.647952
 1      3.000000    1.000000    -5.887832    7.318239    0.124394   -0.608729
 2      3.000000    1.000000     6.000000   28.739351    0.486965   -0.090305
 3      3.000000    1.000000     9.000000   39.636247    0.567086   -0.057557

 potpus  spin 2 : pnu = 2.923103 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.175708    7.681878    0.080298   -0.627143
 1      3.000000    1.000000    -5.887832    7.249094    0.130763   -0.582129
 2      3.000000    1.000000     6.000000   28.996937    0.488446   -0.089023
 3      3.000000    1.000000     9.000000   39.777749    0.567729   -0.057227

 Energy terms:             smooth           local           total
   rhoval*vef            -29.208515        15.483845       -13.724669
   rhoval*ves             -3.651630        -6.813233       -10.464863
   psnuc*ves              15.226045      -283.339090      -268.113045
   utot                    5.787207      -145.076161      -139.288954
   rho*exc                -7.935061        -0.926413        -8.861473
   rho*vxc               -10.390465        -1.273766       -11.664231
   valence chg             6.955188        -3.955188         3.000000
   valence mag             1.986098        -0.996194         0.989904
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.620785
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2444 -0.6214 -0.6214 -0.6214  0.2807  0.6464  0.6464  0.6464
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1152 -0.4923 -0.4923 -0.4923  0.3097  0.6832  0.6832  0.6832
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.621688;   3.000000 electrons
         Sum occ. bands:   -2.981208, incl. Bloechl correction: -0.000022
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905327    6.883118   -3.977791      0.960960    1.946547   -0.985587
       contr. to mm extrapolated for r>rmt:   0.033389 est. true mm = 0.994349
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31137  sum tc=    31.42807  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26502  sum tc=    31.53349  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976434   -1.242611    2.925747    2.925844    2.500000    2.925844
 spn 2 0    0.972184   -1.113297    2.923103    2.923229    2.500000    2.923229
 1     1    0.956710   -0.616820    2.850000    2.914369    2.250000    2.850000
 spn 2 1    0.000000   -0.464688    2.850000    2.928283    2.250000    2.850000
 2     0    0.000001   -0.852912    3.147584    3.128233    3.147584    3.147584
 spn 2 0    0.000000   -1.285276    3.147584    3.104851    3.147584    3.147584
 3     0    0.000000   -0.827915    4.102416    4.093110    4.102416    4.102416
 spn 2 0    0.000000   -0.827915    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.981208  val*vef=     -13.724669   sumtv=      10.743461
 sumec=      -40.576390  cor*vef=    -103.540599   ttcor=      62.964210
 rhoeps=      -8.861473     utot=    -139.288954    ehar=     -74.442757

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00   -0.00    -0.00   -0.00    0.00
 shift forces to make zero average correction:           -0.00   -0.00    0.00

 srhov:    -29.344687     15.636187    -13.708499 sumev=   -2.981208   sumtv=   10.727291

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.122114   -3.977791     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111878  avg sphere pot= 0.010723  vconst= 0.111878
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.778725   charge     7.977791
 smooth rhoeps =   -7.976901 (  -5.038876,  -2.938025)
         rhomu =  -10.445407 (  -6.912700,  -3.532707)
       avg vxc =   -0.156711 (  -0.172297,  -0.141125)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.899369   -4.794758  -13.694127    -18.607281  -10.720054  -29.327335

 local terms:     true           smooth         local
 rhoeps:        -8.844772      -7.961135      -0.883637
 rhomu:         -6.441358      -6.897909       0.456551
 spin2:         -5.201250      -3.527081      -1.674169
 total:        -11.642609     -10.424990      -1.217618
 val*vef       -13.694127     -14.199512       0.505384
 val chg:        2.905327       6.883118      -3.977791
 val mom:        0.960960       1.946547      -0.985587    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.339879        15.633175       -13.706704
   rhoval*ves             -3.654803        -6.791864       -10.446668
   psnuc*ves              15.212254      -283.308029      -268.095775
   utot                    5.778725      -145.049947      -139.271222
   rho*exc                -7.976901        -0.883637        -8.860538
   rho*vxc               -10.445407        -1.217618       -11.663025
   valence chg             6.977791        -3.977791         3.000000
   valence mag             1.985587        -0.985587         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.727291  sumtc=        62.961560   ekin=       73.688851
 rhoep=       -8.860538   utot=      -139.271222   ehks=      -74.442909
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  558.83039083491292     ,-1.19347321865934258E-016)   560.01427153024588            25551
 mixrho: sum smrnew new  = (  560.21107360973951     , 3.73548000399123722E-017)   560.21107360973951                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=3.05e-4  last it=6.76e-4
 mixrho: (warning) scr. and lin-mixed densities had 21975 and 25923 negative poi
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=1.52e-4
   tj:-0.09779   0.44655
 unscreened rms difference:  smooth  0.000316   local  0.000622
   screened rms difference:  smooth  0.000315   local  0.000622   tot  0.000305
 mixrho: sum smrho output= (  557.96643490082238     ,-8.05013311106613127E-017)   559.23655998875131            27131

 iors  : write restart file (binary, mesh density) 

   it  7  of 10    ehf=       0.552143   ehk=       0.551991
 From last iter    ehf=       0.552161   ehk=       0.551977
 diffe(q)= -0.000017 (0.000305)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5521434 ehk=.5519911
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 8 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.112553   -3.943899     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.110429  avg sphere pot= 0.010709  vconst= 0.110429
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.780766   charge     7.943899
 smvxcm (warning) mesh density negative at 63168 points:  rhomin=-6.94e-5
 smooth rhoeps =   -7.917012 (  -5.008367,  -2.908644)
         rhomu =  -10.366742 (  -6.872160,  -3.494582)
       avg vxc =   -0.149774 (  -0.160975,  -0.138574)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.896587   -4.809925  -13.706512    -18.509267  -10.613011  -29.122278

 local terms:     true           smooth         local
 rhoeps:        -8.844576      -7.899310      -0.945266
 rhomu:         -6.437506      -6.856184       0.418678
 spin2:         -5.204838      -3.487634      -1.717204
 total:        -11.642344     -10.343817      -1.298526
 val*vef       -13.706512     -14.117422       0.410910
 val chg:        2.905346       6.849245      -3.943899
 val mom:        0.953535       1.946059      -0.992524    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.925844 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.643537    7.817465    0.075434   -0.647892
 1      3.000000    1.000000    -5.887832    7.317067    0.124430   -0.608609
 2      3.000000    1.000000     6.000000   28.742220    0.486985   -0.090290
 3      3.000000    1.000000     9.000000   39.638267    0.567096   -0.057552

 potpus  spin 2 : pnu = 2.923229 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.196543    7.678762    0.080232   -0.627097
 1      3.000000    1.000000    -5.887832    7.247983    0.130800   -0.582015
 2      3.000000    1.000000     6.000000   28.999876    0.488466   -0.089008
 3      3.000000    1.000000     9.000000   39.779842    0.567740   -0.057222

 Energy terms:             smooth           local           total
   rhoval*vef            -29.138728        15.415734       -13.722995
   rhoval*ves             -3.656733        -6.805798       -10.462531
   psnuc*ves              15.218265      -283.327183      -268.108917
   utot                    5.780766      -145.066490      -139.285724
   rho*exc                -7.917012        -0.945266        -8.862278
   rho*vxc               -10.366742        -1.298526       -11.665268
   valence chg             6.943899        -3.943899         3.000000
   valence mag             1.983564        -0.992524         0.991041
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.621688
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2442 -0.6212 -0.6212 -0.6212  0.2816  0.6466  0.6466  0.6466
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1150 -0.4921 -0.4921 -0.4921  0.3111  0.6837  0.6837  0.6837
 Est Ef = -0.622 < evl(3)=-0.621 ... using qval=3.0, revise to -0.6212
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.621526;   3.000000 electrons
         Sum occ. bands:   -2.980652, incl. Bloechl correction: -0.000022
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905309    6.885856   -3.980547      0.960978    1.949789   -0.988812
       contr. to mm extrapolated for r>rmt:   0.033374 est. true mm = 0.994352
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31142  sum tc=    31.42835  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26506  sum tc=    31.53373  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976414   -1.242425    2.925844    2.925833    2.500000    2.925833
 spn 2 0    0.972166   -1.113070    2.923229    2.923223    2.500000    2.923223
 1     1    0.956729   -0.616601    2.850000    2.914401    2.250000    2.850000
 spn 2 1    0.000000   -0.465543    2.850000    2.927460    2.250000    2.850000
 2     0    0.000001   -0.853676    3.147584    3.128209    3.147584    3.147584
 spn 2 0    0.000000   -1.285580    3.147584    3.104854    3.147584    3.147584
 3     0    0.000000   -0.830524    4.102416    4.093055    4.102416    4.102416
 spn 2 0    0.000000   -0.830524    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.980652  val*vef=     -13.722995   sumtv=      10.742343
 sumec=      -40.576473  cor*vef=    -103.539358   ttcor=      62.962885
 rhoeps=      -8.862278     utot=    -139.285724    ehar=     -74.442774

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00   -0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:    -29.337437     15.630593    -13.706844 sumev=   -2.980652   sumtv=   10.726192

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.122891   -3.980547     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111863  avg sphere pot= 0.010710  vconst= 0.111863
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.784833   charge     7.980546
 smooth rhoeps =   -7.980572 (  -5.042667,  -2.937905)
         rhomu =  -10.450231 (  -6.918195,  -3.532036)
       avg vxc =   -0.156735 (  -0.172327,  -0.141143)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.898929   -4.794340  -13.693269    -18.623731  -10.721026  -29.344756

 local terms:     true           smooth         local
 rhoeps:        -8.844659      -7.964802      -0.879857
 rhomu:         -6.441276      -6.903404       0.462128
 spin2:         -5.201185      -3.526406      -1.674779
 total:        -11.642461     -10.429810      -1.212651
 val*vef       -13.693269     -14.199295       0.506027
 val chg:        2.905309       6.885856      -3.980547
 val mom:        0.960978       1.949789      -0.988812    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.357304        15.651455       -13.705848
   rhoval*ves             -3.649781        -6.796196       -10.445977
   psnuc*ves              15.219446      -283.314964      -268.095517
   utot                    5.784833      -145.055580      -139.270747
   rho*exc                -7.980572        -0.879857        -8.860429
   rho*vxc               -10.450231        -1.212651       -11.662882
   valence chg             6.980546        -3.980547         3.000000
   valence mag             1.988811        -0.988812         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.726192  sumtc=        62.962071   ekin=       73.688263
 rhoep=       -8.860429   utot=      -139.270747   ehks=      -74.442913
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  557.96643490082181     ,-8.05013310958410814E-017)   559.23655998875086            27131
 mixrho: sum smrnew new  = (  560.58484390660942     ,-5.39627286666543937E-017)   560.58484390660942                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=4.15e-4  last it=3.05e-4
 mixrho: (warning) scr. and lin-mixed densities had 24399 and 27563 negative poi
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=2.08e-4
   tj:-1.91994  -2.47442
 unscreened rms difference:  smooth  0.000434   local  0.000869
   screened rms difference:  smooth  0.000434   local  0.000869   tot  0.000415
 mixrho: sum smrho output= (  566.59550450839697     ,-3.91663697117120801E-017)   566.59550450839697                0

 iors  : write restart file (binary, mesh density) 

   it  8  of 10    ehf=       0.552126   ehk=       0.551987
 From last iter    ehf=       0.552143   ehk=       0.551991
 diffe(q)= -0.000018 (0.000415)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5521258 ehk=.5519868
 ttt: lrsig,ldos,lfrzw=           0           0           0
 ttt: sham%lsig       =                    0

 --- BNDFP:  begin iteration 9 of 10 ---

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.148974   -4.073007     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.113527  avg sphere pot= 0.010641  vconst= 0.113527
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.818356   charge     8.073007
 smooth rhoeps =   -8.135811 (  -5.126789,  -3.009022)
         rhomu =  -10.654080 (  -7.031438,  -3.622642)
       avg vxc =   -0.172466 (  -0.184335,  -0.160598)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.898305   -4.796128  -13.694433    -18.930342  -10.986390  -29.916732

 local terms:     true           smooth         local
 rhoeps:        -8.842077      -8.120138      -0.721939
 rhomu:         -6.438884      -7.016761       0.577877
 spin2:         -5.200228      -3.617017      -1.583212
 total:        -11.639113     -10.633778      -1.005335
 val*vef       -13.694433     -14.379295       0.684861
 val chg:        2.899716       6.972722      -4.073007
 val mom:        0.959788       1.953869      -0.994082    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.925833 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.641618    7.825637    0.075374   -0.648206
 1      3.000000    1.000000    -5.887832    7.323079    0.124286   -0.609037
 2      3.000000    1.000000     6.000000   28.728302    0.486873   -0.090366
 3      3.000000    1.000000     9.000000   39.627029    0.567029   -0.057580

 potpus  spin 2 : pnu = 2.923223 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.195531    7.688764    0.080142   -0.627514
 1      3.000000    1.000000    -5.887832    7.254851    0.130601   -0.582595
 2      3.000000    1.000000     6.000000   28.982524    0.488327   -0.089101
 3      3.000000    1.000000     9.000000   39.765794    0.567656   -0.057257

 Energy terms:             smooth           local           total
   rhoval*vef            -29.927201        16.222265       -13.704936
   rhoval*ves             -3.622191        -6.824685       -10.446876
   psnuc*ves              15.258903      -283.354162      -268.095259
   utot                    5.818356      -145.089424      -139.271068
   rho*exc                -8.135811        -0.721939        -8.857750
   rho*vxc               -10.654080        -1.005335       -11.659415
   valence chg             7.073007        -4.073007         3.000000
   valence mag             1.992521        -0.994082         0.998440
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.621526
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2448 -0.6217 -0.6217 -0.6217  0.2803  0.6483  0.6483  0.6483
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1146 -0.4915 -0.4915 -0.4915  0.3125  0.6885  0.6885  0.6885
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.621998;   3.000000 electrons
         Sum occ. bands:   -2.981377, incl. Bloechl correction: -0.000021
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905850    6.949301   -4.043451      0.960948    1.932395   -0.971446
       contr. to mm extrapolated for r>rmt:   0.033391 est. true mm = 0.994339
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31319  sum tc=    31.42899  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26675  sum tc=    31.53454  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976583   -1.243057    2.925833    2.925990    2.500000    2.925990
 spn 2 0    0.972451   -1.112717    2.923223    2.923466    2.500000    2.923466
 1     1    0.956816   -0.617338    2.850000    2.914404    2.250000    2.850000
 spn 2 1    0.000000   -0.460188    2.850000    2.931445    2.250000    2.850000
 2     0    0.000001   -0.851830    3.147584    3.128210    3.147584    3.147584
 spn 2 0    0.000000   -1.285355    3.147584    3.104727    3.147584    3.147584
 3     0    0.000000   -0.827571    4.102416    4.093074    4.102416    4.102416
 spn 2 0    0.000000   -0.827571    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.981377  val*vef=     -13.704936   sumtv=      10.723559
 sumec=      -40.579946  cor*vef=    -103.542424   ttcor=      62.962478
 rhoeps=      -8.857750     utot=    -139.271068    ehar=     -74.442781

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00   -0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:    -29.797608     16.080808    -13.716799 sumev=   -2.981377   sumtv=   10.735422

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.140636   -4.043451     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111827  avg sphere pot= 0.010687  vconst= 0.111827
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.789683   charge     8.043451
 smooth rhoeps =   -8.090417 (  -5.089194,  -3.001223)
         rhomu =  -10.594350 (  -6.977726,  -3.616624)
       avg vxc =   -0.156610 (  -0.172238,  -0.140982)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 vvv val rho1
 vvv val rho2
 vvv val end

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.901970   -4.798207  -13.700177    -18.774706  -10.953060  -29.727766

 local terms:     true           smooth         local
 rhoeps:        -8.846141      -8.074754      -0.771388
 rhomu:         -6.442326      -6.963009       0.520683
 spin2:         -5.202083      -3.611058      -1.591025
 total:        -11.644409     -10.574067      -1.070342
 val*vef       -13.700177     -14.338337       0.638160
 val chg:        2.905850       6.949301      -4.043451
 val mom:        0.960948       1.932395      -0.971446    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.740228        16.027556       -13.712672
   rhoval*ves             -3.644655        -6.806599       -10.451254
   psnuc*ves              15.224022      -283.332849      -268.108827
   utot                    5.789683      -145.069724      -139.280041
   rho*exc                -8.090417        -0.771388        -8.861805
   rho*vxc               -10.594350        -1.070342       -11.664692
   valence chg             7.043451        -4.043451         3.000000
   valence mag             1.971446        -0.971446         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.735422  sumtc=        62.963529   ekin=       73.698951
 rhoep=       -8.861805   utot=      -139.280041   ehks=      -74.442894
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = (  566.59550450839697     ,-3.91663697123024439E-017)   566.59550450839697                0
 mixrho: sum smrnew new  = (  563.43103795985780     , 1.37518584003329846E-017)   563.43103795985780                0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=3.38e-4  last it=4.15e-4
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=1.69e-4
   tj: 2.91362  -3.06617
 unscreened rms difference:  smooth  0.000261   local  0.000821
   screened rms difference:  smooth  0.000264   local  0.000821   tot  0.000338
 mixrho: sum smrho output= (  565.13706339943644     ,-8.48327542091595833E-017)   565.13706339943644                0

 iors  : write restart file (binary, mesh density) 

   it  9  of 10    ehf=       0.552119   ehk=       0.552006
 From last iter    ehf=       0.552126   ehk=       0.551987
 diffe(q)= -0.000007 (0.000338)    tol= 0.000010 (0.000500)   more=F
c zbak=1 mmom=.9999997 ehf=.5521191 ehk=.5520055
 Exit 0 LMF 
 wkinfo:  used    11023 K  workspace of   300000 K   in     4 K calls
