rdcmd:  lmfa --no-iactiv c -vzbak=1
 -----------------------  START LMFA     -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMFA  vn 7.00(LMFA 7.0)  verb 30,40,60
 pot:      spin-pol, XC:BH
 end of rdctrl2 in imfav7
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137
 goto mksym

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 end of mksym x
 goto defspc
 end of defspc
 goto freeat

conf:SPEC_ATOM= C : --- Table for atomic configuration ---
conf int(P)z = int(P) where P is replaced by PZ if it is semicore
conf:  isp  l  int(P) int(P)z    Qval    Qcore   CoreConf
conf:    1  0       2  2        1.000    1.000 => 1,
conf:    1  1       2  2        2.000    0.000 => 
conf:    1  2       3  3        0.000    0.000 => 
conf:    1  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------
conf:    2  0       2  2        1.000    1.000 => 1,
conf:    2  1       2  2        0.000    0.000 => 
conf:    2  2       3  3        0.000    0.000 => 
conf:    2  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001
 tailsm: init
 tailsm:xxx1
 tailsm:xxx2

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753709   qtot  1.997279
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 tailsm: end
 end of freats: spid=C       

  Write mtopara.* ...
 Exit 0 LMFA 
rdcmd:  lmf  --no-iactiv c -vzbak=1
 -----------------------  START LMF      -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMF  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 
 goto setcg
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 
 lstar xxx=          -2
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F
 lstar xxx=          -2

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 gvlist: cutoff radius  13.994 gives  45911   recips of max 125000
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363587    3.701843    2.363561    1.338282
 amom    1.810990    1.143831    1.810990    1.143831    0.667159
 Uniform density added to neutralize background, q=1.000000

 Smooth charge on mesh:            1.661718    moment    1.332841
 Sum of local charges:             1.338282    moments   0.667159
 Total valence charge:             3.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           1.000000
 Deviation from neutrality:       -0.000000

 --- BNDFP:  begin iteration 1 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       93611 -4.96985036122515704E-004
 mkpot negative smrho; isp,number,min(smrho)=           2      107643 -4.99895726979550110E-004
 enforce positive smrho, to which we add srshift=  4.99895726989550140E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338282     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      2.060608   charge     3.661509
 smooth rhoeps =   -1.494861 (  -1.109298,  -0.385563)
         rhomu =   -1.946499 (  -1.522749,  -0.423750)
       avg vxc =   -0.191138 (  -0.218032,  -0.164244)
 smooth rhoeps =   -1.494861 (  -1.109298,  -0.385563)
         rhomu =   -1.946499 (  -1.522749,  -0.423750)
       avg vxc =   -0.191138 (  -0.218032,  -0.164244)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       128
 vxcnsp (warning): negative rho: min val =  -4.61E-04
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.261804   -3.876233  -14.138038     -2.842621   -0.891813   -3.734435

 local terms:     true           smooth         local
 rhoeps:        -9.464952      -1.364263      -8.100688
 rhomu:         -7.369404      -1.402026      -5.967378
 spin2:         -5.086143      -0.375091      -4.711052
 total:        -12.455547      -1.777117     -10.678430
 val*vef       -14.138038      -6.807929      -7.330109
 val chg:        3.588746       2.250464       1.338282
 val mom:        1.810990       1.143831       0.667159    core:  -0.000000
 core chg:       2.000000       2.000000      -0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.622125    0.101666   -0.583560
 1      3.000000    1.000000    -5.887832    7.139035    0.143256   -0.535856
 2      3.000000    1.000000     4.727244   27.072458    0.465408   -0.096156
 3      3.000000    1.000000     7.577135   37.163437    0.543349   -0.062204

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.498210    0.106861   -0.559304
 1      3.000000    1.000000    -5.887832    7.161455    0.151762   -0.504954
 2      3.000000    1.000000     4.727244   27.365015    0.467061   -0.094577
 3      3.000000    1.000000     7.577135   37.316588    0.544000   -0.061810

 Energy terms:             smooth           local           total
   rhoval*vef             -3.931560       -10.403599       -14.335159
   rhoval*ves             -5.065158        -5.181775       -10.246933
   psnuc*ves               9.186373      -278.836573      -269.650199
   utot                    2.060608      -142.009174      -139.948566
   rho*exc                -1.494861        -8.100688        -9.595549
   rho*vxc                -1.946499       -10.678430       -12.624928
   valence chg             2.661509         1.338282         3.999791
   valence mag             1.332841         0.667159         2.000000
   core charge             2.000000        -0.000000         2.000000

 Charges:  valence     3.99979   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.99979
 (warning) system not neutral, dq=0.999791

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0534 -0.6779 -0.4297 -0.4297 -0.4297  0.2977  0.2977  0.2977
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1365 -0.8248 -0.2365 -0.2365 -0.2365  0.2428  0.2428  0.2428
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 ... only filled or empty bands encountered:  ev=-0.824805  ec=-0.772717
 VBmax = -0.824805  CBmin = -0.772717  gap = 0.052088 Ry = 0.70839 eV
 BZINTS: Fermi energy:     -0.824805;   3.000000 electrons
         Sum occ. bands:   -3.277725, incl. Bloechl correction:  0.000000
         Mag. moment:      -1.000000

 Saved qp weights ...
 Start second band pass ...
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0534 -0.6779 -0.4297 -0.4297 -0.4297  0.2977  0.2977  0.2977
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1365 -0.8248 -0.2365 -0.2365 -0.2365  0.2428  0.2428  0.2428
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 ... only filled or empty bands encountered:  ev=-0.824805  ec=-0.772717
 VBmax = -0.824805  CBmin = -0.772717  gap = 0.052088 Ry = 0.70839 eV
 BZINTS: Fermi energy:     -0.824805;   3.000000 electrons
         Sum occ. bands:   -3.277725, incl. Bloechl correction:  0.000000
         Mag. moment:      -1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.130156  386.510089 -384.379933     -0.144414 -327.846694  327.702280
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85491  sum tc=    31.38764  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78517  sum tc=    31.54593  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.992767   -0.956642    2.900000    2.967335    2.500000    2.967335
 spn 2 0    1.134455   -0.773670    2.900000    2.946917    2.500000    2.946917
 1     1    0.000104   -0.505503    2.850000    2.802064    2.250000    2.850000
 spn 2 1    0.002815   -0.125968    2.850000    2.943095    2.250000    2.850000
 2     0    0.000000   -1.059852    3.180000    3.117538    3.147584    3.147584
 spn 2 0    0.000012   -1.006449    3.180000    3.114300    3.147584    3.147584
 3     0    0.000000   -0.979574    4.120000    4.090136    4.102416    4.102416
 spn 2 0    0.000004   -0.926740    4.120000    4.088649    4.102416    4.102416

 Harris energy:
 sumev=       -3.277725  val*vef=     -14.335159   sumtv=      11.057434
 sumec=      -39.640082  cor*vef=    -102.572087   ttcor=      62.932005
 rhoeps=      -9.595549     utot=    -139.948566    ehar=     -75.554677

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00    -0.00   -0.00   -0.00
 shift forces to make zero average correction:           -0.00   -0.00   -0.00

 srhov:  -1237.406564   1225.633681    -11.772882 sumev=   -3.277725   sumtv=    8.495157
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1 -108.431577 -384.379933     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.205342  avg sphere pot= 0.030809  vconst= 0.205342
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves     38.909154   charge   388.379933
 smooth rhoeps =-2470.307875 (-179.105890,***********)
         rhomu =-3278.855537 (-116.220351,***********)
       avg vxc =   -0.316237 (  -0.227596,  -0.404877)
 smooth rhoeps =-2470.307875 (-179.105890,***********)
         rhomu =-3278.855537 (-116.220351,***********)
       avg vxc =   -0.316237 (  -0.227596,  -0.404877)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -5.572121   -5.624672  -11.196792    -82.113018-2616.753793-2698.866811

 local terms:     true           smooth         local
 rhoeps:        -7.980818   -2470.061843    2462.081025
 rhomu:         -5.216692    -116.218998     111.002306
 spin2:         -5.294318   -3162.316810    3157.022492
 total:        -10.511010   -3278.535808    3268.024799
 val*vef       -11.196792   -3195.933466    3184.736673
 val chg:        2.130156     386.510089    -384.379933
 val mom:       -0.144414    -327.846694     327.702280    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef          -2698.887528      2687.555482       -11.332046
   rhoval*ves             82.992160       -91.768696        -8.776537
   psnuc*ves              -5.173852      -258.804102      -263.977954
   utot                   38.909154      -175.286399      -136.377246
   rho*exc             -2470.307875      2462.081025        -8.226850
   rho*vxc             -3278.855537      3268.024799       -10.830739
   valence chg           387.379933      -384.379933         3.000000
   valence mag          -328.702280       327.702280        -1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=        8.495157  sumtc=        62.933572   ekin=       71.428730
 rhoep=       -8.226850   utot=      -136.377246   ehks=      -73.175366
 mag. mom=    -1.000000  (bands)       -1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.249647D+03 0.213631D-25 0.249647D+03       0
 mixrho: sum smrnew new  = 0.366735D+04 0.105471D-14 0.366735D+04       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns=  0.38472D+00  0.45304D+01 -0.21293D-16
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=3.66e0
 AMIX: nmix=0 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=1.83e0
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.49989546938422791      -2.49947734692113988E-004
 add q= -0.499895 to preserve neutrality
 mixrho: warning. negative smrho; isp number min=           1       93323 -2.48461366258057254E-004
 mixrho: warning. negative smrho; isp number min=           2       60589 -2.48563578016058558E-004

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=      -0.559777   ehk=       1.819534
h zbak=1 mmom=-1.0000002 ehf=-.5597765 ehk=1.819534

 --- BNDFP:  begin iteration 2 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       93323 -2.48461366258057254E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       60589 -2.48563578016058558E-004
 enforce positive smrho, to which we add srshift=  2.48563578026058535E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1  -54.027027 -191.520826     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.099368  avg sphere pot= 0.025175  vconst= 0.099368
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      8.916753   charge   196.017953
 smooth rhoeps = -987.218966 ( -73.343470,-913.875496)
         rhomu =-1309.222887 ( -48.830572,***********)
       avg vxc =   -0.291544 (  -0.245283,  -0.337806)
 smooth rhoeps = -987.218966 ( -73.343470,-913.875496)
         rhomu =-1309.222887 ( -48.830572,***********)
       avg vxc =   -0.291544 (  -0.245283,  -0.337806)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0        64
 vxcnsp (warning): negative rho: min val =  -9.48E-05
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.179996   -4.715630  -12.895626    -57.076099-1332.288152-1389.364250

 local terms:     true           smooth         local
 rhoeps:        -8.675048    -987.018475     978.343428
 rhomu:         -6.227523     -48.764117      42.536593
 spin2:         -5.191474   -1260.198225    1255.006751
 total:        -11.418997   -1308.962342    1297.543345
 val*vef       -12.895626   -1293.275221    1280.379594
 val chg:        2.859451     194.380277    -191.520826
 val mom:        0.833288    -163.351431     164.184719    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000151

 potpus  spin 1 : pnu = 2.967335 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -29.130920    7.412574    0.040313   -0.678797
 1      3.000000    1.000000    -5.887832    7.347846    0.119244   -0.633602
 2      3.000000    1.000000     6.000000   28.602069    0.486329   -0.090973
 3      3.000000    1.000000     9.000000   39.577697    0.566905   -0.057685

 potpus  spin 2 : pnu = 2.946917 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -17.822435    7.432831    0.060410   -0.655442
 1      3.000000    1.000000    -5.887832    7.190905    0.125329   -0.610073
 2      3.000000    1.000000     6.000000   28.983861    0.489146   -0.088946
 3      3.000000    1.000000     9.000000   39.849830    0.568486   -0.057017

 Energy terms:             smooth           local           total
   rhoval*vef          -1389.555193      1376.439778       -13.115415
   rhoval*ves             15.827245       -25.671320        -9.844075
   psnuc*ves               2.006261      -268.820337      -266.814076
   utot                    8.916753      -147.245829      -138.329076
   rho*exc              -987.218966       978.343428        -8.875539
   rho*vxc             -1309.222887      1297.543345       -11.679542
   valence chg           195.017953      -191.520826         3.497127
   valence mag          -163.684720       164.184719         0.500000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.49713   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.49713
 (warning) system not neutral, dq=0.497127

 Read qp weights ...  ef=-0.824805
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.3393 -0.7201 -0.7201 -0.7201  0.1428  0.5383  0.5383  0.5383
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2237 -0.6074 -0.6074 -0.6074  0.1403  0.5134  0.5134  0.5134
 Est Ef = -0.825 < evl(3)=-0.720 ... using qval=3.0, revise to -0.7201
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.720401;   3.000000 electrons
         Sum occ. bands:   -3.283288, incl. Bloechl correction: -0.000018
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.897581    6.504584   -3.607003     -0.938918   -0.458132   -0.480786
       contr. to mm extrapolated for r>rmt:  -0.052588 est. true mm =-0.991506
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.56207  sum tc=    31.48865  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.52663  sum tc=    31.57660  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.979331   -1.334219    2.967335    2.927950    2.500000    2.927950
 spn 2 0    0.973025   -1.220187    2.946917    2.922262    2.500000    2.922262
 1     1    0.000000   -0.820818    2.850000    2.745085    2.250000    2.850000
 spn 2 1    0.945224   -0.601531    2.850000    2.907252    2.250000    2.850000
 2     0    0.000000   -0.601531    3.147584    3.147584    3.147584    3.147584
 spn 2 0    0.000001   -0.832845    3.147584    3.130004    3.147584    3.147584
 3     0    0.000000   -0.832845    4.102416    4.102416    4.102416    4.102416
 spn 2 0    0.000000   -0.800320    4.102416    4.094239    4.102416    4.102416

 Harris energy:
 sumev=       -3.283288  val*vef=     -13.115415   sumtv=       9.832126
 sumec=      -41.088704  cor*vef=    -104.021340   ttcor=      62.932636
 rhoeps=      -8.875539     utot=    -138.329076    ehar=     -74.439851

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:    -31.412991     17.297190    -14.115801 sumev=   -3.283288   sumtv=   10.832513
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.017517   -3.607003     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.114296  avg sphere pot= 0.011838  vconst= 0.114296
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.200249   charge     7.607003
 smooth rhoeps =   -7.392392 (  -3.633825,  -3.758567)
         rhomu =   -9.675230 (  -4.751286,  -4.923944)
       avg vxc =   -0.159433 (  -0.139128,  -0.179737)
 smooth rhoeps =   -7.392392 (  -3.633825,  -3.758567)
         rhomu =   -9.675230 (  -4.751286,  -4.923944)
       avg vxc =   -0.159433 (  -0.139128,  -0.179737)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -5.081352   -8.801831  -13.883183    -13.706138  -13.296906  -27.003044

 local terms:     true           smooth         local
 rhoeps:        -8.861680      -7.375266      -1.486414
 rhomu:         -5.238470      -4.747171      -0.491300
 spin2:         -6.426473      -4.905883      -1.520590
 total:        -11.664943      -9.653053      -2.011890
 val*vef       -13.883183     -13.903164       0.019981
 val chg:        2.897581       6.504584      -3.607003
 val mom:       -0.938918      -0.458132      -0.480786    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -27.016011        13.119833       -13.896177
   rhoval*ves             -4.126632        -6.496289       -10.622921
   psnuc*ves              14.527131      -283.043232      -268.516102
   utot                    5.200249      -144.769760      -139.569511
   rho*exc                -7.392392        -1.486414        -8.878806
   rho*vxc                -9.675230        -2.011890       -11.687120
   valence chg             6.607003        -3.607003         3.000000
   valence mag            -0.519214        -0.480786        -1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.832513  sumtc=        63.065249   ekin=       73.897762
 rhoep=       -8.878806   utot=      -139.569511   ehks=      -74.550555
 mag. mom=     1.000000  (bands)       -1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.195833D+04-0.325370D-25 0.195833D+04       0
 mixrho: sum smrnew new  = 0.380487D+03-0.730898D-16 0.380487D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns= -0.18841D+00  0.22420D+01 -0.33201D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=1.81e0  last it=3.66e0
 AMIX: nmix=1 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=9.05e-1
   tj: 0.33115
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.33179089741716439      -1.65895448708582222E-004
 add q= -0.331791 to preserve neutrality
 mixrho: warning. negative smrho; isp number min=           1       92435 -1.65365929004885850E-004
 mixrho: warning. negative smrho; isp number min=           2       59461 -1.64430778154683481E-004

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=       0.555049   ehk=       0.444345
 From last iter    ehf=      -0.559777   ehk=       1.819534
 diffe(q)=  1.114825 (1.810292)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=-.9999997 ehf=.5550487 ehk=.4443449

 --- BNDFP:  begin iteration 3 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       92435 -1.65365929004885850E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       59461 -1.64430778154683481E-004
 enforce positive smrho, to which we add srshift=  1.65365929014885853E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1  -36.299193 -128.677287     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.104360  avg sphere pot= 0.020714  vconst= 0.104360
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      4.208275   charge   133.008019
 smooth rhoeps = -583.129602 ( -46.566697,-536.562905)
         rhomu = -772.853970 ( -32.040516,-740.813454)
       avg vxc =   -0.264656 (  -0.223158,  -0.306153)
 smooth rhoeps = -583.129602 ( -46.566697,-536.562905)
         rhomu = -772.853970 ( -32.040516,-740.813454)
       avg vxc =   -0.264656 (  -0.223158,  -0.306153)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -7.108179   -6.087655  -13.195833    -48.768041 -921.085473 -969.853514

 local terms:     true           smooth         local
 rhoeps:        -8.713244    -582.999796     574.286552
 rhomu:         -5.883910     -31.998043      26.114133
 spin2:         -5.584098    -740.687341     735.103242
 total:        -11.468008    -772.685383     761.217375
 val*vef       -13.195833    -770.596908     757.401075
 val chg:        2.872203     131.549490    -128.677287
 val mom:        0.240614    -108.875443     109.116056    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000103

 potpus  spin 1 : pnu = 2.927950 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -13.026603    7.810851    0.073406   -0.653763
 1      3.000000    1.000000    -5.887832    7.308468    0.122990   -0.616135
 2      3.000000    1.000000     6.000000   28.730353    0.487023   -0.090330
 3      3.000000    1.000000     9.000000   39.642413    0.567174   -0.057536

 potpus  spin 2 : pnu = 2.922262 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.038806    7.769815    0.078039   -0.646891
 1      3.000000    1.000000    -5.887832    7.235259    0.125012   -0.609552
 2      3.000000    1.000000     6.000000   28.898369    0.488411   -0.089413
 3      3.000000    1.000000     9.000000   39.776672    0.568023   -0.057199

 Energy terms:             smooth           local           total
   rhoval*vef           -969.978738       956.644448       -13.334289
   rhoval*ves              2.222966       -12.334016       -10.111050
   psnuc*ves               6.193583      -273.618420      -267.424837
   utot                    4.208275      -142.976218      -138.767944
   rho*exc              -583.129602       574.286552        -8.843050
   rho*vxc              -772.853970       761.217375       -11.636594
   valence chg           132.008019      -128.677287         3.330732
   valence mag          -109.117698       109.116056        -0.001641
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.33073   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.33073
 (warning) system not neutral, dq=0.330732

 Read qp weights ...  ef=-0.720401
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2667 -0.6457 -0.6457 -0.6457  0.1841  0.5759  0.5759  0.5759
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2336 -0.6150 -0.6150 -0.6150  0.1705  0.5419  0.5419  0.5419
 Est Ef = -0.720 < evl(3)=-0.646 ... using qval=3.0, revise to -0.6457
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.646119;   3.000000 electrons
         Sum occ. bands:   -3.146326, incl. Bloechl correction: -0.000023
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.907867    6.727450   -3.819583      0.959683    2.095229   -1.135545
       contr. to mm extrapolated for r>rmt:   0.034282 est. true mm = 0.993965
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.45016  sum tc=    31.49370  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.44193  sum tc=    31.51685  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.977272   -1.262344    2.927950    2.926403    2.500000    2.926403
 spn 2 0    0.974091   -1.230531    2.922262    2.923293    2.500000    2.923293
 1     1    0.956503   -0.639631    2.850000    2.913589    2.250000    2.850000
 spn 2 1    0.000000   -0.590209    2.850000    2.926701    2.250000    2.850000
 2     0    0.000001   -0.855013    3.147584    3.128591    3.147584    3.147584
 spn 2 0    0.000000   -1.347103    3.147584    3.104812    3.147584    3.147584
 3     0    0.000000   -0.829277    4.102416    4.093283    4.102416    4.102416
 spn 2 0    0.000000   -0.829277    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -3.146326  val*vef=     -13.334289   sumtv=      10.187963
 sumec=      -40.892092  cor*vef=    -103.891015   ttcor=      62.998923
 rhoeps=      -8.843050     utot=    -138.767944    ehar=     -74.424107

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00    0.00     0.00    0.00    0.00     0.00    0.00   -0.00
 shift forces to make zero average correction:            0.00    0.00   -0.00

 srhov:    -31.646016     17.557403    -14.088612 sumev=   -3.146326   sumtv=   10.942286
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.077485   -3.819583     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.112612  avg sphere pot= 0.011161  vconst= 0.112612
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.511885   charge     7.819583
 smooth rhoeps =   -7.788185 (  -5.038913,  -2.749271)
         rhomu =  -10.199200 (  -6.937233,  -3.261967)
       avg vxc =   -0.155678 (  -0.172211,  -0.139145)
 smooth rhoeps =   -7.788185 (  -5.038913,  -2.749271)
         rhomu =  -10.199200 (  -6.937233,  -3.261967)
       avg vxc =   -0.155678 (  -0.172211,  -0.139145)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.945517   -4.923244  -13.868761    -18.492720   -9.871520  -28.364239

 local terms:     true           smooth         local
 rhoeps:        -8.870642      -7.772998      -1.097644
 rhomu:         -6.458156      -6.922728       0.464572
 spin2:         -5.218570      -3.256807      -1.961763
 total:        -11.676726     -10.179535      -1.497191
 val*vef       -13.868761     -14.155704       0.286942
 val chg:        2.907867       6.727450      -3.819583
 val mom:        0.959683       2.095229      -1.135545    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -28.376188        14.495448       -13.880740
   rhoval*ves             -3.855870        -6.738905       -10.594775
   psnuc*ves              14.879639      -283.302083      -268.422443
   utot                    5.511885      -145.020494      -139.508609
   rho*exc                -7.788185        -1.097644        -8.885829
   rho*vxc               -10.199200        -1.497191       -11.696392
   valence chg             6.819583        -3.819583         3.000000
   valence mag             2.135545        -1.135545         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.942286  sumtc=        63.010549   ekin=       73.952835
 rhoep=       -8.885829   utot=      -139.508609   ehks=      -74.441603
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.143065D+04-0.260480D-25 0.143065D+04       0
 mixrho: sum smrnew new  = 0.559696D+03 0.116258D-15 0.559696D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns= -0.12519D+00  0.14956D+01 -0.33232D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=1.21e0  last it=1.81e0
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=6.03e-1
   tj:-0.16043   0.22815
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.22834201512753793      -1.14171007563768990E-004
 add q= -0.228342 to preserve neutrality
 mixrho: warning. negative smrho; isp number min=           1       88001 -1.13260055640345626E-004
 mixrho: warning. negative smrho; isp number min=           2       59797 -1.13651141851062621E-004

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=       0.570793   ehk=       0.553297
 From last iter    ehf=       0.555049   ehk=       0.444345
 diffe(q)=  0.015745 (1.206392)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5707935 ehk=.5532972

 --- BNDFP:  begin iteration 4 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       88001 -1.13260055640345626E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       59797 -1.13651141851062621E-004
 enforce positive smrho, to which we add srshift=  1.13651141861062624E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1  -25.333706  -89.805651     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.106671  avg sphere pot= 0.017632  vconst= 0.106671
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      3.058628   charge    94.032953
 smooth rhoeps = -361.529342 ( -32.908969,-328.620373)
         rhomu = -478.818496 ( -23.943470,-454.875025)
       avg vxc =   -0.244958 (  -0.214449,  -0.275468)
 smooth rhoeps = -361.529342 ( -32.908969,-328.620373)
         rhomu = -478.818496 ( -23.943470,-454.875025)
       avg vxc =   -0.244958 (  -0.214449,  -0.275468)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.298495   -5.119359  -13.417854    -43.085266 -639.634978 -682.720244

 local terms:     true           smooth         local
 rhoeps:        -8.772198    -361.441528     352.669330
 rhomu:         -6.255762     -23.907881      17.652119
 spin2:         -5.290810    -454.796632     449.505822
 total:        -11.546572    -478.704513     467.157941
 val*vef       -13.417854    -481.671205     468.253351
 val chg:        2.884905      92.690556     -89.805651
 val mom:        0.758097     -73.903400      74.661497    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000073

 potpus  spin 1 : pnu = 2.926403 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.743054    7.838866    0.074372   -0.653279
 1      3.000000    1.000000    -5.887832    7.320407    0.122912   -0.615970
 2      3.000000    1.000000     6.000000   28.708060    0.486860   -0.090449
 3      3.000000    1.000000     9.000000   39.626455    0.567084   -0.057575

 potpus  spin 2 : pnu = 2.923293 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.207197    7.693374    0.078916   -0.636743
 1      3.000000    1.000000    -5.887832    7.218444    0.128195   -0.595177
 2      3.000000    1.000000     6.000000   28.991395    0.488838   -0.088973
 3      3.000000    1.000000     9.000000   39.816513    0.568148   -0.057113

 Energy terms:             smooth           local           total
   rhoval*vef           -682.804924       669.295807       -13.509117
   rhoval*ves             -2.837301        -7.423599       -10.260900
   psnuc*ves               8.954557      -276.695872      -267.741315
   utot                    3.058628      -142.059735      -139.001107
   rho*exc              -361.529342       352.669330        -8.860012
   rho*vxc              -478.818496       467.157941       -11.660555
   valence chg            93.032953       -89.805651         3.227302
   valence mag           -74.041937        74.661497         0.619560
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.22730   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.22730
 (warning) system not neutral, dq=0.227302

 Read qp weights ...  ef=-0.646119
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2729 -0.6514 -0.6514 -0.6514  0.2043  0.5896  0.5896  0.5896
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1706 -0.5511 -0.5511 -0.5511  0.2031  0.5780  0.5780  0.5780
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.651739;   3.000000 electrons
         Sum occ. bands:   -3.095187, incl. Bloechl correction: -0.000022
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.906931    6.684911   -3.777980      0.962514    2.211821   -1.249306
       contr. to mm extrapolated for r>rmt:   0.031744 est. true mm = 0.994258
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.39955  sum tc=    31.45450  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.36451  sum tc=    31.53471  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.977355   -1.269297    2.926403    2.926471    2.500000    2.926471
 spn 2 0    0.972208   -1.167701    2.923293    2.922317    2.500000    2.922317
 1     1    0.957368   -0.645762    2.850000    2.914165    2.250000    2.850000
 spn 2 1    0.000000   -0.533684    2.850000    2.918174    2.250000    2.850000
 2     0    0.000001   -0.863124    3.147584    3.128334    3.147584    3.147584
 spn 2 0    0.000000   -1.307561    3.147584    3.105257    3.147584    3.147584
 3     0    0.000000   -0.839006    4.102416    4.093122    4.102416    4.102416
 spn 2 0    0.000000   -0.839006    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -3.095187  val*vef=     -13.509117   sumtv=      10.413930
 sumec=      -40.764067  cor*vef=    -103.768816   ttcor=      63.004749
 rhoeps=      -8.860012     utot=    -139.001107    ehar=     -74.442440

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00    0.00     0.00    0.00    0.00     0.00    0.00   -0.00
 shift forces to make zero average correction:            0.00    0.00   -0.00

 srhov:    -31.869499     17.912544    -13.956954 sumev=   -3.095187   sumtv=   10.861767
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.065749   -3.777980     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.112418  avg sphere pot= 0.011077  vconst= 0.112418
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.579823   charge     7.777980
 smooth rhoeps =   -7.710997 (  -5.080564,  -2.630433)
         rhomu =  -10.098568 (  -7.011996,  -3.086572)
       avg vxc =   -0.156049 (  -0.171721,  -0.140378)
 smooth rhoeps =   -7.710997 (  -5.080564,  -2.630433)
         rhomu =  -10.098568 (  -7.011996,  -3.086572)
       avg vxc =   -0.156049 (  -0.171721,  -0.140378)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.957837   -4.844827  -13.802663    -18.733716   -9.405230  -28.138946

 local terms:     true           smooth         local
 rhoeps:        -8.861625      -7.695621      -1.166004
 rhomu:         -6.456364      -6.997663       0.541300
 spin2:         -5.208492      -3.080992      -2.127500
 total:        -11.664855     -10.078656      -1.586200
 val*vef       -13.802663     -14.004360       0.201696
 val chg:        2.906931       6.684911      -3.777980
 val mom:        0.962514       2.211821      -1.249306    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -28.151096        14.336253       -13.814843
   rhoval*ves             -3.805554        -6.732000       -10.537554
   psnuc*ves              14.965199      -283.260295      -268.295096
   utot                    5.579823      -144.996147      -139.416325
   rho*exc                -7.710997        -1.166004        -8.877002
   rho*vxc               -10.098568        -1.586200       -11.684767
   valence chg             6.777980        -3.777980         3.000000
   valence mag             2.249306        -1.249306         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.861767  sumtc=        62.989212   ekin=       73.850979
 rhoep=       -8.877002   utot=      -139.416325   ehks=      -74.442347
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.118694D+04-0.262750D-26 0.118694D+04       0
 mixrho: sum smrnew new  = 0.564205D+03-0.412100D-16 0.564205D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns= -0.86255D-01  0.10301D+01 -0.11699D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=8.31e-1  last it=1.21e0
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=4.16e-1
   tj:-1.58546  -0.24108
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  8.65741873660397232E-004  4.32870936830198688E-007
 add q=  0.000866 to preserve neutrality
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       75675 -2.75613969697860275E-006

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=       0.552460   ehk=       0.552553
 From last iter    ehf=       0.570793   ehk=       0.553297
 diffe(q)= -0.018333 (0.831090)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5524601 ehk=.5525528

 --- BNDFP:  begin iteration 5 of 10 ---
 all smrho is positive for isp=           1
 mkpot negative smrho; isp,number,min(smrho)=           2       75675 -2.75613969697860275E-006
 enforce positive smrho, to which we add srshift=  2.75613970697860258E-006

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.044843   -3.703873     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111876  avg sphere pot= 0.010844  vconst= 0.111876
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.706413   charge     7.709385
 smooth rhoeps =   -7.669669 (  -5.524062,  -2.145607)
         rhomu =  -10.050593 (  -7.674751,  -2.375842)
       avg vxc =   -0.157024 (  -0.182165,  -0.131884)
 smooth rhoeps =   -7.669669 (  -5.524062,  -2.145607)
         rhomu =  -10.050593 (  -7.674751,  -2.375842)
       avg vxc =   -0.157024 (  -0.182165,  -0.131884)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       864
 vxcnsp (warning): negative rho: min val =  -2.47E-02
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.069548   -3.767932  -13.837480    -20.183929   -7.647617  -27.831546

 local terms:     true           smooth         local
 rhoeps:        -8.908031      -7.653257      -1.254774
 rhomu:         -6.825836      -7.656635       0.830798
 spin2:         -4.902684      -2.372702      -2.529982
 total:        -11.728520     -10.029336      -1.699184
 val*vef       -13.837480     -13.843127       0.005648
 val chg:        2.909441       6.613313      -3.703873
 val mom:        1.492912       3.074028      -1.581116    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.926471 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.755377    7.839618    0.074636   -0.650553
 1      3.000000    1.000000    -5.887832    7.334385    0.123595   -0.611918
 2      3.000000    1.000000     6.000000   28.695818    0.486690   -0.090530
 3      3.000000    1.000000     9.000000   39.609637    0.566954   -0.057620

 potpus  spin 2 : pnu = 2.922317 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.047584    7.633656    0.082130   -0.618641
 1      3.000000    1.000000    -5.887832    7.236057    0.133399   -0.571193
 2      3.000000    1.000000     6.000000   29.085804    0.488922   -0.088594
 3      3.000000    1.000000     9.000000   39.823121    0.567921   -0.057124

 Energy terms:             smooth           local           total
   rhoval*vef            -27.844803        13.994036       -13.850767
   rhoval*ves             -3.693946        -6.811636       -10.505581
   psnuc*ves              15.106771      -283.384503      -268.277731
   utot                    5.706413      -145.098069      -139.391656
   rho*exc                -7.669669        -1.254774        -8.924443
   rho*vxc               -10.050593        -1.699184       -11.749777
   valence chg             6.709385        -3.703873         3.005512
   valence mag             3.138835        -1.581116         1.557719
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00551   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00551
 (warning) system not neutral, dq=0.005512

 Read qp weights ...  ef=-0.651739
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2645 -0.6416 -0.6416 -0.6416  0.2727  0.6394  0.6394  0.6394
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0579 -0.4351 -0.4351 -0.4351  0.3315  0.7101  0.7101  0.7101
 Est Ef = -0.652 < evl(3)=-0.642 ... using qval=3.0, revise to -0.6416
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.641842;   3.000000 electrons
         Sum occ. bands:   -2.964107, incl. Bloechl correction: -0.000020
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905606    6.882903   -3.977298      0.964631    2.104753   -1.140122
       contr. to mm extrapolated for r>rmt:   0.029977 est. true mm = 0.994608
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.29945  sum tc=    31.39795  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.22553  sum tc=    31.56366  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.977021   -1.262683    2.926471    2.926288    2.500000    2.926288
 spn 2 0    0.970487   -1.055735    2.922317    2.922373    2.500000    2.922373
 1     1    0.958097   -0.637074    2.850000    2.915000    2.250000    2.850000
 spn 2 1    0.000000   -0.414204    2.850000    2.920896    2.250000    2.850000
 2     0    0.000000   -0.867954    3.147584    3.127886    3.147584    3.147584
 spn 2 0    0.000000   -1.247648    3.147584    3.105232    3.147584    3.147584
 3     0    0.000000   -0.846973    4.102416    4.092841    4.102416    4.102416
 spn 2 0    0.000000   -0.846973    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.964107  val*vef=     -13.850767   sumtv=      10.886660
 sumec=      -40.524985  cor*vef=    -103.521918   ttcor=      62.996933
 rhoeps=      -8.924443     utot=    -139.391656    ehar=     -74.432507

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00   -0.00    0.00     0.00    0.00    0.00    -0.00    0.00   -0.00
 shift forces to make zero average correction:           -0.00    0.00   -0.00

 srhov:    -29.053506     15.391195    -13.662311 sumev=   -2.964107   sumtv=   10.698204
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.121975   -3.977298     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111737  avg sphere pot= 0.010665  vconst= 0.111737
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.814785   charge     7.977298
 smooth rhoeps =   -7.986300 (  -5.157449,  -2.828851)
         rhomu =  -10.458712 (  -7.099998,  -3.358714)
       avg vxc =   -0.156743 (  -0.171441,  -0.142046)
 smooth rhoeps =   -7.986300 (  -5.157449,  -2.828851)
         rhomu =  -10.458712 (  -7.099998,  -3.358714)
       avg vxc =   -0.156743 (  -0.171441,  -0.142046)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.941374   -4.726435  -13.667809    -19.110838  -10.238713  -29.349551

 local terms:     true           smooth         local
 rhoeps:        -8.843475      -7.970600      -0.872875
 rhomu:         -6.446845      -7.085668       0.638823
 spin2:         -5.194089      -3.352715      -1.841374
 total:        -11.640934     -10.438383      -1.202551
 val*vef       -13.667809     -14.182209       0.514400
 val chg:        2.905606       6.882903      -3.977298
 val mom:        0.964631       2.104753      -1.140122    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.362073        15.681710       -13.680363
   rhoval*ves             -3.624314        -6.797427       -10.421740
   psnuc*ves              15.253883      -283.318801      -268.064917
   utot                    5.814785      -145.058114      -139.243329
   rho*exc                -7.986300        -0.872875        -8.859175
   rho*vxc               -10.458712        -1.202551       -11.661263
   valence chg             6.977298        -3.977298         3.000000
   valence mag             2.140122        -1.140122         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.698204  sumtc=        62.961610   ekin=       73.659813
 rhoep=       -8.859175   utot=      -139.243329   ehks=      -74.442691
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.615514D+03 0.195854D-26 0.615514D+03       0
 mixrho: sum smrnew new  = 0.569839D+03 0.938548D-16 0.569839D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns=  0.26791D-03  0.49772D-02  0.32712D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=3.63e-3  last it=8.31e-1
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=1.82e-3
   tj:-3.48470   2.40588
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -7.54001260771453019E-003 -3.77000630385726596E-006
 add q= -0.007540 to preserve neutrality
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       16901 -4.50131244976579418E-007

 iors  : write restart file (binary, mesh density) 

   it  5  of 10    ehf=       0.562393   ehk=       0.552209
 From last iter    ehf=       0.552460   ehk=       0.552553
 diffe(q)=  0.009933 (0.003634)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5623929 ehk=.5522095

 --- BNDFP:  begin iteration 6 of 10 ---
 all smrho is positive for isp=           1
 mkpot negative smrho; isp,number,min(smrho)=           2       16901 -4.50131244976579418E-007
 enforce positive smrho, to which we add srshift=  4.50131254976579401E-007

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.217044   -4.314309     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111702  avg sphere pot= 0.010678  vconst= 0.111702
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.792076   charge     8.315209
 smooth rhoeps =   -8.569528 (  -5.267470,  -3.302058)
         rhomu =  -11.223089 (  -7.194753,  -4.028336)
       avg vxc =   -0.157303 (  -0.172323,  -0.142283)
 smooth rhoeps =   -8.569528 (  -5.267470,  -3.302058)
         rhomu =  -11.223089 (  -7.194753,  -4.028336)
       avg vxc =   -0.157303 (  -0.172323,  -0.142283)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       224
 vxcnsp (warning): negative rho: min val =  -1.64E-03
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.012651   -4.666910  -13.679561    -19.288160  -12.107332  -31.395492

 local terms:     true           smooth         local
 rhoeps:        -8.847956      -8.553667      -0.294289
 rhomu:         -6.473308      -7.180082       0.706774
 spin2:         -5.173669      -4.022468      -1.151201
 total:        -11.646977     -11.202550      -0.444427
 val*vef       -13.679561     -14.968297       1.288735
 val chg:        2.905889       7.220197      -4.314309
 val mom:        1.000372       1.844441      -0.844069    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.926288 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.722395    7.820994    0.075028   -0.648782
 1      3.000000    1.000000    -5.887832    7.321684    0.124185   -0.609597
 2      3.000000    1.000000     6.000000   28.729357    0.486896   -0.090358
 3      3.000000    1.000000     9.000000   39.629666    0.567049   -0.057573

 potpus  spin 2 : pnu = 2.922373 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.056701    7.685082    0.080935   -0.625850
 1      3.000000    1.000000    -5.887832    7.248871    0.131053   -0.580852
 2      3.000000    1.000000     6.000000   29.004071    0.488461   -0.088993
 3      3.000000    1.000000     9.000000   39.778958    0.567721   -0.057226

 Energy terms:             smooth           local           total
   rhoval*vef            -31.408196        17.715894       -13.692302
   rhoval*ves             -3.646246        -6.782505       -10.428752
   psnuc*ves              15.230398      -283.340081      -268.109683
   utot                    5.792076      -145.061293      -139.269218
   rho*exc                -8.569528        -0.294289        -8.863817
   rho*vxc               -11.223089        -0.444427       -11.667516
   valence chg             7.315209        -4.314309         3.000900
   valence mag             1.881711        -0.844069         1.037643
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00090   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00090

 Read qp weights ...  ef=-0.641842
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2469 -0.6238 -0.6238 -0.6238  0.2820  0.6478  0.6478  0.6478
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1105 -0.4876 -0.4876 -0.4876  0.3160  0.6888  0.6888  0.6888
 Est Ef = -0.642 < evl(3)=-0.624 ... using qval=3.0, revise to -0.6238
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.624138;   3.000000 electrons
         Sum occ. bands:   -2.981415, incl. Bloechl correction: -0.000021
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905879    6.935885   -4.030005      0.961610    1.959367   -0.997757
       contr. to mm extrapolated for r>rmt:   0.032801 est. true mm = 0.994411
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31399  sum tc=    31.42715  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26465  sum tc=    31.53749  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976624   -1.245102    2.926288    2.926003    2.500000    2.926003
 spn 2 0    0.972134   -1.108493    2.922373    2.923288    2.500000    2.923288
 1     1    0.957120   -0.619328    2.850000    2.914571    2.250000    2.850000
 spn 2 1    0.000000   -0.460228    2.850000    2.928008    2.250000    2.850000
 2     0    0.000001   -0.854776    3.147584    3.128105    3.147584    3.147584
 spn 2 0    0.000000   -1.284634    3.147584    3.104819    3.147584    3.147584
 3     0    0.000000   -0.832162    4.102416    4.092991    4.102416    4.102416
 spn 2 0    0.000000   -0.832162    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.981415  val*vef=     -13.692302   sumtv=      10.710887
 sumec=      -40.578640  cor*vef=    -103.557922   ttcor=      62.979281
 rhoeps=      -8.863817     utot=    -139.269218    ehar=     -74.442866

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00    0.00     0.00    0.00    0.00     0.00    0.00   -0.00
 shift forces to make zero average correction:            0.00    0.00   -0.00

 srhov:    -29.811448     16.097305    -13.714144 sumev=   -2.981415   sumtv=   10.732729
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.136844   -4.030005     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111798  avg sphere pot= 0.010672  vconst= 0.111798
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.797976   charge     8.030005
 smooth rhoeps =   -8.067364 (  -5.095999,  -2.971366)
         rhomu =  -10.564225 (  -6.991682,  -3.572543)
       avg vxc =   -0.156594 (  -0.172062,  -0.141125)
 smooth rhoeps =   -8.067364 (  -5.095999,  -2.971366)
         rhomu =  -10.564225 (  -6.991682,  -3.572543)
       avg vxc =   -0.156594 (  -0.172062,  -0.141125)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.910098   -4.787610  -13.697707    -18.815001  -10.833729  -29.648729

 local terms:     true           smooth         local
 rhoeps:        -8.846152      -8.051707      -0.794445
 rhomu:         -6.443658      -6.977042       0.533384
 spin2:         -5.200773      -3.566907      -1.633865
 total:        -11.644431     -10.543949      -1.100482
 val*vef       -13.697707     -14.300999       0.603291
 val chg:        2.905879       6.935885      -4.030005
 val mom:        0.961610       1.959367      -0.997757    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.661195        15.950989       -13.710207
   rhoval*ves             -3.637476        -6.811367       -10.448842
   psnuc*ves              15.233427      -283.341497      -268.108070
   utot                    5.797976      -145.076432      -139.278456
   rho*exc                -8.067364        -0.794445        -8.861810
   rho*vxc               -10.564225        -1.100482       -11.664706
   valence chg             7.030005        -4.030005         3.000000
   valence mag             1.997757        -0.997757         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.732729  sumtc=        62.964645   ekin=       73.697374
 rhoep=       -8.861810   utot=      -139.278456   ehks=      -74.442892
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.574808D+03 0.165442D-25 0.574808D+03       0
 mixrho: sum smrnew new  = 0.564235D+03 0.487283D-16 0.564235D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns= -0.28520D-03  0.28669D-02 -0.17161D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=2.34e-3  last it=3.63e-3
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=1.17e-3
   tj:-0.15240  -0.00374
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  3.24387994780295230E-004  1.62193997390147656E-007
 add q=  0.000324 to preserve neutrality
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  6  of 10    ehf=       0.552034   ehk=       0.552008
 From last iter    ehf=       0.562393   ehk=       0.552209
 diffe(q)= -0.010359 (0.002341)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5520339 ehk=.5520081

 --- BNDFP:  begin iteration 7 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.146279   -4.063454     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111749  avg sphere pot= 0.010649  vconst= 0.111749
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.812563   charge     8.063454
 smooth rhoeps =   -8.121252 (  -5.116002,  -3.005250)
         rhomu =  -10.634857 (  -7.016976,  -3.617881)
       avg vxc =   -0.156920 (  -0.171590,  -0.142250)
 smooth rhoeps =   -8.121252 (  -5.116002,  -3.005250)
         rhomu =  -10.634857 (  -7.016976,  -3.617881)
       avg vxc =   -0.156920 (  -0.171590,  -0.142250)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.879928   -4.800325  -13.680253    -18.900227  -10.954709  -29.854936

 local terms:     true           smooth         local
 rhoeps:        -8.843634      -8.105569      -0.738065
 rhomu:         -6.432225      -7.002553       0.570328
 spin2:         -5.208832      -3.611996      -1.596836
 total:        -11.641057     -10.614549      -1.026508
 val*vef       -13.680253     -14.360955       0.680702
 val chg:        2.905671       6.969125      -4.063454
 val mom:        0.943680       1.938163      -0.994483    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.926003 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.671615    7.819095    0.075301   -0.648097
 1      3.000000    1.000000    -5.887832    7.319440    0.124367   -0.608809
 2      3.000000    1.000000     6.000000   28.736698    0.486937   -0.090321
 3      3.000000    1.000000     9.000000   39.633537    0.567066   -0.057564

 potpus  spin 2 : pnu = 2.923288 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.206241    7.681848    0.080179   -0.627103
 1      3.000000    1.000000    -5.887832    7.251196    0.130758   -0.582059
 2      3.000000    1.000000     6.000000   28.992953    0.488398   -0.089047
 3      3.000000    1.000000     9.000000   39.772986    0.567694   -0.057240

 Energy terms:             smooth           local           total
   rhoval*vef            -29.867427        16.174650       -13.692778
   rhoval*ves             -3.626873        -6.808213       -10.435087
   psnuc*ves              15.251999      -283.353987      -268.101988
   utot                    5.812563      -145.081100      -139.268537
   rho*exc                -8.121252        -0.738065        -8.859317
   rho*vxc               -10.634857        -1.026508       -11.661365
   valence chg             7.063454        -4.063454         3.000000
   valence mag             1.974456        -0.994483         0.979973
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.624138
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2436 -0.6206 -0.6206 -0.6206  0.2830  0.6489  0.6489  0.6489
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1154 -0.4924 -0.4924 -0.4924  0.3159  0.6882  0.6882  0.6882
 Est Ef = -0.624 < evl(3)=-0.621 ... using qval=3.0, revise to -0.6206
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.620849;   3.000000 electrons
         Sum occ. bands:   -2.979782, incl. Bloechl correction: -0.000021
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905705    6.940747   -4.035041      0.961012    1.936706   -0.975694
       contr. to mm extrapolated for r>rmt:   0.033346 est. true mm = 0.994358
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31277  sum tc=    31.42996  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26664  sum tc=    31.53388  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976516   -1.241842    2.926003    2.925935    2.500000    2.925935
 spn 2 0    0.972346   -1.113434    2.923288    2.923410    2.500000    2.923410
 1     1    0.956842   -0.616032    2.850000    2.914458    2.250000    2.850000
 spn 2 1    0.000000   -0.464059    2.850000    2.929064    2.250000    2.850000
 2     0    0.000001   -0.852836    3.147584    3.128162    3.147584    3.147584
 spn 2 0    0.000000   -1.287658    3.147584    3.104759    3.147584    3.147584
 3     0    0.000000   -0.829738    4.102416    4.093030    4.102416    4.102416
 spn 2 0    0.000000   -0.829738    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.979782  val*vef=     -13.692778   sumtv=      10.712996
 sumec=      -40.579416  cor*vef=    -103.551379   ttcor=      62.971963
 rhoeps=      -8.859317     utot=    -139.268537    ehar=     -74.442896

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00    0.00     0.00    0.00    0.00     0.00   -0.00   -0.00
 shift forces to make zero average correction:            0.00   -0.00   -0.00

 srhov:    -29.724903     16.013820    -13.711084 sumev=   -2.979782   sumtv=   10.731302
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.138264   -4.035041     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111807  avg sphere pot= 0.010671  vconst= 0.111807
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.798745   charge     8.035041
 smooth rhoeps =   -8.073302 (  -5.082703,  -2.990599)
         rhomu =  -10.571879 (  -6.969602,  -3.602277)
       avg vxc =   -0.156659 (  -0.172270,  -0.141048)
 smooth rhoeps =   -8.073302 (  -5.082703,  -2.990599)
         rhomu =  -10.571879 (  -6.969602,  -3.602277)
       avg vxc =   -0.156659 (  -0.172270,  -0.141048)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.901296   -4.795719  -13.697015    -18.759053  -10.918195  -29.677248

 local terms:     true           smooth         local
 rhoeps:        -8.845600      -8.057607      -0.787992
 rhomu:         -6.442118      -6.954869       0.512752
 spin2:         -5.201580      -3.596687      -1.604893
 total:        -11.643698     -10.551556      -1.092141
 val*vef       -13.697015     -14.308713       0.611698
 val chg:        2.905705       6.940747      -4.035041
 val mom:        0.961012       1.936706      -0.975694    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.689738        15.980201       -13.709537
   rhoval*ves             -3.637549        -6.811202       -10.448751
   psnuc*ves              15.235038      -283.339796      -268.104757
   utot                    5.798745      -145.075499      -139.276754
   rho*exc                -8.073302        -0.787992        -8.861294
   rho*vxc               -10.571879        -1.092141       -11.664020
   valence chg             7.035041        -4.035041         3.000000
   valence mag             1.975694        -0.975694         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.731302  sumtc=        62.963840   ekin=       73.695142
 rhoep=       -8.861294   utot=      -139.276754   ehks=      -74.442907
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.564869D+03-0.387390D-26 0.564869D+03       0
 mixrho: sum smrnew new  = 0.563171D+03-0.582317D-16 0.563171D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns= -0.28413D-04  0.28567D-03 -0.51499D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=2.43e-4  last it=2.34e-3
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=1.21e-4
   tj:-0.04689  -0.02195
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  8.17466580311787538E-005  4.08733290155893838E-008
 add q=  0.000082 to preserve neutrality
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  7  of 10    ehf=       0.552004   ehk=       0.551993
 From last iter    ehf=       0.552034   ehk=       0.552008
 diffe(q)= -0.000030 (0.000243)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5520043 ehk=.5519933

 --- BNDFP:  begin iteration 8 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.141938   -4.048065     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111779  avg sphere pot= 0.010657  vconst= 0.111779
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.807149   charge     8.048065
 smooth rhoeps =   -8.093471 (  -5.090585,  -3.002886)
         rhomu =  -10.598298 (  -6.980043,  -3.618254)
       avg vxc =   -0.156952 (  -0.171895,  -0.142010)
 smooth rhoeps =   -8.093471 (  -5.090585,  -3.002886)
         rhomu =  -10.598298 (  -6.980043,  -3.618254)
       avg vxc =   -0.156952 (  -0.171895,  -0.142010)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.873839   -4.813559  -13.687398    -18.801252  -10.956132  -29.757384

 local terms:     true           smooth         local
 rhoeps:        -8.843966      -8.077779      -0.766187
 rhomu:         -6.431867      -6.965495       0.533628
 spin2:         -5.209625      -3.612483      -1.597141
 total:        -11.641492     -10.577978      -1.063513
 val*vef       -13.687398     -14.328709       0.641311
 val chg:        2.905639       6.953704      -4.048065
 val mom:        0.944936       1.924790      -0.979855    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.925935 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.659650    7.818815    0.075366   -0.647922
 1      3.000000    1.000000    -5.887832    7.319118    0.124410   -0.608611
 2      3.000000    1.000000     6.000000   28.738052    0.486943   -0.090315
 3      3.000000    1.000000     9.000000   39.634127    0.567068   -0.057562

 potpus  spin 2 : pnu = 2.923410 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.226592    7.681253    0.080078   -0.627271
 1      3.000000    1.000000    -5.887832    7.251413    0.130723   -0.582205
 2      3.000000    1.000000     6.000000   28.991778    0.488393   -0.089053
 3      3.000000    1.000000     9.000000   39.772535    0.567693   -0.057240

 Energy terms:             smooth           local           total
   rhoval*vef            -29.769871        16.069953       -13.699917
   rhoval*ves             -3.631152        -6.810422       -10.441573
   psnuc*ves              15.245450      -283.347906      -268.102456
   utot                    5.807149      -145.079164      -139.272015
   rho*exc                -8.093471        -0.766187        -8.859657
   rho*vxc               -10.598298        -1.063513       -11.661811
   valence chg             7.048065        -4.048065         3.000000
   valence mag             1.962148        -0.979855         0.982294
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.620849
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2433 -0.6203 -0.6203 -0.6203  0.2828  0.6487  0.6487  0.6487
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1152 -0.4922 -0.4922 -0.4922  0.3163  0.6886  0.6886  0.6886
 Est Ef = -0.621 < evl(3)=-0.620 ... using qval=3.0, revise to -0.6203
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.620582;   3.000000 electrons
         Sum occ. bands:   -2.979048, incl. Bloechl correction: -0.000021
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905642    6.940152   -4.034510      0.960907    1.935133   -0.974226
       contr. to mm extrapolated for r>rmt:   0.033439 est. true mm = 0.994346
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31203  sum tc=    31.42980  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26610  sum tc=    31.53371  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976493   -1.241573    2.925935    2.925923    2.500000    2.925923
 spn 2 0    0.972367   -1.113236    2.923410    2.923419    2.500000    2.923419
 1     1    0.956781   -0.615762    2.850000    2.914436    2.250000    2.850000
 spn 2 1    0.000000   -0.463718    2.850000    2.929172    2.250000    2.850000
 2     0    0.000001   -0.852908    3.147584    3.128172    3.147584    3.147584
 spn 2 0    0.000000   -1.287146    3.147584    3.104755    3.147584    3.147584
 3     0    0.000000   -0.829750    4.102416    4.093036    4.102416    4.102416
 spn 2 0    0.000000   -0.829750    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.979048  val*vef=     -13.699917   sumtv=      10.720870
 sumec=      -40.578130  cor*vef=    -103.546031   ttcor=      62.967901
 rhoeps=      -8.859657     utot=    -139.272015    ehar=     -74.442901

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00    0.00     0.00    0.00    0.00     0.00   -0.00   -0.00
 shift forces to make zero average correction:            0.00   -0.00   -0.00

 srhov:    -29.704385     15.995411    -13.708974 sumev=   -2.979048   sumtv=   10.729926
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.138114   -4.034510     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111809  avg sphere pot= 0.010670  vconst= 0.111809
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.799380   charge     8.034510
 smooth rhoeps =   -8.071893 (  -5.080672,  -2.991221)
         rhomu =  -10.570018 (  -6.966531,  -3.603487)
       avg vxc =   -0.156685 (  -0.172322,  -0.141048)
 smooth rhoeps =   -8.071893 (  -5.080672,  -2.991221)
         rhomu =  -10.570018 (  -6.966531,  -3.603487)
       avg vxc =   -0.156685 (  -0.172322,  -0.141048)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.899280   -4.796718  -13.695999    -18.751725  -10.922318  -29.674043

 local terms:     true           smooth         local
 rhoeps:        -8.845352      -8.056186      -0.789166
 rhomu:         -6.441686      -6.951778       0.510092
 spin2:         -5.201685      -3.597901      -1.603784
 total:        -11.643370     -10.549679      -1.093692
 val*vef       -13.695999     -14.306549       0.610550
 val chg:        2.905642       6.940152      -4.034510
 val mom:        0.960907       1.935133      -0.974226    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.686542        15.978012       -13.708530
   rhoval*ves             -3.637253        -6.810750       -10.448003
   psnuc*ves              15.236012      -283.338570      -268.102558
   utot                    5.799380      -145.074660      -139.275280
   rho*exc                -8.071893        -0.789166        -8.861059
   rho*vxc               -10.570018        -1.093692       -11.663709
   valence chg             7.034510        -4.034510         3.000000
   valence mag             1.974226        -0.974226         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.729926  sumtc=        62.963503   ekin=       73.693429
 rhoep=       -8.861059   utot=      -139.275280   ehks=      -74.442910
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.563138D+03 0.100223D-25 0.563138D+03       0
 mixrho: sum smrnew new  = 0.563046D+03 0.151009D-16 0.563046D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns= -0.13555D-04  0.13312D-03 -0.74467D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.14e-4  last it=2.43e-4
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=5.69e-5
   tj:-0.72714  -0.00378
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  1.83979526013899886E-006  9.19897630069499598E-010
 add q=  0.000002 to preserve neutrality
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  8  of 10    ehf=       0.551999   ehk=       0.551990
 From last iter    ehf=       0.552004   ehk=       0.551993
 diffe(q)= -0.000006 (0.000114)    tol= 0.000010 (0.000500)   more=F
c zbak=1 mmom=.9999997 ehf=.5519987 ehk=.5519901
 Exit 0 LMF 
