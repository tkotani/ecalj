rdcmd:  lmfa --no-iactiv c -vzbak=0
 -----------------------  START LMFA (80000K)  -----------------------
 HEADER sc C atom

 LMFA:     alat = 7.93701  nbas = 1  nspec = 1  vn 7.00(LMFA 7.0)  verb 30,40,|
 pot:      spin-pol, XC:BH

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753711   qtot  1.997282
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 Exit 0 LMFA 
 CPU time:    0.543s     Fri Feb 20 17:31:39 2009   on waldo.eas.asu.edu
 wkinfo:  used   101 K  workspace of 80000 K   in   0 K calls
rdcmd:  lmf  --no-iactiv c -vzbak=0
 -----------------------  START LMF (80000K)  -----------------------
 HEADER sc C atom

 LMF:      alat = 7.93701  nbas = 1  nspec = 1  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 GVLIST: gmax = 13.99 a.u. created 45911 vectors of 125000 (36%)
         mesh has 50 x 50 x 50 divisions; length 0.224, 0.224, 0.224
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363589    3.701843    2.363564    1.338280
 amom    1.810990    1.143834    1.810990    1.143833    0.667157

 Smooth charge on mesh:            2.661720    moment    1.332843
 Sum of local charges:             1.338280    moments   0.667157
 Total valence charge:             4.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           0.000000
 Deviation from neutrality:        0.000000

 --- BNDFP:  begin iteration 1 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338280     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.063913   charge     2.661720
 smooth rhoeps =   -1.494903 (  -1.109322,  -0.385581)
         rhomu =   -1.946553 (  -1.522783,  -0.423770)
       avg vxc =   -0.191348 (  -0.218128,  -0.164568)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.341410   -3.941483  -14.282893     -2.908182   -0.943828   -3.852010

 local terms:     true           smooth         local
 rhoeps:        -9.536045      -1.428953      -8.107092
 rhomu:         -7.422765      -1.450798      -5.971967
 spin2:         -5.125221      -0.410320      -4.714900
 total:        -12.547986      -1.861118     -10.686867
 val*vef       -14.282893      -6.925500      -7.357392
 val chg:        3.701843       2.363564       1.338280
 val mom:        1.810990       1.143833       0.667157    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000
 l        enu         v           c          srdel        qpar        ppar
 0     -1.054715   -1.268528   -1.158163    0.198868      2.7906    0.901141
 1     -0.471084   -1.054270   -0.468773    0.175050     19.1074    0.930214
 2     -0.328679   -0.621646    1.519432    0.353874     17.0973    6.142397
 3     -0.115033   -0.556834    3.369830    0.400985     24.4205   10.664440

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.589352    0.102212   -0.581577
 1      3.000000    1.000000    -5.887832    7.119796    0.144160   -0.533282
 2      3.000000    1.000000     4.727244   27.134665    0.465946   -0.095778
 3      3.000000    1.000000     7.577135   37.213691    0.543677   -0.062061

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000
 l        enu         v           c          srdel        qpar        ppar
 0     -0.846590   -1.087566   -0.962512    0.211082      2.8067    0.936237
 1     -0.269118   -0.929135   -0.266498    0.186383     19.0749    0.984262
 2     -0.216979   -0.512409    1.659287    0.357600     16.9824    6.304590
 3     -0.011628   -0.454896    3.495411    0.402800     24.3466   10.791136

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.437705    0.107908   -0.555887
 1      3.000000    1.000000    -5.887832    7.130043    0.153492   -0.500465
 2      3.000000    1.000000     4.727244   27.482684    0.468116   -0.093876
 3      3.000000    1.000000     7.577135   37.415022    0.544672   -0.061530

 Energy terms:             smooth           local           total
   rhoval*vef             -3.931620       -10.430878       -14.362499
   rhoval*ves             -5.058553        -5.181774       -10.240327
   psnuc*ves               9.186379      -278.836578      -269.650199
   utot                    2.063913      -142.009176      -139.945263
   rho*exc                -1.494903        -8.107092        -9.601995
   rho*vxc                -1.946553       -10.686867       -12.633421
   valence chg             2.661720         1.338280         4.000000
   valence mag             1.332843         0.667157         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...
 Start second band pass ...
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4290

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686856    3.838083   -0.151227      1.796589    2.141131   -0.344542
       contr. to mm extrapolated for r>rmt:   0.163680 est. true mm = 1.960270

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.957935   -1.040174    2.900000    2.913380    2.500000    2.913380
 spn 2 0    0.945133   -0.837598    2.900000    2.907600    2.500000    2.907600
 1     1    1.783776   -0.432708    2.850000    2.886376    2.250000    2.850000
 spn 2 1    0.000000   -0.837769    2.850000    2.228737    2.250000    2.850000
 2     0    0.000011   -0.435910    3.180000    3.166283    3.147584    3.166283
 spn 2 0    0.000000   -0.837563    3.180000    3.124651    3.147584    3.147584
 3     0    0.000001   -0.441835    4.120000    4.106334    4.102416    4.106334
 spn 2 0    0.000000   -0.837445    4.120000    4.091601    4.102416    4.102416

 Harris energy:
 sumev=       -2.743233  val*vef=     -14.362499   sumtv=      11.619265
 sumec=      -39.640777  cor*vef=    -102.572782   ttcor=      62.932005
 rhoeps=      -9.601995     utot=    -139.945263    ehar=     -74.995989

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -7.491271     -6.856024    -14.347295 sumev=   -2.743233   sumtv=   11.604061

 Kohn-Sham energy:
 sumtv=       11.604061  sumtc=        62.932006   ekin=       74.536067
 rhoep=       -9.592116   utot=      -139.940096   ehks=      -74.996145
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=1.35e-2
 mixrho: (warning) scr. and lin-mixed densities had 1625 and 405 negative points
 AMIX: nmix=0 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=6.75e-3
 unscreened rms difference:  smooth  0.010354   local  0.036279
   screened rms difference:  smooth  0.010366   local  0.036279   tot  0.013495

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=      -0.001089   ehk=      -0.001245
h zbak=0 mmom=1.9999996 ehf=-.0010887 ehk=-.0012453

 --- BNDFP:  begin iteration 2 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.167431    0.593526     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008356  avg sphere pot= 0.016799  vconst=-0.008356
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.743364   charge     3.406474
 smvxcm (warning) mesh density negative at 37543 points:  rhomin=-5.54e-6
 smooth rhoeps =   -2.247132 (  -1.725337,  -0.521795)
         rhomu =   -2.930651 (  -2.376967,  -0.553684)
       avg vxc =   -0.176671 (  -0.195603,  -0.157740)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336776   -3.945468  -14.282244     -4.949780   -1.314639   -6.264420

 local terms:     true           smooth         local
 rhoeps:        -9.532961      -2.180845      -7.352116
 rhomu:         -7.417504      -2.305477      -5.112028
 spin2:         -5.126437      -0.540186      -4.586251
 total:        -12.543941      -2.845662      -9.698279
 val*vef       -14.282244      -7.814991      -6.467253
 val chg:        3.697600       3.104074       0.593526
 val mom:        1.803790       1.642482       0.161307    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.913380 2.850000 3.166283 4.106334
 l        enu         v           c          srdel        qpar        ppar
 0     -1.040755   -1.271447   -1.159252    0.199919      2.8071    0.892067
 1     -0.471549   -1.053722   -0.469241    0.174921     19.1023    0.929744
 2     -0.435130   -0.620353    1.549507    0.359365     16.8017    6.424329
 3     -0.440848   -0.555136    3.478625    0.412859     23.6640   11.598202

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.750859    7.433920    0.093659   -0.587138
 1      3.000000    1.000000    -5.887832    7.121418    0.144054   -0.533608
 2      3.000000    1.000000     5.210637   28.053455    0.475959   -0.091976
 3      3.000000    1.000000     8.643874   39.422308    0.563199   -0.057686

 potpus  spin 2 : pnu = 2.907600 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -0.838679   -1.090342   -0.963959    0.211794      2.8175    0.930246
 1     -0.270137   -0.929626   -0.267519    0.186317     19.0733    0.983998
 2     -0.512201   -0.512201    1.742491    0.372407     16.2570    7.102011
 3     -0.454507   -0.454507    3.641683    0.418658     23.3691   12.064392

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.042854    7.339636    0.102864   -0.559272
 1      3.000000    1.000000    -5.887832    7.130564    0.153438   -0.500623
 2      3.000000    1.000000     6.000000   29.973160    0.494326   -0.084382
 3      3.000000    1.000000     9.000000   40.379853    0.570594   -0.055847

 Energy terms:             smooth           local           total
   rhoval*vef             -6.343231        -8.017822       -14.361053
   rhoval*ves             -4.963149        -5.280236       -10.243385
   psnuc*ves              10.449878      -280.096509      -269.646631
   utot                    2.743364      -142.688372      -139.945008
   rho*exc                -2.247132        -7.352116        -9.599248
   rho*vxc                -2.930651        -9.698279       -12.628930
   valence chg             3.406474         0.593526         4.000000
   valence mag             1.838692         0.161307         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.430662
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0411 -0.4293 -0.4293 -0.4293  0.1400  0.5311  0.5311  0.5311
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8396 -0.2382 -0.2382 -0.2382  0.2119  0.6260  0.6260  0.6260
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4293

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430819;   4.000000 electrons
         Sum occ. bands:   -2.744302, incl. Bloechl correction: -0.000157
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.692559    3.929938   -0.237379      1.801924    2.217595   -0.415671
       contr. to mm extrapolated for r>rmt:   0.159851 est. true mm = 1.961776

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958124   -1.040653    2.913380    2.913468    2.500000    2.913468
 spn 2 0    0.945317   -0.838583    2.907600    2.907678    2.500000    2.907678
 1     1    1.789106   -0.432513    2.850000    2.886986    2.250000    2.850000
 spn 2 1    0.000000   -0.838749    2.850000    2.228627    2.250000    2.850000
 2     0    0.000011   -0.435897    3.166283    3.166194    3.147584    3.166194
 spn 2 0    0.000000   -0.838550    3.147584    3.124616    3.147584    3.147584
 3     0    0.000001   -0.442092    4.106334    4.106290    4.102416    4.106290
 spn 2 0    0.000000   -0.838436    4.102416    4.091584    4.102416    4.102416

 Harris energy:
 sumev=       -2.744302  val*vef=     -14.361053   sumtv=      11.616751
 sumec=      -39.643187  cor*vef=    -102.575192   ttcor=      62.932005
 rhoeps=      -9.599248     utot=    -139.945008    ehar=     -74.995499

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -8.611944     -5.770037    -14.381981 sumev=   -2.744302   sumtv=   11.637679

 Kohn-Sham energy:
 sumtv=       11.637679  sumtc=        62.931909   ekin=       74.569588
 rhoep=       -9.599619   utot=      -139.966069   ehks=      -74.996101
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=7.65e-3  last it=1.35e-2
 mixrho: (warning) scr. and lin-mixed densities had 321 and 321 negative points
 AMIX: nmix=1 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=3.83e-3
   tj:-1.30814
 unscreened rms difference:  smooth  0.005865   local  0.020518
   screened rms difference:  smooth  0.005867   local  0.020518   tot  0.007653

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=      -0.000599   ehk=      -0.001201
 From last iter    ehf=      -0.001089   ehk=      -0.001245
 diffe(q)=  0.000489 (0.007653)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0005992 ehk=-.0012006

 --- BNDFP:  begin iteration 3 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.103077   -0.365397     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.010114  avg sphere pot= 0.013346  vconst=-0.010114
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.748696   charge     4.365397
 smvxcm (warning) mesh density negative at 32479 points:  rhomin=-8.1e-6
 smooth rhoeps =   -3.351137 (  -2.645608,  -0.705529)
         rhomu =   -4.378301 (  -3.654101,  -0.724199)
       avg vxc =   -0.185829 (  -0.207025,  -0.164634)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.355870   -3.945068  -14.300939     -8.093429   -1.839195   -9.932624

 local terms:     true           smooth         local
 rhoeps:        -9.535851      -3.285667      -6.250184
 rhomu:         -7.421419      -3.583847      -3.837572
 spin2:         -5.126380      -0.710703      -4.415677
 total:        -12.547799      -4.294551      -8.253249
 val*vef       -14.300939      -8.833703      -5.467236
 val chg:        3.694222       4.059618      -0.365397
 val mom:        1.801637       2.306203      -0.504566    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000004

 potpus  spin 1 : pnu = 2.913468 2.850000 3.166194 4.106290
 l        enu         v           c          srdel        qpar        ppar
 0     -1.038125   -1.269065   -1.156805    0.199982      2.8070    0.892483
 1     -0.468951   -1.051263   -0.466641    0.175003     19.0891    0.930511
 2     -0.433476   -0.617893    1.551593    0.359341     16.8010    6.424488
 3     -0.439461   -0.552492    3.480954    0.412852     23.6629   11.598787

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.762386    7.435318    0.093634   -0.586873
 1      3.000000    1.000000    -5.887832    7.125573    0.144121   -0.533190
 2      3.000000    1.000000     5.214024   28.055591    0.475981   -0.091977
 3      3.000000    1.000000     8.647793   39.425588    0.563237   -0.057684

 potpus  spin 2 : pnu = 2.907678 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -0.835879   -1.088238   -0.961545    0.212046      2.8177    0.931131
 1     -0.267516   -0.928315   -0.264891    0.186565     19.0604    0.985562
 2     -0.511149   -0.511149    1.743605    0.372419     16.2565    7.103218
 3     -0.453447   -0.453447    3.642614    0.418650     23.3692   12.064372

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.051844    7.338103    0.102927   -0.558691
 1      3.000000    1.000000    -5.887832    7.134635    0.153642   -0.499802
 2      3.000000    1.000000     6.000000   29.975212    0.494324   -0.084375
 3      3.000000    1.000000     9.000000   40.379530    0.570586   -0.055849

 Energy terms:             smooth           local           total
   rhoval*vef            -10.009707        -4.368316       -14.378023
   rhoval*ves             -4.532486        -5.725789       -10.258275
   psnuc*ves              12.029879      -281.712073      -269.682194
   utot                    3.748696      -143.718931      -139.970234
   rho*exc                -3.351137        -6.250184        -9.601321
   rho*vxc                -4.378301        -8.253249       -12.631549
   valence chg             4.365397        -0.365397         4.000000
   valence mag             2.504566        -0.504566         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.430819
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0386 -0.4267 -0.4267 -0.4267  0.1386  0.5319  0.5319  0.5319
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8370 -0.2357 -0.2357 -0.2357  0.2114  0.6269  0.6269  0.6269
 Est Ef = -0.431 < evl(4)=-0.427 ... using qval=4.0, revise to -0.4267

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.428302;   4.000000 electrons
         Sum occ. bands:   -2.734370, incl. Bloechl correction: -0.000167
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.689968    3.888736   -0.198768      1.799858    2.190827   -0.390970
       contr. to mm extrapolated for r>rmt:   0.161206 est. true mm = 1.961064

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958047   -1.038117    2.913468    2.913475    2.500000    2.913475
 spn 2 0    0.945055   -0.835971    2.907678    2.907603    2.500000    2.907603
 1     1    1.786854   -0.430123    2.850000    2.886777    2.250000    2.850000
 spn 2 1    0.000000   -0.836140    2.850000    2.228988    2.250000    2.850000
 2     0    0.000011   -0.433443    3.166194    3.166198    3.147584    3.166198
 spn 2 0    0.000000   -0.835937    3.147584    3.124705    3.147584    3.147584
 3     0    0.000001   -0.439389    4.106290    4.106292    4.102416    4.106292
 spn 2 0    0.000000   -0.835820    4.102416    4.091622    4.102416    4.102416

 Harris energy:
 sumev=       -2.734370  val*vef=     -14.378023   sumtv=      11.643653
 sumec=      -39.628274  cor*vef=    -102.560231   ttcor=      62.931957
 rhoeps=      -9.601321     utot=    -139.970234    ehar=     -74.995946

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.475297     -4.872167    -14.347463 sumev=   -2.734370   sumtv=   11.613093

 Kohn-Sham energy:
 sumtv=       11.613093  sumtc=        62.929094   ekin=       74.542188
 rhoep=       -9.595126   utot=      -139.943195   ehks=      -74.996133
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=1.55e-3  last it=7.65e-3
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=7.77e-4
   tj: 0.36639  -0.12095
 unscreened rms difference:  smooth  0.001231   local  0.004136
   screened rms difference:  smooth  0.001226   local  0.004136   tot  0.001554

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=      -0.001046   ehk=      -0.001233
 From last iter    ehf=      -0.000599   ehk=      -0.001201
 diffe(q)= -0.000446 (0.001554)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0010456 ehk=-.0012328

 --- BNDFP:  begin iteration 4 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.061889   -0.219391     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.009692  avg sphere pot= 0.013862  vconst=-0.009692
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.589452   charge     4.219391
 smvxcm (warning) mesh density negative at 30407 points:  rhomin=-6.52e-6
 smooth rhoeps =   -3.173560 (  -2.497684,  -0.675876)
         rhomu =   -4.145425 (  -3.448822,  -0.696603)
       avg vxc =   -0.186494 (  -0.208403,  -0.164584)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.348654   -3.944010  -14.292664     -7.582586   -1.751864   -9.334450

 local terms:     true           smooth         local
 rhoeps:        -9.533692      -3.107844      -6.425848
 rhomu:         -7.418881      -3.378100      -4.040781
 spin2:         -5.126068      -0.683141      -4.442927
 total:        -12.544949      -4.061242      -8.483707
 val*vef       -14.292664      -8.687336      -5.605328
 val chg:        3.693802       3.913193      -0.219391
 val mom:        1.801152       2.205129      -0.403976    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000004

 potpus  spin 1 : pnu = 2.913475 2.850000 3.166198 4.106292
 l        enu         v           c          srdel        qpar        ppar
 0     -1.039261   -1.270024   -1.157857    0.199902      2.8069    0.892196
 1     -0.470070   -1.051921   -0.467762    0.174922     19.0916    0.930051
 2     -0.433993   -0.618441    1.550971    0.359331     16.8014    6.423851
 3     -0.439929   -0.553032    3.480389    0.412849     23.6631   11.598394

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.763271    7.435784    0.093594   -0.587082
 1      3.000000    1.000000    -5.887832    7.124782    0.144054   -0.533469
 2      3.000000    1.000000     5.213878   28.054220    0.475975   -0.091983
 3      3.000000    1.000000     8.647566   39.424898    0.563233   -0.057685

 potpus  spin 2 : pnu = 2.907603 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -0.837193   -1.089151   -0.962623    0.211917      2.8174    0.930793
 1     -0.268682   -0.928770   -0.266060    0.186447     19.0639    0.984896
 2     -0.511469   -0.511469    1.743098    0.372396     16.2571    7.102022
 3     -0.453724   -0.453724    3.642216    0.418641     23.3695   12.063577

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.043158    7.340084    0.102923   -0.558925
 1      3.000000    1.000000    -5.887832    7.133516    0.153545   -0.500160
 2      3.000000    1.000000     6.000000   29.972883    0.494313   -0.084385
 3      3.000000    1.000000     9.000000   40.378391    0.570582   -0.055851

 Energy terms:             smooth           local           total
   rhoval*vef             -9.411975        -4.958215       -14.370190
   rhoval*ves             -4.619436        -5.633091       -10.252527
   psnuc*ves              11.798339      -281.462536      -269.664197
   utot                    3.589452      -143.547814      -139.958362
   rho*exc                -3.173560        -6.425848        -9.599407
   rho*vxc                -4.145425        -8.483707       -12.629133
   valence chg             4.219391        -0.219391         4.000000
   valence mag             2.403976        -0.403976         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.428302
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0397 -0.4278 -0.4278 -0.4278  0.1376  0.5311  0.5311  0.5311
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8382 -0.2368 -0.2368 -0.2368  0.2112  0.6265  0.6265  0.6265
 Est Ef = -0.428 < evl(4)=-0.428 ... using qval=4.0, revise to -0.4278

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.429408;   4.000000 electrons
         Sum occ. bands:   -2.738884, incl. Bloechl correction: -0.000167
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.690358    3.893741   -0.203384      1.799978    2.187203   -0.387225
       contr. to mm extrapolated for r>rmt:   0.161112 est. true mm = 1.961090

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958102   -1.039236    2.913475    2.913497    2.500000    2.913497
 spn 2 0    0.945189   -0.837128    2.907603    2.907657    2.500000    2.907657
 1     1    1.787053   -0.431242    2.850000    2.886808    2.250000    2.850000
 spn 2 1    0.000000   -0.837295    2.850000    2.228805    2.250000    2.850000
 2     0    0.000011   -0.434555    3.166198    3.166132    3.147584    3.166132
 spn 2 0    0.000000   -0.837093    3.147584    3.124657    3.147584    3.147584
 3     0    0.000001   -0.440523    4.106292    4.106271    4.102416    4.106271
 spn 2 0    0.000000   -0.836977    4.102416    4.091600    4.102416    4.102416

 Harris energy:
 sumev=       -2.738884  val*vef=     -14.370190   sumtv=      11.631306
 sumec=      -39.634796  cor*vef=    -102.565321   ttcor=      62.930526
 rhoeps=      -9.599407     utot=    -139.958362    ehar=     -74.995938

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.356681     -5.003115    -14.359797 sumev=   -2.738884   sumtv=   11.620913

 Kohn-Sham energy:
 sumtv=       11.620913  sumtc=        62.930428   ekin=       74.551341
 rhoep=       -9.596304   utot=      -139.951163   ehks=      -74.996126
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.85e-4  last it=1.55e-3
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=9.25e-5
   tj: 0.33289   0.08128
 unscreened rms difference:  smooth  0.000128   local  0.000502
   screened rms difference:  smooth  0.000124   local  0.000502   tot  0.000185

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=      -0.001038   ehk=      -0.001226
 From last iter    ehf=      -0.001046   ehk=      -0.001233
 diffe(q)=  0.000008 (0.000185)    tol= 0.000010 (0.000500)   more=F
c zbak=0 mmom=1.9999997 ehf=-.001038 ehk=-.0012261
 Exit 0 LMF 
 CPU time:  100.790s     Fri Feb 20 17:33:22 2009   on waldo.eas.asu.edu
 wkinfo:  used 14914 K  workspace of 80000 K   in  30 K calls
