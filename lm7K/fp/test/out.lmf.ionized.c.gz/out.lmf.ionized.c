rdcmd:  lmfa --no-iactiv c -vzbak=1
HOST_INFORMATION platform: gfortran
HOST_INFORMATION compiler version: gcc version 4.3.4 (Ubuntu 4.3.4-10ubuntu1) 
HOST_INFORMATION FFLAGS (<=120): -O3 -fomit-frame-pointer -funroll-loops -ffast-math -ffixed-line-length-132 -DHASIARGC -DHASGETARG -DFDATE -DHASCPUTIME 
HOST_INFORMATION LIBLOC (<=120): /usr/lib64/libfftw3.a /usr/lib64/liblapack.so.3gf /usr/lib64/libblas.a
HOST_INFORMATION uname -a (<=120): Linux mar 2.6.32-25-generic #45-Ubuntu SMP Sat Oct 16 19:52:42 UTC 2010 x86_64 GNU/Linux
HOST_INFORMATION /etc/issue: Ubuntu 10.04.1 LTS \n \l
HOST_INFORMATION git branch: refs/heads/master
HOST_INFORMATION git commit: d040261476268c1a6f8442f30813ed4c12e48916
HOST_INFORMATION linked at: Sat Nov 13 16:41:48 JST 2010
 -----------------------  START LMFA     -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMFA  vn 7.00(LMFA 7.0)  verb 30,40,60
 pot:      spin-pol, XC:BH
 end of rdctrl2 in imfav7
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137
 goto mksym

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 end of mksym x
 goto defspc
 end of defspc
 goto freeat

conf:SPEC_ATOM= C : --- Table for atomic configuration ---
conf int(P)z = int(P) where P is replaced by PZ if it is semicore
conf:  isp  l  int(P) int(P)z    Qval    Qcore   CoreConf
conf:    1  0       2  2        1.000    1.000 => 1,
conf:    1  1       2  2        2.000    0.000 => 
conf:    1  2       3  3        0.000    0.000 => 
conf:    1  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------
conf:    2  0       2  2        1.000    1.000 => 1,
conf:    2  1       2  2        0.000    0.000 => 
conf:    2  2       3  3        0.000    0.000 => 
conf:    2  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001
 tailsm: init

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
 eee exi=           1  -1.0000000000000000     
 eee exi=           2  -2.0000000000000000     
 eee exi=           3  -4.0000000000000000     
 eee exi=           4  -6.0000000000000000     
 eee exi=           5  -9.0000000000000000     
 eee exi=           6  -15.000000000000000     
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753709   qtot  1.997279
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
 eee exi=           1  -1.0000000000000000     
 eee exi=           2  -2.0000000000000000     
 eee exi=           3  -4.0000000000000000     
 eee exi=           4  -6.0000000000000000     
 eee exi=           5  -9.0000000000000000     
 eee exi=           6  -15.000000000000000     
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 tailsm: end
 end of freats: spid=C       

  Write mtopara.* ...
 Exit 0 LMFA 
rdcmd:  lmf  --no-iactiv c -vzbak=1
HOST_INFORMATION platform: gfortran
HOST_INFORMATION compiler version: gcc version 4.3.4 (Ubuntu 4.3.4-10ubuntu1) 
HOST_INFORMATION FFLAGS (<=120): -O3 -fomit-frame-pointer -funroll-loops -ffast-math -ffixed-line-length-132 -DHASIARGC -DHASGETARG -DFDATE -DHASCPUTIME 
HOST_INFORMATION LIBLOC (<=120): /usr/lib64/libfftw3.a /usr/lib64/liblapack.so.3gf /usr/lib64/libblas.a
HOST_INFORMATION uname -a (<=120): Linux mar 2.6.32-25-generic #45-Ubuntu SMP Sat Oct 16 19:52:42 UTC 2010 x86_64 GNU/Linux
HOST_INFORMATION /etc/issue: Ubuntu 10.04.1 LTS \n \l
HOST_INFORMATION git branch: refs/heads/master
HOST_INFORMATION git commit: d040261476268c1a6f8442f30813ed4c12e48916
HOST_INFORMATION linked at: Sat Nov 13 16:41:48 JST 2010
 -----------------------  START LMF      -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMF  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 
 goto setcg
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 
 lstar xxx=          -2
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F
 lstar xxx=          -2

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 gvlist: cutoff radius  13.994 gives  45911   recips of max 125000
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363587    3.701843    2.363561    1.338282
 amom    1.810990    1.143831    1.810990    1.143831    0.667159
 Uniform density added to neutralize background, q=1.000000

 Smooth charge on mesh:            1.661718    moment    1.332841
 Sum of local charges:             1.338282    moments   0.667159
 Total valence charge:             3.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           1.000000
 Deviation from neutrality:       -0.000000

 --- BNDFP:  begin iteration 1 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       93611 -4.96985036122515704E-004
 mkpot negative smrho; isp,number,min(smrho)=           2      107643 -4.99895726979550110E-004
 enforce positive smrho, to which we add srshift=  4.99895726989550140E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338282     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      2.060608   charge     3.661509
 smooth rhoeps =   -1.494861 (  -1.109298,  -0.385563)
         rhomu =   -1.946499 (  -1.522749,  -0.423750)
       avg vxc =   -0.191138 (  -0.218032,  -0.164244)
 smooth rhoeps =   -1.494861 (  -1.109298,  -0.385563)
         rhomu =   -1.946499 (  -1.522749,  -0.423750)
       avg vxc =   -0.191138 (  -0.218032,  -0.164244)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       128
 vxcnsp (warning): negative rho: min val =  -4.61E-04
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.261804   -3.876233  -14.138038     -2.842621   -0.891813   -3.734435

 local terms:     true           smooth         local
 rhoeps:        -9.464952      -1.364263      -8.100688
 rhomu:         -7.369404      -1.402026      -5.967378
 spin2:         -5.086143      -0.375091      -4.711052
 total:        -12.455547      -1.777117     -10.678430
 val*vef       -14.138038      -6.807929      -7.330109
 val chg:        3.588746       2.250464       1.338282
 val mom:        1.810990       1.143831       0.667159    core:  -0.000000
 core chg:       2.000000       2.000000      -0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.622125    0.101666   -0.583560
 1      3.000000    1.000000    -5.887832    7.139035    0.143256   -0.535856
 2      3.000000    1.000000     4.727244   27.072458    0.465408   -0.096156
 3      3.000000    1.000000     7.577135   37.163437    0.543349   -0.062204

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.498210    0.106861   -0.559304
 1      3.000000    1.000000    -5.887832    7.161455    0.151762   -0.504954
 2      3.000000    1.000000     4.727244   27.365015    0.467061   -0.094577
 3      3.000000    1.000000     7.577135   37.316588    0.544000   -0.061810

 Energy terms:             smooth           local           total
   rhoval*vef             -3.931560       -10.403599       -14.335159
   rhoval*ves             -5.065158        -5.181775       -10.246933
   psnuc*ves               9.186373      -278.836573      -269.650199
   utot                    2.060608      -142.009174      -139.948566
   rho*exc                -1.494861        -8.100688        -9.595549
   rho*vxc                -1.946499       -10.678430       -12.624928
   valence chg             2.661509         1.338282         3.999791
   valence mag             1.332841         0.667159         2.000000
   core charge             2.000000        -0.000000         2.000000

 Charges:  valence     3.99979   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.99979
 (warning) system not neutral, dq=0.999791

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0534 -0.6779 -0.4297 -0.4297 -0.4297  0.2977  0.2977  0.2977
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1365 -0.8248 -0.2365 -0.2365 -0.2365  0.2428  0.2428  0.2428
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 ... only filled or empty bands encountered:  ev=-0.824805  ec=-0.772717
 VBmax = -0.824805  CBmin = -0.772717  gap = 0.052088 Ry = 0.70839 eV
 BZINTS: Fermi energy:     -0.824805;   3.000000 electrons
         Sum occ. bands:   -3.277725, incl. Bloechl correction:  0.000000
         Mag. moment:      -1.000000

 Saved qp weights ...
 Start second band pass ...
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0534 -0.6779 -0.4297 -0.4297 -0.4297  0.2977  0.2977  0.2977
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1365 -0.8248 -0.2365 -0.2365 -0.2365  0.2428  0.2428  0.2428
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 ... only filled or empty bands encountered:  ev=-0.824805  ec=-0.772717
 VBmax = -0.824805  CBmin = -0.772717  gap = 0.052088 Ry = 0.70839 eV
 BZINTS: Fermi energy:     -0.824805;   3.000000 electrons
         Sum occ. bands:   -3.277725, incl. Bloechl correction:  0.000000
         Mag. moment:      -1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.130156  386.510089 -384.379933     -0.144414 -327.846694  327.702280
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85491  sum tc=    31.38764  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78517  sum tc=    31.54593  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.992767   -0.956642    2.900000    2.967335    2.500000    2.967335
 spn 2 0    1.134455   -0.773670    2.900000    2.946917    2.500000    2.946917
 1     1    0.000104   -0.505503    2.850000    2.802064    2.250000    2.850000
 spn 2 1    0.002815   -0.125968    2.850000    2.943095    2.250000    2.850000
 2     0    0.000000   -1.059852    3.180000    3.117538    3.147584    3.147584
 spn 2 0    0.000012   -1.006449    3.180000    3.114300    3.147584    3.147584
 3     0    0.000000   -0.979574    4.120000    4.090136    4.102416    4.102416
 spn 2 0    0.000004   -0.926740    4.120000    4.088649    4.102416    4.102416

 Harris energy:
 sumev=       -3.277725  val*vef=     -14.335159   sumtv=      11.057434
 sumec=      -39.640082  cor*vef=    -102.572087   ttcor=      62.932005
 rhoeps=      -9.595549     utot=    -139.948566    ehar=     -75.554677

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00   -0.00     0.00    0.00   -0.00    -0.00   -0.00    0.00
 shift forces to make zero average correction:           -0.00   -0.00    0.00

 srhov:  -1237.406564   1225.633681    -11.772882 sumev=   -3.277725   sumtv=    8.495157
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1 -108.431577 -384.379933     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.205342  avg sphere pot= 0.030809  vconst= 0.205342
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves     38.909154   charge   388.379933
 smooth rhoeps =-2470.307875 (-179.105890,***********)
         rhomu =-3278.855537 (-116.220351,***********)
       avg vxc =   -0.316237 (  -0.227596,  -0.404877)
 smooth rhoeps =-2470.307875 (-179.105890,***********)
         rhomu =-3278.855537 (-116.220351,***********)
       avg vxc =   -0.316237 (  -0.227596,  -0.404877)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -5.572121   -5.624672  -11.196792    -82.113018-2616.753793-2698.866811

 local terms:     true           smooth         local
 rhoeps:        -7.980818   -2470.061843    2462.081025
 rhomu:         -5.216692    -116.218998     111.002306
 spin2:         -5.294318   -3162.316810    3157.022492
 total:        -10.511010   -3278.535808    3268.024799
 val*vef       -11.196792   -3195.933466    3184.736673
 val chg:        2.130156     386.510089    -384.379933
 val mom:       -0.144414    -327.846694     327.702280    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef          -2698.887528      2687.555482       -11.332046
   rhoval*ves             82.992160       -91.768696        -8.776537
   psnuc*ves              -5.173852      -258.804102      -263.977954
   utot                   38.909154      -175.286399      -136.377246
   rho*exc             -2470.307875      2462.081025        -8.226850
   rho*vxc             -3278.855537      3268.024799       -10.830739
   valence chg           387.379933      -384.379933         3.000000
   valence mag          -328.702280       327.702280        -1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=        8.495157  sumtc=        62.933572   ekin=       71.428730
 rhoep=       -8.226850   utot=      -136.377246   ehks=      -73.175366
 mag. mom=    -1.000000  (bands)       -1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.249647D+03 0.213631D-25 0.249647D+03       0
 mixrho: sum smrnew new  = 0.366735D+04-0.858895D-15 0.366735D+04       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns=  0.38472D+00  0.45304D+01 -0.22194D-16
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=3.66e0
 AMIX: nmix=0 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=1.83e0
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.49989546938132889      -2.49947734690664518E-004
 add q= -0.499895 to preserve neutrality
 unscreened rms difference:  smooth  6.407019   local 11.944378
   screened rms difference:  smooth  4.853730   local 11.944378   tot  3.656523
 mixrho: warning. negative smrho; isp number min=           1       90779 -6.77138202907305196E-004
 mixrho: warning. negative smrho; isp number min=           2       71667 -6.70355057714315614E-004

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=      -0.559777   ehk=       1.819534
h zbak=1 mmom=-1.0000002 ehf=-.5597765 ehk=1.819534

 --- BNDFP:  begin iteration 2 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       90779 -6.77138202907305196E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       71667 -6.70355057714315614E-004
 enforce positive smrho, to which we add srshift=  6.77138202917305226E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1  -54.027027 -191.520826     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.033200  avg sphere pot= 0.025175  vconst= 0.033200
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      8.716942   charge   196.875102
 smooth rhoeps = -987.885342 ( -73.661331,-914.224011)
         rhomu =-1310.094472 ( -49.167338,***********)
       avg vxc =   -0.348692 (  -0.312581,  -0.384802)
 smooth rhoeps = -987.885342 ( -73.661331,-914.224011)
         rhomu =-1310.094472 ( -49.167338,***********)
       avg vxc =   -0.348692 (  -0.312581,  -0.384802)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.282609   -4.877595  -13.160205    -55.594279-1311.700580-1367.294859

 local terms:     true           smooth         local
 rhoeps:        -8.864856    -987.433138     978.568282
 rhomu:         -6.359894     -48.963211      42.603317
 spin2:         -5.306301   -1260.543280    1255.236979
 total:        -11.666195   -1309.506491    1297.840296
 val*vef       -13.160205   -1293.660378    1280.500174
 val chg:        3.128514     194.649339    -191.520826
 val mom:        0.833288    -163.351431     164.184719    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000157

 potpus  spin 1 : pnu = 2.967335 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -29.130920    7.148883    0.041667   -0.661515
 1      3.000000    1.000000    -5.887832    7.215347    0.125265   -0.609242
 2      3.000000    1.000000     6.000000   28.948501    0.488585   -0.089186
 3      3.000000    1.000000     9.000000   39.802436    0.568028   -0.057151

 potpus  spin 2 : pnu = 2.946917 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -17.822435    7.206380    0.062673   -0.637491
 1      3.000000    1.000000    -5.887832    7.089092    0.131674   -0.585228
 2      3.000000    1.000000     6.000000   29.309512    0.491109   -0.087353
 3      3.000000    1.000000     9.000000   40.051423    0.569415   -0.056555

 Energy terms:             smooth           local           total
   rhoval*vef          -1367.835530      1354.104654       -13.730877
   rhoval*ves             15.896621       -25.851337        -9.954716
   psnuc*ves               1.537263      -268.894242      -267.356979
   utot                    8.716942      -147.372790      -138.655847
   rho*exc              -987.885342       978.568282        -9.317060
   rho*vxc             -1310.094472      1297.840296       -12.254175
   valence chg           195.875102      -191.520826         4.354276
   valence mag          -163.684720       164.184719         0.500000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.35428   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      1.35428
 (warning) system not neutral, dq=1.354276

 Read qp weights ...  ef=-0.824805
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2698 -0.6530 -0.6530 -0.6530 -0.0541  0.4096  0.4096  0.4096
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1592 -0.5475 -0.5475 -0.5475  0.0306  0.4324  0.4324  0.4324
 Est Ef = -0.825 < evl(3)=-0.653 ... using qval=3.0, revise to -0.6530
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.654075;   3.000000 electrons
         Sum occ. bands:   -3.082995, incl. Bloechl correction: -0.000035
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.861574    5.615157   -2.753584     -0.908714    0.296363   -1.205076
       contr. to mm extrapolated for r>rmt:  -0.076189 est. true mm =-0.984902
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.43137  sum tc=    31.48010  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.39613  sum tc=    31.56723  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976430   -1.258901    2.967335    2.926427    2.500000    2.926427
 spn 2 0    0.967059   -1.152995    2.946917    2.918327    2.500000    2.918327
 1     1    0.000000   -1.151382    2.850000    2.207621    2.250000    2.850000
 spn 2 1    0.918082   -0.542737    2.850000    2.895343    2.250000    2.850000
 2     0    0.000000   -1.421802    3.147584    3.103507    3.147584    3.147584
 spn 2 0    0.000002   -0.819844    3.147584    3.131716    3.147584    3.147584
 3     0    0.000000   -0.819844    4.102416    4.102416    4.102416    4.102416
 spn 2 0    0.000000   -0.777422    4.102416    4.095389    4.102416    4.102416

 Harris energy:
 sumev=       -3.082995  val*vef=     -13.730877   sumtv=      10.647881
 sumec=      -40.827503  cor*vef=    -103.760169   ttcor=      62.932666
 rhoeps=      -9.317060     utot=    -138.655847    ehar=     -74.392361

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00    0.00     0.00   -0.00   -0.00    -0.00    0.00    0.00
 shift forces to make zero average correction:           -0.00    0.00    0.00

 srhov:    -24.709672     11.295855    -13.413818 sumev=   -3.082995   sumtv=   10.330822
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.776772   -2.753584     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.117576  avg sphere pot= 0.012802  vconst= 0.117576
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      4.984082   charge     6.753584
 smooth rhoeps =   -5.969454 (  -3.356430,  -2.613025)
         rhomu =   -7.809160 (  -4.517597,  -3.291563)
       avg vxc =   -0.171717 (  -0.148481,  -0.194953)
 smooth rhoeps =   -5.969454 (  -3.356430,  -2.613025)
         rhomu =   -7.809160 (  -4.517597,  -3.291563)
       avg vxc =   -0.171717 (  -0.148481,  -0.194953)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -5.015240   -8.483004  -13.498244    -13.056403   -9.100262  -22.156666

 local terms:     true           smooth         local
 rhoeps:        -8.775881      -5.945365      -2.830517
 rhomu:         -5.219355      -4.512698      -0.706657
 spin2:         -6.332715      -3.265269      -3.067446
 total:        -11.552069      -7.777966      -3.774103
 val*vef       -13.498244     -12.283601      -1.214643
 val chg:        2.861574       5.615157      -2.753584
 val mom:       -0.908714       0.296363      -1.205076    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -22.173721         8.658403       -13.515318
   rhoval*ves             -4.373941        -5.959636       -10.333577
   psnuc*ves              14.342104      -282.234537      -267.892433
   utot                    4.984082      -144.097086      -139.113005
   rho*exc                -5.969454        -2.830517        -8.799971
   rho*vxc                -7.809160        -3.774103       -11.583262
   valence chg             5.753584        -2.753584         3.000000
   valence mag             0.205076        -1.205076        -1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00000

 Kohn-Sham energy:
 sumtv=       10.330822  sumtc=        63.047333   ekin=       73.378155
 rhoep=       -8.799971   utot=      -139.113005   ehks=      -74.534821
 mag. mom=     1.000000  (bands)       -1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.201190D+04 0.610342D-26 0.201190D+04       0
 mixrho: sum smrnew new  = 0.372416D+03-0.260889D-16 0.372416D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns= -0.19012D+00  0.22499D+01 -0.33472D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=1.82e0  last it=3.66e0
 AMIX: nmix=1 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=9.08e-1
   tj: 0.33193
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.61830664318458162      -3.09153321592290883E-004
 add q= -0.618307 to preserve neutrality
 unscreened rms difference:  smooth  3.181888   local  5.935995
   screened rms difference:  smooth  2.391406   local  5.935995   tot  1.816758
 mixrho: warning. negative smrho; isp number min=           1       88727 -5.53466609289749584E-004
 mixrho: warning. negative smrho; isp number min=           2       71163 -5.51088499648318196E-004

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=       0.602539   ehk=       0.460079
 From last iter    ehf=      -0.559777   ehk=       1.819534
 diffe(q)=  1.162316 (1.816758)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=-.9999998 ehf=.6025394 ehk=.4600792

 --- BNDFP:  begin iteration 3 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       88727 -5.53466609289749584E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       71163 -5.51088499648318196E-004
 enforce positive smrho, to which we add srshift=  5.53466609299749614E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1  -36.239487 -128.465638     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.048341  avg sphere pot= 0.021041  vconst= 0.048341
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      4.100707   charge   133.572571
 smooth rhoeps = -582.513169 ( -46.678375,-535.834794)
         rhomu = -772.026820 ( -32.211872,-739.814948)
       avg vxc =   -0.327366 (  -0.296363,  -0.358370)
 smooth rhoeps = -582.513169 ( -46.678375,-535.834794)
         rhomu = -772.026820 ( -32.211872,-739.814948)
       avg vxc =   -0.327366 (  -0.296363,  -0.358370)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -7.191789   -6.080942  -13.272731    -47.679171 -906.291774 -953.970945

 local terms:     true           smooth         local
 rhoeps:        -8.839982    -582.163242     573.323259
 rhomu:         -5.979477     -32.049395      26.069918
 spin2:         -5.653307    -739.522694     733.869387
 total:        -11.632784    -771.572089     759.939305
 val*vef       -13.272731    -769.194619     755.921887
 val chg:        3.082380     131.548017    -128.465638
 val mom:        0.251396    -108.687061     108.938457    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000104

 potpus  spin 1 : pnu = 2.926427 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.747370    7.666579    0.076309   -0.641934
 1      3.000000    1.000000    -5.887832    7.208203    0.127012   -0.601193
 2      3.000000    1.000000     6.000000   28.994088    0.488798   -0.088970
 3      3.000000    1.000000     9.000000   39.821779    0.568094   -0.057109

 potpus  spin 2 : pnu = 2.918327 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -11.434418    7.655648    0.082770   -0.632868
 1      3.000000    1.000000    -5.887832    7.143630    0.129413   -0.592961
 2      3.000000    1.000000     6.000000   29.160507    0.490066   -0.088102
 3      3.000000    1.000000     9.000000   39.946644    0.568838   -0.056804

 Energy terms:             smooth           local           total
   rhoval*vef           -954.389571       940.684799       -13.704772
   rhoval*ves              2.448502       -12.534448       -10.085946
   psnuc*ves               5.752913      -273.393649      -267.640736
   utot                    4.100707      -142.964048      -138.863341
   rho*exc              -582.513169       573.323259        -9.189909
   rho*vxc              -772.026820       759.939305       -12.087515
   valence chg           132.572571      -128.465638         4.106933
   valence mag          -108.939512       108.938457        -0.001055
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.10693   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      1.10693
 (warning) system not neutral, dq=1.106933

 Read qp weights ...  ef=-0.654075
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2303 -0.6126 -0.6126 -0.6126 -0.0274  0.4405  0.4405  0.4405
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1947 -0.5801 -0.5801 -0.5801  0.0537  0.4542  0.4542  0.4542
 Est Ef = -0.654 < evl(3)=-0.613 ... using qval=3.0, revise to -0.6126
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.613752;   3.000000 electrons
         Sum occ. bands:   -3.038813, incl. Bloechl correction: -0.000038
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.888571    6.188519   -3.299948      0.948219    2.201973   -1.253754
       contr. to mm extrapolated for r>rmt:   0.041135 est. true mm = 0.989354
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.38687  sum tc=    31.49394  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.37713  sum tc=    31.51993  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.975582   -1.219783    2.926427    2.925780    2.500000    2.925780
 spn 2 0    0.970176   -1.188875    2.918327    2.920587    2.500000    2.920587
 1     1    0.942812   -0.604235    2.850000    2.906655    2.250000    2.850000
 spn 2 1    0.000000   -0.877453    2.850000    2.357017    2.250000    2.850000
 2     0    0.000001   -0.840709    3.147584    3.130628    3.147584    3.147584
 spn 2 0    0.000000   -1.337307    3.147584    3.105963    3.147584    3.147584
 3     0    0.000000   -0.802046    4.102416    4.094620    4.102416    4.102416
 spn 2 0    0.000000   -0.802046    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -3.038813  val*vef=     -13.704772   sumtv=      10.665958
 sumec=      -40.763994  cor*vef=    -103.753966   ttcor=      62.989973
 rhoeps=      -9.189909     utot=    -138.863341    ehar=     -74.397319

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00    0.00     0.00    0.00   -0.00    -0.00   -0.00    0.00
 shift forces to make zero average correction:           -0.00   -0.00    0.00

 srhov:    -27.698567     14.013878    -13.684689 sumev=   -3.038813   sumtv=   10.645875
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.930898   -3.299948     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.114187  avg sphere pot= 0.011682  vconst= 0.114187
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.373437   charge     7.299947
 smooth rhoeps =   -6.909412 (  -4.656666,  -2.252746)
         rhomu =   -9.047018 (  -6.441902,  -2.605115)
       avg vxc =   -0.164128 (  -0.182967,  -0.145289)
 smooth rhoeps =   -6.909412 (  -4.656666,  -2.252746)
         rhomu =   -9.047018 (  -6.441902,  -2.605115)
       avg vxc =   -0.164128 (  -0.182967,  -0.145289)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.795788   -4.853153  -13.648941    -17.343166   -8.014998  -25.358164

 local terms:     true           smooth         local
 rhoeps:        -8.822773      -6.890674      -1.932099
 rhomu:         -6.411170      -6.423755       0.012584
 spin2:         -5.202603      -2.599000      -2.603603
 total:        -11.613774      -9.022754      -2.591019
 val*vef       -13.648941     -13.171777      -0.477164
 val chg:        2.888571       6.188519      -3.299948
 val mom:        0.948219       2.201973      -1.253754    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -25.372276        11.709198       -13.663078
   rhoval*ves             -4.024709        -6.404995       -10.429703
   psnuc*ves              14.771582      -282.860693      -268.089110
   utot                    5.373437      -144.632844      -139.259407
   rho*exc                -6.909412        -1.932099        -8.841511
   rho*vxc                -9.047018        -2.591019       -11.638037
   valence chg             6.299947        -3.299948         3.000000
   valence mag             2.253754        -1.253754         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.645875  sumtc=        63.013864   ekin=       73.659740
 rhoep=       -8.841511   utot=      -139.259407   ehks=      -74.441178
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.147707D+04-0.946633D-27 0.147707D+04       0
 mixrho: sum smrnew new  = 0.534606D+03 0.851209D-16 0.534606D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns= -0.12627D+00  0.14980D+01 -0.60894D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=1.21e0  last it=1.82e0
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=6.04e-1
   tj:-0.43709   0.19366
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.48903622853151774      -2.44518114265758902E-004
 add q= -0.489036 to preserve neutrality
 unscreened rms difference:  smooth  2.118533   local  3.942370
   screened rms difference:  smooth  1.588257   local  3.942370   tot  1.208167
 mixrho: warning. negative smrho; isp number min=           1       83501 -4.59777430794007643E-004
 mixrho: warning. negative smrho; isp number min=           2       72387 -4.61695750656468764E-004

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=       0.597581   ehk=       0.553722
 From last iter    ehf=       0.602539   ehk=       0.460079
 diffe(q)= -0.004959 (1.208167)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999998 ehf=.5975808 ehk=.5537223

 --- BNDFP:  begin iteration 4 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       83501 -4.59777430794007643E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       72387 -4.61695750656468764E-004
 enforce positive smrho, to which we add srshift=  4.61695750666468740E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1  -21.595304  -76.553358     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.064933  avg sphere pot= 0.016920  vconst= 0.064933
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      2.882876   charge    81.476750
 smooth rhoeps = -293.117965 ( -28.343756,-264.774208)
         rhomu = -388.077001 ( -21.195519,-366.881483)
       avg vxc =   -0.314592 (  -0.296349,  -0.332836)
 smooth rhoeps = -293.117965 ( -28.343756,-264.774208)
         rhomu = -388.077001 ( -21.195519,-366.881483)
       avg vxc =   -0.314592 (  -0.296349,  -0.332836)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.652613   -4.848655  -13.501268    -39.414058 -534.914917 -574.328976

 local terms:     true           smooth         local
 rhoeps:        -8.875441    -292.845110     283.969669
 rhomu:         -6.429888     -21.044413      14.614524
 spin2:         -5.251602    -366.678232     361.426630
 total:        -11.681490    -387.722645     376.041155
 val*vef       -13.501268    -391.600897     378.099629
 val chg:        3.038906      79.592264     -76.553358
 val mom:        0.923677     -62.203580      63.127256    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000063

 potpus  spin 1 : pnu = 2.925780 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.632138    7.729092    0.076121   -0.645186
 1      3.000000    1.000000    -5.887832    7.245642    0.125729   -0.605594
 2      3.000000    1.000000     6.000000   28.900752    0.488179   -0.089446
 3      3.000000    1.000000     9.000000   39.759688    0.567776   -0.057256

 potpus  spin 2 : pnu = 2.920587 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -11.774380    7.590374    0.082708   -0.624365
 1      3.000000    1.000000    -5.887832    7.148526    0.132226   -0.580129
 2      3.000000    1.000000     6.000000   29.215434    0.490231   -0.087864
 3      3.000000    1.000000     9.000000   39.960038    0.568827   -0.056780

 Energy terms:             smooth           local           total
   rhoval*vef           -574.646944       560.822893       -13.824052
   rhoval*ves             -3.781747        -6.459368       -10.241115
   psnuc*ves               9.547498      -277.479035      -267.931537
   utot                    2.882876      -141.969202      -139.086326
   rho*exc              -293.117965       283.969669        -9.148296
   rho*vxc              -388.077001       376.041155       -12.035846
   valence chg            80.476750       -76.553358         3.923392
   valence mag           -62.300096        63.127256         0.827160
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.92339   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.92339
 (warning) system not neutral, dq=0.923392

 Read qp weights ...  ef=-0.613752
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2536 -0.6345 -0.6345 -0.6345 -0.0095  0.4576  0.4576  0.4576
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1316 -0.5160 -0.5160 -0.5160  0.0859  0.4965  0.4965  0.4965
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.635410;   3.000000 electrons
         Sum occ. bands:   -3.020563, incl. Bloechl correction: -0.000033
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.893040    6.398953   -3.505914      0.955753    2.455264   -1.499511
       contr. to mm extrapolated for r>rmt:   0.035142 est. true mm = 0.990895
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.35043  sum tc=    31.44673  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.30785  sum tc=    31.54390  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976770   -1.243731    2.925780    2.926739    2.500000    2.926739
 spn 2 0    0.968643   -1.125228    2.920587    2.920028    2.500000    2.920028
 1     1    0.947626   -0.626319    2.850000    2.909013    2.250000    2.850000
 spn 2 1    0.000000   -1.048122    2.850000    2.210968    2.250000    2.850000
 2     0    0.000001   -0.853015    3.147584    3.130138    3.147584    3.147584
 spn 2 0    0.000000   -1.295773    3.147584    3.106170    3.147584    3.147584
 3     0    0.000000   -0.816657    4.102416    4.094301    4.102416    4.102416
 spn 2 0    0.000000   -0.816657    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -3.020563  val*vef=     -13.824052   sumtv=      10.803489
 sumec=      -40.658274  cor*vef=    -103.660204   ttcor=      63.001929
 rhoeps=      -9.148296     utot=    -139.086326    ehar=     -74.429204

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00    0.00     0.00   -0.00    0.00    -0.00    0.00   -0.00
 shift forces to make zero average correction:           -0.00    0.00   -0.00

 srhov:    -29.533160     15.873469    -13.659690 sumev=   -3.020563   sumtv=   10.639127
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.989000   -3.505914     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.113467  avg sphere pot= 0.011396  vconst= 0.113467
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.496551   charge     7.505913
 smooth rhoeps =   -7.276372 (  -5.026286,  -2.250086)
         rhomu =   -9.530510 (  -6.973414,  -2.557096)
       avg vxc =   -0.162625 (  -0.179970,  -0.145279)
 smooth rhoeps =   -7.276372 (  -5.026286,  -2.250086)
         rhomu =   -9.530510 (  -6.973414,  -2.557096)
       avg vxc =   -0.162625 (  -0.179970,  -0.145279)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.863017   -4.773680  -13.636697    -18.723836   -7.895023  -26.618859

 local terms:     true           smooth         local
 rhoeps:        -8.826421      -7.258465      -1.567957
 rhomu:         -6.424112      -6.956667       0.532554
 spin2:         -5.194457      -2.550656      -2.643800
 total:        -11.618569      -9.507323      -2.111246
 val*vef       -13.636697     -13.548960      -0.087737
 val chg:        2.893040       6.398953      -3.505914
 val mom:        0.955753       2.455264      -1.499511    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -26.632548        12.982134       -13.650414
   rhoval*ves             -3.918700        -6.493078       -10.411778
   psnuc*ves              14.911801      -282.954838      -268.043037
   utot                    5.496551      -144.723958      -139.227407
   rho*exc                -7.276372        -1.567957        -8.844328
   rho*vxc                -9.530510        -2.111246       -11.641757
   valence chg             6.505913        -3.505914         3.000000
   valence mag             2.499510        -1.499511         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.639127  sumtc=        62.990624   ekin=       73.629751
 rhoep=       -8.844328   utot=      -139.227407   ehks=      -74.441985
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.113604D+04-0.863014D-26 0.113604D+04       0
 mixrho: sum smrnew new  = 0.562839D+03 0.302392D-16 0.562839D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns= -0.73971D-01  0.87575D+00 -0.80256D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=7.07e-1  last it=1.21e0
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=3.53e-1
   tj:-1.03981  -0.16655
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.33038837766706841      -1.65194188833534249E-004
 add q= -0.330388 to preserve neutrality
 unscreened rms difference:  smooth  1.238492   local  2.306314
   screened rms difference:  smooth  0.927175   local  2.306314   tot  0.706532
 mixrho: warning. negative smrho; isp number min=           1       64623 -2.55808698539302358E-004
 mixrho: warning. negative smrho; isp number min=           2       77793 -2.60775448702058564E-004

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=       0.565696   ehk=       0.552915
 From last iter    ehf=       0.597581   ehk=       0.553722
 diffe(q)= -0.031885 (0.706532)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5656961 ehk=.5529155

 --- BNDFP:  begin iteration 5 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       64623 -2.55808698539302358E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       77793 -2.60775448702058564E-004
 enforce positive smrho, to which we add srshift=  2.60775448712058540E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.025619   -3.635725     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.094065  avg sphere pot= 0.011063  vconst= 0.094065
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.592799   charge     8.157276
 smooth rhoeps =   -7.704646 (  -5.535698,  -2.168948)
         rhomu =  -10.094136 (  -7.694555,  -2.399581)
       avg vxc =   -0.262286 (  -0.274243,  -0.250329)
 smooth rhoeps =   -7.704646 (  -5.535698,  -2.168948)
         rhomu =  -10.094136 (  -7.694555,  -2.399581)
       avg vxc =   -0.262286 (  -0.274243,  -0.250329)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       768
 vxcnsp (warning): negative rho: min val =  -2.14E-02
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.915885   -3.859139  -13.775023    -20.027262   -7.404828  -27.432090

 local terms:     true           smooth         local
 rhoeps:        -8.917355      -7.572861      -1.344495
 rhomu:         -6.800559      -7.592399       0.791840
 spin2:         -4.939435      -2.330902      -2.608533
 total:        -11.739994      -9.923301      -1.816693
 val*vef       -13.775023     -13.832910       0.057887
 val chg:        2.959540       6.595265      -3.635725
 val mom:        1.455949       3.027642      -1.571692    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000006

 potpus  spin 1 : pnu = 2.926739 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.803637    7.789225    0.074880   -0.648501
 1      3.000000    1.000000    -5.887832    7.299320    0.124481   -0.609177
 2      3.000000    1.000000     6.000000   28.777949    0.487297   -0.090091
 3      3.000000    1.000000     9.000000   39.670828    0.567291   -0.057471

 potpus  spin 2 : pnu = 2.920028 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -11.688563    7.618099    0.083945   -0.617014
 1      3.000000    1.000000    -5.887832    7.201784    0.133956   -0.570310
 2      3.000000    1.000000     6.000000   29.163075    0.489530   -0.088189
 3      3.000000    1.000000     9.000000   39.886119    0.568284   -0.056971

 Energy terms:             smooth           local           total
   rhoval*vef            -27.563465        13.657045       -13.906420
   rhoval*ves             -3.776106        -6.640797       -10.416903
   psnuc*ves              14.961703      -283.177928      -268.216225
   utot                    5.592799      -144.909363      -139.316564
   rho*exc                -7.704646        -1.344495        -9.049140
   rho*vxc               -10.094136        -1.816693       -11.910829
   valence chg             7.157276        -3.635725         3.521551
   valence mag             3.109665        -1.571692         1.537973
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.52155   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.52155
 (warning) system not neutral, dq=0.521551

 Read qp weights ...  ef=-0.63541
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2660 -0.6444 -0.6444 -0.6444  0.0386  0.5074  0.5074  0.5074
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0709 -0.4509 -0.4509 -0.4509 -0.0192  0.5215  0.5215  0.5215
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.645140;   3.000000 electrons
         Sum occ. bands:   -2.981819, incl. Bloechl correction: -0.000026
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905115    7.955504   -5.050389      0.957569    1.587210   -0.629641
       contr. to mm extrapolated for r>rmt:   0.035149 est. true mm = 0.992718
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.30575  sum tc=    31.40592  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.23559  sum tc=    31.56320  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.978180   -1.257329    2.926739    2.928028    2.500000    2.928028
 spn 2 0    0.973772   -1.056402    2.920028    2.926084    2.500000    2.926084
 1     1    0.953162   -0.637064    2.850000    2.912034    2.250000    2.850000
 spn 2 1    0.000001   -0.843833    2.850000    2.284164    2.250000    2.850000
 2     0    0.000001   -0.857687    3.147584    3.129311    3.147584    3.147584
 spn 2 0    0.000000   -1.282112    3.147584    3.104622    3.147584    3.147584
 3     0    0.000000   -0.825422    4.102416    4.093772    4.102416    4.102416
 spn 2 0    0.000000   -0.825422    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.981819  val*vef=     -13.906420   sumtv=      10.924601
 sumec=      -40.541342  cor*vef=    -103.537589   ttcor=      62.996247
 rhoeps=      -9.049140     utot=    -139.316564    ehar=     -74.444856

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00    -0.00   -0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:    -34.424159     20.735049    -13.689109 sumev=   -2.981819   sumtv=   10.707291
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.424688   -5.050389     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111320  avg sphere pot= 0.010079  vconst= 0.111320
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.997998   charge     9.050388
 smooth rhoeps =   -9.853833 (  -5.789096,  -4.064736)
         rhomu =  -12.908498 (  -7.852302,  -5.056196)
       avg vxc =   -0.159260 (  -0.175687,  -0.142833)
 smooth rhoeps =   -9.853833 (  -5.789096,  -4.064736)
         rhomu =  -12.908498 (  -7.852302,  -5.056196)
       avg vxc =   -0.159260 (  -0.175687,  -0.142833)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.910616   -4.767884  -13.678501    -21.164066  -14.887073  -36.051140

 local terms:     true           smooth         local
 rhoeps:        -8.842706      -9.838101       0.995395
 rhomu:         -6.438564      -7.837252       1.398689
 spin2:         -5.201327      -5.050875      -0.150452
 total:        -11.639891     -12.888127       1.248236
 val*vef       -13.678501     -16.497910       2.819409
 val chg:        2.905115       7.955504      -5.050389
 val mom:        0.957569       1.587210      -0.629641    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -36.063484        22.372593       -13.690891
   rhoval*ves             -3.490483        -6.943270       -10.433753
   psnuc*ves              15.486479      -283.573849      -268.087371
   utot                    5.997998      -145.258560      -139.260562
   rho*exc                -9.853833         0.995395        -8.858437
   rho*vxc               -12.908498         1.248236       -11.660261
   valence chg             8.050388        -5.050389         3.000000
   valence mag             1.629640        -0.629641         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.707291  sumtc=        62.969119   ekin=       73.676409
 rhoep=       -8.858437   utot=      -139.260562   ehks=      -74.442590
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.641684D+03-0.181675D-25 0.641684D+03       0
 mixrho: sum smrnew new  = 0.605002D+03-0.123565D-15 0.605002D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns=  0.89311D-03  0.13971D-01  0.33372D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.12e-2  last it=7.07e-1
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=5.6e-3
   tj:-1.06135   0.63363
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.23298559947013509      -1.16492799735067566E-004
 add q= -0.232986 to preserve neutrality
 unscreened rms difference:  smooth  0.019758   local  0.037510
   screened rms difference:  smooth  0.015654   local  0.037510   tot  0.011193
 mixrho: warning. negative smrho; isp number min=           1       62847 -1.71938012682868108E-004
 mixrho: warning. negative smrho; isp number min=           2       74013 -1.74578422407599290E-004

 iors  : write restart file (binary, mesh density) 

   it  5  of 10    ehf=       0.550044   ehk=       0.552310
 From last iter    ehf=       0.565696   ehk=       0.552915
 diffe(q)= -0.015652 (0.011193)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5500438 ehk=.5523102

 --- BNDFP:  begin iteration 6 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       62847 -1.71938012682868108E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       74013 -1.74578422407599290E-004
 enforce positive smrho, to which we add srshift=  1.74578422417599293E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.540342   -5.460371     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.099953  avg sphere pot= 0.010432  vconst= 0.099953
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.807032   charge     9.809528
 smooth rhoeps =  -10.774836 (  -5.968113,  -4.806724)
         rhomu =  -14.117050 (  -7.990725,  -6.126325)
       avg vxc =   -0.246980 (  -0.254589,  -0.239372)
 smooth rhoeps =  -10.774836 (  -5.968113,  -4.806724)
         rhomu =  -14.117050 (  -7.990725,  -6.126325)
       avg vxc =   -0.246980 (  -0.254589,  -0.239372)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       416
 vxcnsp (warning): negative rho: min val =  -6.21E-03
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.209690   -4.508388  -13.718078    -21.075282  -17.491236  -38.566518

 local terms:     true           smooth         local
 rhoeps:        -8.875510     -10.684814       1.809304
 rhomu:         -6.553891      -7.922987       1.369096
 spin2:         -5.129437      -6.077309       0.947873
 total:        -11.683328     -14.000297       2.316969
 val*vef       -13.718078     -17.759349       4.041271
 val chg:        2.941334       8.401706      -5.460371
 val mom:        1.105605       1.265364      -0.159759    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000009

 potpus  spin 1 : pnu = 2.928028 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -13.041157    7.772494    0.074170   -0.647767
 1      3.000000    1.000000    -5.887832    7.301190    0.124800   -0.607533
 2      3.000000    1.000000     6.000000   28.779470    0.487264   -0.090091
 3      3.000000    1.000000     9.000000   39.666701    0.567253   -0.057483

 potpus  spin 2 : pnu = 2.926084 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.685990    7.600877    0.078953   -0.624325
 1      3.000000    1.000000    -5.887832    7.225667    0.132156   -0.577025
 2      3.000000    1.000000     6.000000   29.073790    0.488950   -0.088635
 3      3.000000    1.000000     9.000000   39.828294    0.567988   -0.057107

 Energy terms:             smooth           local           total
   rhoval*vef            -38.652337        24.848392       -13.803944
   rhoval*ves             -3.628212        -6.791127       -10.419339
   psnuc*ves              15.242276      -283.409162      -268.166885
   utot                    5.807032      -145.100144      -139.293112
   rho*exc               -10.774836         1.809304        -8.965532
   rho*vxc               -14.117050         2.316969       -11.800081
   valence chg             8.809528        -5.460371         3.349157
   valence mag             1.318371        -0.159759         1.158611
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.34916   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.34916
 (warning) system not neutral, dq=0.349157

 Read qp weights ...  ef=-0.64514
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2494 -0.6274 -0.6274 -0.6274  0.1165  0.5499  0.5499  0.5499
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1012 -0.4803 -0.4803 -0.4803  0.1278  0.5785  0.5785  0.5785
 Est Ef = -0.645 < evl(3)=-0.627 ... using qval=3.0, revise to -0.6274
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.628040;   3.000000 electrons
         Sum occ. bands:   -2.978472, incl. Bloechl correction: -0.000026
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.902331    7.158985   -4.256654      0.957908    1.905459   -0.947551
       contr. to mm extrapolated for r>rmt:   0.034912 est. true mm = 0.992820
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.30547  sum tc=    31.42184  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.25208  sum tc=    31.54271  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.977118   -1.243197    2.928028    2.926823    2.500000    2.926823
 spn 2 0    0.972211   -1.093704    2.926084    2.923769    2.500000    2.923769
 1     1    0.953001   -0.621182    2.850000    2.912080    2.250000    2.850000
 spn 2 1    0.000000   -1.530499    2.850000    2.128768    2.250000    2.850000
 2     0    0.000001   -0.846859    3.147584    3.129196    3.147584    3.147584
 spn 2 0    0.000000   -1.288056    3.147584    3.104781    3.147584    3.147584
 3     0    0.000000   -0.816210    4.102416    4.093679    4.102416    4.102416
 spn 2 0    0.000000   -0.816210    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.978472  val*vef=     -13.803944   sumtv=      10.825472
 sumec=      -40.557546  cor*vef=    -103.540235   ttcor=      62.982689
 rhoeps=      -8.965532     utot=    -139.293112    ehar=     -74.450484

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00    0.00    -0.00   -0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:    -31.677863     18.010903    -13.666960 sumev=   -2.978472   sumtv=   10.688487
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.200780   -4.256654     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.112048  avg sphere pot= 0.010653  vconst= 0.112048
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.792155   charge     8.256654
 smooth rhoeps =   -8.464272 (  -5.278441,  -3.185830)
         rhomu =  -11.085166 (  -7.230859,  -3.854306)
       avg vxc =   -0.159233 (  -0.175691,  -0.142776)
 smooth rhoeps =   -8.464272 (  -5.278441,  -3.185830)
         rhomu =  -11.085166 (  -7.230859,  -3.854306)
       avg vxc =   -0.159233 (  -0.175691,  -0.142776)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.886079   -4.780136  -13.666215    -19.472908  -11.593699  -31.066607

 local terms:     true           smooth         local
 rhoeps:        -8.838184      -8.448016      -0.390168
 rhomu:         -6.434378      -7.215455       0.781076
 spin2:         -5.199572      -3.848661      -1.350911
 total:        -11.633951     -11.064116      -0.569835
 val*vef       -13.666215     -14.844295       1.178080
 val chg:        2.902331       7.158985      -4.256654
 val mom:        0.957908       1.905459      -0.947551    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -31.079339        17.400357       -13.678982
   rhoval*ves             -3.659848        -6.766466       -10.426314
   psnuc*ves              15.244158      -283.300626      -268.056468
   utot                    5.792155      -145.033546      -139.241391
   rho*exc                -8.464272        -0.390168        -8.854440
   rho*vxc               -11.085166        -0.569835       -11.655001
   valence chg             7.256654        -4.256654         3.000000
   valence mag             1.947551        -0.947551         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.688487  sumtc=        62.964550   ekin=       73.653037
 rhoep=       -8.854440   utot=      -139.241391   ehks=      -74.442794
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.632994D+03 0.151572D-25 0.632994D+03       0
 mixrho: sum smrnew new  = 0.575263D+03-0.779639D-16 0.575263D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns= -0.15529D-02  0.12360D-01 -0.25409D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.01e-2  last it=1.12e-2
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=5.04e-3
   tj: 0.37484  -0.00304
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.20601423741574187      -1.03007118707870964E-004
 add q= -0.206014 to preserve neutrality
 unscreened rms difference:  smooth  0.017479   local  0.033581
   screened rms difference:  smooth  0.014794   local  0.033581   tot  0.010081
 mixrho: warning. negative smrho; isp number min=           1       60787 -1.52763681350984030E-004
 mixrho: warning. negative smrho; isp number min=           2       73725 -1.55327544857547181E-004

 iors  : write restart file (binary, mesh density) 

   it  6  of 10    ehf=       0.544416   ehk=       0.552106
 From last iter    ehf=       0.550044   ehk=       0.552310
 diffe(q)= -0.005627 (0.010081)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5444164 ehk=.552106

 --- BNDFP:  begin iteration 7 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       60787 -1.52763681350984030E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       73725 -1.55327544857547181E-004
 enforce positive smrho, to which we add srshift=  1.55327544867547184E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.285852   -4.558225     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.101555  avg sphere pot= 0.010542  vconst= 0.101555
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.801217   charge     8.868880
 smooth rhoeps =   -9.098958 (  -5.610268,  -3.488690)
         rhomu =  -11.917577 (  -7.669850,  -4.247727)
       avg vxc =   -0.241035 (  -0.249616,  -0.232455)
 smooth rhoeps =   -9.098958 (  -5.610268,  -3.488690)
         rhomu =  -11.917577 (  -7.669850,  -4.247727)
       avg vxc =   -0.241035 (  -0.249616,  -0.232455)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       416
 vxcnsp (warning): negative rho: min val =  -5.86E-03
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.188252   -4.523821  -13.712073    -20.348006  -12.576468  -32.924474

 local terms:     true           smooth         local
 rhoeps:        -8.870969      -9.018260       0.147291
 rhomu:         -6.545324      -7.608243       1.062919
 spin2:         -5.132032      -4.204681      -0.927350
 total:        -11.677356     -11.812925       0.135569
 val*vef       -13.712073     -15.570066       1.857992
 val chg:        2.936323       7.494548      -4.558225
 val mom:        1.097635       1.951826      -0.854191    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.926823 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.818806    7.789616    0.074924   -0.647635
 1      3.000000    1.000000    -5.887832    7.303703    0.124701   -0.607901
 2      3.000000    1.000000     6.000000   28.772865    0.487217   -0.090126
 3      3.000000    1.000000     9.000000   39.662034    0.567228   -0.057494

 potpus  spin 2 : pnu = 2.923769 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.286330    7.633883    0.080450   -0.623984
 1      3.000000    1.000000    -5.887832    7.228390    0.131975   -0.577696
 2      3.000000    1.000000     6.000000   29.064310    0.488886   -0.088683
 3      3.000000    1.000000     9.000000   39.821931    0.567954   -0.057122

 Energy terms:             smooth           local           total
   rhoval*vef            -33.000129        19.212364       -13.787765
   rhoval*ves             -3.626625        -6.792413       -10.419039
   psnuc*ves              15.229060      -283.368176      -268.139116
   utot                    5.801217      -145.080295      -139.279077
   rho*exc                -9.098958         0.147291        -8.951667
   rho*vxc               -11.917577         0.135569       -11.782009
   valence chg             7.868880        -4.558225         3.310655
   valence mag             2.005101        -0.854191         1.150910
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.31066   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.31066
 (warning) system not neutral, dq=0.310655

 Read qp weights ...  ef=-0.62804
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2500 -0.6279 -0.6279 -0.6279  0.1293  0.5576  0.5576  0.5576
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1028 -0.4816 -0.4816 -0.4816  0.1309  0.5838  0.5838  0.5838
 Est Ef = -0.628 < evl(3)=-0.628 ... using qval=3.0, revise to -0.6279
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.628506;   3.000000 electrons
         Sum occ. bands:   -2.981149, incl. Bloechl correction: -0.000026
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.903011    7.193174   -4.290163      0.957998    1.853130   -0.895132
       contr. to mm extrapolated for r>rmt:   0.034970 est. true mm = 0.992969
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.30815  sum tc=    31.42288  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.25525  sum tc=    31.54291  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.977094   -1.244207    2.926823    2.926759    2.500000    2.926759
 spn 2 0    0.972506   -1.095408    2.923769    2.924022    2.500000    2.924022
 1     1    0.953411   -0.621877    2.850000    2.912304    2.250000    2.850000
 spn 2 1    0.000000   -1.536329    2.850000    2.128311    2.250000    2.850000
 2     0    0.000001   -0.847461    3.147584    3.129121    3.147584    3.147584
 spn 2 0    0.000000   -1.291165    3.147584    3.104646    3.147584    3.147584
 3     0    0.000000   -0.817358    4.102416    4.093630    4.102416    4.102416
 spn 2 0    0.000000   -0.817358    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.981149  val*vef=     -13.787765   sumtv=      10.806616
 sumec=      -40.563398  cor*vef=    -103.537018   ttcor=      62.973619
 rhoeps=      -8.951667     utot=    -139.279077    ehar=     -74.450509

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00   -0.00   -0.00    -0.00    0.00    0.00
 shift forces to make zero average correction:           -0.00    0.00    0.00

 srhov:    -31.401579     17.721498    -13.680080 sumev=   -2.981149   sumtv=   10.698931
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.210233   -4.290163     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111980  avg sphere pot= 0.010621  vconst= 0.111980
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.802402   charge     8.290163
 smooth rhoeps =   -8.518032 (  -5.270080,  -3.247953)
         rhomu =  -11.155451 (  -7.209867,  -3.945584)
       avg vxc =   -0.158906 (  -0.175308,  -0.142504)
 smooth rhoeps =   -8.518032 (  -5.270080,  -3.247953)
         rhomu =  -11.155451 (  -7.209867,  -3.945584)
       avg vxc =   -0.158906 (  -0.175308,  -0.142504)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.888957   -4.785059  -13.674016    -19.419267  -11.845599  -31.264866

 local terms:     true           smooth         local
 rhoeps:        -8.839871      -8.501896      -0.337975
 rhomu:         -6.435608      -7.194551       0.758943
 spin2:         -5.200560      -3.940006      -1.260555
 total:        -11.636169     -11.134557      -0.501612
 val*vef       -13.674016     -14.904106       1.230090
 val chg:        2.903011       7.193174      -4.290163
 val mom:        0.957998       1.853130      -0.895132    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -31.277526        17.590814       -13.686712
   rhoval*ves             -3.649371        -6.782909       -10.432280
   psnuc*ves              15.254175      -283.324971      -268.070796
   utot                    5.802402      -145.053940      -139.251538
   rho*exc                -8.518032        -0.337975        -8.856007
   rho*vxc               -11.155451        -0.501612       -11.657063
   valence chg             7.290163        -4.290163         3.000000
   valence mag             1.895131        -0.895132         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.698931  sumtc=        62.965797   ekin=       73.664728
 rhoep=       -8.856007   utot=      -139.251538   ehks=      -74.442818
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.617124D+03-0.223405D-26 0.617124D+03       0
 mixrho: sum smrnew new  = 0.574081D+03-0.137249D-16 0.574081D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns= -0.57872D-03  0.23918D-02 -0.67985D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.92e-3  last it=1.01e-2
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=9.59e-4
   tj: 0.21818   0.27205
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.18821488324511026      -9.41074416225551471E-005
 add q= -0.188215 to preserve neutrality
 unscreened rms difference:  smooth  0.003383   local  0.006298
   screened rms difference:  smooth  0.003334   local  0.006298   tot  0.001917
 mixrho: warning. negative smrho; isp number min=           1       59293 -1.39449759734131494E-004
 mixrho: warning. negative smrho; isp number min=           2       73029 -1.41855459814530584E-004

 iors  : write restart file (binary, mesh density) 

   it  7  of 10    ehf=       0.544391   ehk=       0.552082
 From last iter    ehf=       0.544416   ehk=       0.552106
 diffe(q)= -0.000025 (0.001917)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5443911 ehk=.5520823

 --- BNDFP:  begin iteration 8 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       59293 -1.39449759734131494E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       73029 -1.41855459814530584E-004
 enforce positive smrho, to which we add srshift=  1.41855459824530587E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.268546   -4.496880     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.102544  avg sphere pot= 0.010570  vconst= 0.102544
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.794581   charge     8.780591
 smooth rhoeps =   -8.979502 (  -5.546328,  -3.433174)
         rhomu =  -11.760786 (  -7.584605,  -4.176181)
       avg vxc =   -0.237316 (  -0.245875,  -0.228756)
 smooth rhoeps =   -8.979502 (  -5.546328,  -3.433174)
         rhomu =  -11.760786 (  -7.584605,  -4.176181)
       avg vxc =   -0.237316 (  -0.245875,  -0.228756)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       352
 vxcnsp (warning): negative rho: min val =  -4.98E-03
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.144898   -4.563240  -13.708138    -20.154046  -12.387258  -32.541304

 local terms:     true           smooth         local
 rhoeps:        -8.867357      -8.905048       0.037691
 rhomu:         -6.529996      -7.527527       0.997531
 spin2:         -5.142546      -4.136702      -1.005844
 total:        -11.672541     -11.664229      -0.008313
 val*vef       -13.708138     -15.427677       1.719538
 val chg:        2.933238       7.430118      -4.496880
 val mom:        1.077358       1.943468      -0.866110    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.926759 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.807252    7.791884    0.074955   -0.647659
 1      3.000000    1.000000    -5.887832    7.304927    0.124678   -0.607957
 2      3.000000    1.000000     6.000000   28.770075    0.487195   -0.090141
 3      3.000000    1.000000     9.000000   39.659754    0.567215   -0.057499

 potpus  spin 2 : pnu = 2.924022 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.328981    7.635882    0.080200   -0.624530
 1      3.000000    1.000000    -5.887832    7.230691    0.131815   -0.578295
 2      3.000000    1.000000     6.000000   29.056160    0.488833   -0.088724
 3      3.000000    1.000000     9.000000   39.816630    0.567927   -0.057135

 Energy terms:             smooth           local           total
   rhoval*vef            -32.610395        18.833130       -13.777265
   rhoval*ves             -3.633473        -6.786792       -10.420265
   psnuc*ves              15.222636      -283.350002      -268.127366
   utot                    5.794581      -145.068397      -139.273816
   rho*exc                -8.979502         0.037691        -8.941811
   rho*vxc               -11.760786        -0.008313       -11.769099
   valence chg             7.780591        -4.496880         3.283711
   valence mag             1.995055        -0.866110         1.128946
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.28371   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.28371
 (warning) system not neutral, dq=0.283711

 Read qp weights ...  ef=-0.628506
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2493 -0.6272 -0.6272 -0.6272  0.1403  0.5638  0.5638  0.5638
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1048 -0.4835 -0.4835 -0.4835  0.1435  0.5904  0.5904  0.5904
 Est Ef = -0.629 < evl(3)=-0.627 ... using qval=3.0, revise to -0.6272
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.627752;   3.000000 electrons
         Sum occ. bands:   -2.981706, incl. Bloechl correction: -0.000026
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.903108    7.156109   -4.253001      0.958122    1.856199   -0.898078
       contr. to mm extrapolated for r>rmt:   0.034924 est. true mm = 0.993046
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.30907  sum tc=    31.42404  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.25716  sum tc=    31.54193  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.977018   -1.243884    2.926759    2.926658    2.500000    2.926658
 spn 2 0    0.972493   -1.097869    2.924022    2.923951    2.500000    2.923951
 1     1    0.953596   -0.621298    2.850000    2.912417    2.250000    2.850000
 spn 2 1    0.000000   -1.538043    2.850000    2.128226    2.250000    2.850000
 2     0    0.000001   -0.847324    3.147584    3.129072    3.147584    3.147584
 spn 2 0    0.000000   -1.291317    3.147584    3.104647    3.147584    3.147584
 3     0    0.000000   -0.817647    4.102416    4.093596    4.102416    4.102416
 spn 2 0    0.000000   -0.817647    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.981706  val*vef=     -13.777265   sumtv=      10.795558
 sumec=      -40.566231  cor*vef=    -103.535939   ttcor=      62.969708
 rhoeps=      -8.941811     utot=    -139.273816    ehar=     -74.450360

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00    -0.00    0.00    0.00     0.00   -0.00   -0.00
 shift forces to make zero average correction:            0.00   -0.00   -0.00

 srhov:    -31.160992     17.477823    -13.683169 sumev=   -2.981706   sumtv=   10.701462
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.199750   -4.253001     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111996  avg sphere pot= 0.010644  vconst= 0.111996
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.794270   charge     8.253001
 smooth rhoeps =   -8.453353 (  -5.237466,  -3.215886)
         rhomu =  -11.070541 (  -7.166506,  -3.904035)
       avg vxc =   -0.158769 (  -0.175137,  -0.142401)
 smooth rhoeps =   -8.453353 (  -5.237466,  -3.215886)
         rhomu =  -11.070541 (  -7.166506,  -3.904035)
       avg vxc =   -0.158769 (  -0.175137,  -0.142401)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.888923   -4.787033  -13.675955    -19.302129  -11.730611  -31.032740

 local terms:     true           smooth         local
 rhoeps:        -8.840228      -8.437231      -0.402997
 rhomu:         -6.435895      -7.151211       0.715316
 spin2:         -5.200743      -3.898455      -1.302288
 total:        -11.636638     -11.049665      -0.586973
 val*vef       -13.675955     -14.824922       1.148967
 val chg:        2.903108       7.156109      -4.253001
 val mom:        0.958122       1.856199      -0.898078    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -31.045397        17.356749       -13.688648
   rhoval*ves             -3.655078        -6.778749       -10.433827
   psnuc*ves              15.243618      -283.317630      -268.074012
   utot                    5.794270      -145.048190      -139.253919
   rho*exc                -8.453353        -0.402997        -8.856349
   rho*vxc               -11.070541        -0.586973       -11.657513
   valence chg             7.253001        -4.253001         3.000000
   valence mag             1.898077        -0.898078         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.701462  sumtc=        62.965975   ekin=       73.667438
 rhoep=       -8.856349   utot=      -139.253919   ehks=      -74.442831
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.610978D+03-0.440184D-26 0.610978D+03       0
 mixrho: sum smrnew new  = 0.571942D+03 0.596744D-17 0.571942D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns= -0.52759D-03  0.21682D-02 -0.73196D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.73e-3  last it=1.92e-3
 AMIX: Reducing nmix to  1: t_j exceeds tm: tj=-11.03505   0.05512
 AMIX: Reducing nmix to  0: t_j exceeds tm: tj= -8.76362
 AMIX: nmix=0 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=8.67e-4
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -0.14185532114307176      -7.09276605715359004E-005
 add q= -0.141855 to preserve neutrality
 unscreened rms difference:  smooth  0.003066   local  0.005691
   screened rms difference:  smooth  0.003030   local  0.005691   tot  0.001734
 mixrho: warning. negative smrho; isp number min=           1       54937 -1.04846384372293751E-004
 mixrho: warning. negative smrho; isp number min=           2       71037 -1.06804385004550135E-004

 iors  : write restart file (binary, mesh density) 

   it  8  of 10    ehf=       0.544540   ehk=       0.552069
 From last iter    ehf=       0.544391   ehk=       0.552082
 diffe(q)=  0.000149 (0.001734)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5445398 ehk=.5520688

 --- BNDFP:  begin iteration 9 of 10 ---
 mkpot negative smrho; isp,number,min(smrho)=           1       54937 -1.04846384372293751E-004
 mkpot negative smrho; isp,number,min(smrho)=           2       71037 -1.06804385004550135E-004
 enforce positive smrho, to which we add srshift=  1.06804385014550138E-004

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.234148   -4.374941     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.105096  avg sphere pot= 0.010607  vconst= 0.105096
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.791179   charge     8.588549
 smooth rhoeps =   -8.734070 (  -5.401252,  -3.332818)
         rhomu =  -11.438571 (  -7.387983,  -4.050588)
       avg vxc =   -0.226669 (  -0.235111,  -0.218228)
 smooth rhoeps =   -8.734070 (  -5.401252,  -3.332818)
         rhomu =  -11.438571 (  -7.387983,  -4.050588)
       avg vxc =   -0.226669 (  -0.235111,  -0.218228)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 vxcns2 (warning): nr*np=     11808  negative density # of points=         0       256
 vxcnsp (warning): negative rho: min val =  -2.41E-03
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -9.018854   -4.678500  -13.697354    -19.722861  -12.057324  -31.780186

 local terms:     true           smooth         local
 rhoeps:        -8.858181      -8.675433      -0.182748
 rhomu:         -6.486060      -7.342464       0.856404
 spin2:         -5.174232      -4.020059      -1.154173
 total:        -11.660292     -11.362523      -0.297769
 val*vef       -13.697354     -15.130908       1.433554
 val chg:        2.925294       7.300234      -4.374941
 val mom:        1.017740       1.899834      -0.882094    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.926658 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.789063    7.796709    0.075001   -0.647684
 1      3.000000    1.000000    -5.887832    7.308015    0.124635   -0.608022
 2      3.000000    1.000000     6.000000   28.763313    0.487139   -0.090178
 3      3.000000    1.000000     9.000000   39.654026    0.567181   -0.057514

 potpus  spin 2 : pnu = 2.923951 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.316928    7.650173    0.080039   -0.625718
 1      3.000000    1.000000    -5.887832    7.237089    0.131385   -0.579903
 2      3.000000    1.000000     6.000000   29.033978    0.488687   -0.088836
 3      3.000000    1.000000     9.000000   39.802153    0.567852   -0.057169

 Energy terms:             smooth           local           total
   rhoval*vef            -31.832921        18.082796       -13.750125
   rhoval*ves             -3.640012        -6.783420       -10.423432
   psnuc*ves              15.222371      -283.335262      -268.112891
   utot                    5.791179      -145.059341      -139.268161
   rho*exc                -8.734070        -0.182748        -8.916818
   rho*vxc               -11.438571        -0.297769       -11.736340
   valence chg             7.588549        -4.374941         3.213609
   valence mag             1.946566        -0.882094         1.064473
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.21361   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.21361
 (warning) system not neutral, dq=0.213609

 Read qp weights ...  ef=-0.627752
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2471 -0.6247 -0.6247 -0.6247  0.1703  0.5812  0.5812  0.5812
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1104 -0.4886 -0.4886 -0.4886  0.1784  0.6087  0.6087  0.6087
 Est Ef = -0.628 < evl(3)=-0.625 ... using qval=3.0, revise to -0.6247
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.625280;   3.000000 electrons
         Sum occ. bands:   -2.982557, incl. Bloechl correction: -0.000025
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.903388    7.066790   -4.163402      0.958428    1.864221   -0.905793
       contr. to mm extrapolated for r>rmt:   0.034826 est. true mm = 0.993254
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31077  sum tc=    31.42691  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.26171  sum tc=    31.53851  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976820   -1.242551    2.926658    2.926401    2.500000    2.926401
 spn 2 0    0.972480   -1.104694    2.923951    2.923783    2.500000    2.923783
 1     1    0.954088   -0.619285    2.850000    2.912726    2.250000    2.850000
 spn 2 1    0.000000   -1.132064    2.850000    2.180345    2.250000    2.850000
 2     0    0.000001   -0.846934    3.147584    3.128927    3.147584    3.147584
 spn 2 0    0.000000   -1.291773    3.147584    3.104655    3.147584    3.147584
 3     0    0.000000   -0.818571    4.102416    4.093498    4.102416    4.102416
 spn 2 0    0.000000   -0.818571    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.982557  val*vef=     -13.750125   sumtv=      10.767569
 sumec=      -40.572480  cor*vef=    -103.540321   ttcor=      62.967841
 rhoeps=      -8.916818     utot=    -139.268161    ehar=     -74.449569

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00    0.00    -0.00   -0.00   -0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:    -30.610713     16.920251    -13.690462 sumev=   -2.982557   sumtv=   10.707906
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.174474   -4.163402     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.112028  avg sphere pot= 0.010696  vconst= 0.112028
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.776369   charge     8.163402
 smooth rhoeps =   -8.297687 (  -5.159029,  -3.138658)
         rhomu =  -10.866193 (  -7.062169,  -3.804024)
       avg vxc =   -0.158408 (  -0.174696,  -0.142121)
 smooth rhoeps =   -8.297687 (  -5.159029,  -3.138658)
         rhomu =  -10.866193 (  -7.062169,  -3.804024)
       avg vxc =   -0.158408 (  -0.174696,  -0.142121)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.888247   -4.792633  -13.680879    -19.019895  -11.454531  -30.474426

 local terms:     true           smooth         local
 rhoeps:        -8.841096      -8.281609      -0.559487
 rhomu:         -6.436551      -7.046927       0.610376
 spin2:         -5.201227      -3.798446      -1.402781
 total:        -11.637778     -10.845374      -0.792405
 val*vef       -13.680879     -14.632726       0.951847
 val chg:        2.903388       7.066790      -4.163402
 val mom:        0.958428       1.864221      -0.905793    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -30.487072        16.793513       -13.693559
   rhoval*ves             -3.667185        -6.770557       -10.437742
   psnuc*ves              15.219923      -283.300196      -268.080273
   utot                    5.776369      -145.035377      -139.259007
   rho*exc                -8.297687        -0.559487        -8.857174
   rho*vxc               -10.866193        -0.792405       -11.658597
   valence chg             7.163402        -4.163402         3.000000
   valence mag             1.905793        -0.905793         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.707906  sumtc=        62.965415   ekin=       73.673321
 rhoep=       -8.857174   utot=      -139.259007   ehks=      -74.442860
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.595945D+03 0.248333D-26 0.595945D+03       0
 mixrho: sum smrnew new  = 0.566825D+03 0.713468D-16 0.566825D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns= -0.42515D-03  0.18196D-02 -0.84799D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.46e-3  last it=1.73e-3
 AMIX: Reducing nmix to  1: t_j exceeds tm: tj= 13.85704 -11.27730
 AMIX: nmix=1 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=7.29e-4
   tj:-3.92181
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  3.06593391314176067E-002  1.53296695657088077E-005
 add q=  0.030659 to preserve neutrality
 unscreened rms difference:  smooth  0.002573   local  0.004836
   screened rms difference:  smooth  0.002568   local  0.004836   tot  0.001458
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  9  of 10    ehf=       0.545331   ehk=       0.552040
 From last iter    ehf=       0.544540   ehk=       0.552069
 diffe(q)=  0.000791 (0.001458)    tol= 0.000010 (0.000500)   more=T
i zbak=1 mmom=.9999997 ehf=.5453306 ehk=.5520396

 --- BNDFP:  begin iteration 10 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.087296   -3.854365     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.114386  avg sphere pot= 0.010826  vconst= 0.114386
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.746069   charge     7.854365
 smooth rhoeps =   -7.749253 (  -4.851979,  -2.897274)
         rhomu =  -10.145974 (  -6.647995,  -3.497980)
       avg vxc =   -0.175817 (  -0.185981,  -0.165652)
 smooth rhoeps =   -7.749253 (  -4.851979,  -2.897274)
         rhomu =  -10.145974 (  -6.647995,  -3.497980)
       avg vxc =   -0.175817 (  -0.185981,  -0.165652)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.704411   -4.972296  -13.676708    -17.983867  -10.578624  -28.562491

 local terms:     true           smooth         local
 rhoeps:        -8.832884      -7.733405      -1.099479
 rhomu:         -6.375556      -6.633705       0.258149
 spin2:         -5.251166      -3.491739      -1.759427
 total:        -11.626722     -10.125444      -1.501278
 val*vef       -13.676708     -13.936714       0.260006
 val chg:        2.896660       6.751026      -3.854365
 val mom:        0.871778       1.812194      -0.940416    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000008

 potpus  spin 1 : pnu = 2.926401 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.742734    7.816753    0.075050   -0.648086
 1      3.000000    1.000000    -5.887832    7.321575    0.124382   -0.608635
 2      3.000000    1.000000     6.000000   28.732682    0.486897   -0.090345
 3      3.000000    1.000000     9.000000   39.629300    0.567039   -0.057574

 potpus  spin 2 : pnu = 2.923783 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -12.288702    7.693890    0.079540   -0.629153
 1      3.000000    1.000000    -5.887832    7.258708    0.130135   -0.584510
 2      3.000000    1.000000     6.000000   28.964673    0.488224   -0.089189
 3      3.000000    1.000000     9.000000   39.755928    0.567611   -0.057280

 Energy terms:             smooth           local           total
   rhoval*vef            -28.572335        14.885751       -13.686584
   rhoval*ves             -3.686231        -6.754216       -10.440447
   psnuc*ves              15.178369      -283.263007      -268.084638
   utot                    5.746069      -145.008612      -139.262543
   rho*exc                -7.749253        -1.099479        -8.848731
   rho*vxc               -10.145974        -1.501278       -11.647252
   valence chg             6.854365        -3.854365         3.000000
   valence mag             1.846226        -0.940416         0.905811
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.62528
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.2418 -0.6186 -0.6186 -0.6186  0.2812  0.6499  0.6499  0.6499
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.1237 -0.5005 -0.5005 -0.5005  0.3094  0.6854  0.6854  0.6854
 Est Ef = -0.625 < evl(3)=-0.619 ... using qval=3.0, revise to -0.6186
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.618955;   3.000000 electrons
         Sum occ. bands:   -2.984378, incl. Bloechl correction: -0.000021
         Mag. moment:       1.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    2.905959    6.973307   -4.067347      0.960394    1.911034   -0.950640
       contr. to mm extrapolated for r>rmt:   0.033868 est. true mm = 0.994262
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -20.31529  sum tc=    31.43310  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -20.27345  sum tc=    31.52976  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.976529   -1.240010    2.926401    2.925958    2.500000    2.925958
 spn 2 0    0.972783   -1.121815    2.923783    2.923663    2.500000    2.923663
 1     1    0.956647   -0.614284    2.850000    2.914348    2.250000    2.850000
 spn 2 1    0.000000   -0.467222    2.850000    2.933369    2.250000    2.850000
 2     0    0.000001   -0.850937    3.147584    3.128152    3.147584    3.147584
 spn 2 0    0.000000   -1.291607    3.147584    3.104626    3.147584    3.147584
 3     0    0.000000   -0.829271    4.102416    4.092985    4.102416    4.102416
 spn 2 0    0.000000   -0.829271    4.102416    4.102416    4.102416    4.102416

 Harris energy:
 sumev=       -2.984378  val*vef=     -13.686584   sumtv=      10.702206
 sumec=      -40.588740  cor*vef=    -103.555366   ttcor=      62.966626
 rhoeps=      -8.848731     utot=    -139.262543    ehar=     -74.442441

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00   -0.00     0.00    0.00   -0.00    -0.00   -0.00    0.00
 shift forces to make zero average correction:           -0.00   -0.00    0.00

 srhov:    -29.712139     15.984929    -13.727210 sumev=   -2.984378   sumtv=   10.742832
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 Energy for background charge q=1, radius r=6.204 :  E = 9/5*q*q/r = 0.2902

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -1.147377   -4.067347     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt=-0.111828  avg sphere pot= 0.010674  vconst= 0.111828
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |
 cell interaction energy from homogeneous background (q=1) is 0.290159

 smooth rhoves      5.792873   charge     8.067347
 smooth rhoeps =   -8.130281 (  -5.094286,  -3.035995)
         rhomu =  -10.646559 (  -6.980303,  -3.666255)
       avg vxc =   -0.156663 (  -0.172492,  -0.140835)
 smooth rhoeps =   -8.130281 (  -5.094286,  -3.035995)
         rhomu =  -10.646559 (  -6.980303,  -3.666255)
       avg vxc =   -0.156663 (  -0.172492,  -0.140835)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1      -8.896463   -4.809956  -13.706419    -18.778757  -11.092329  -29.871085

 local terms:     true           smooth         local
 rhoeps:        -8.846751      -8.114642      -0.732109
 rhomu:         -6.441776      -6.965545       0.523769
 spin2:         -5.203431      -3.660763      -1.542668
 total:        -11.645207     -10.626308      -1.018898
 val*vef       -13.706419     -14.387427       0.681008
 val chg:        2.905959       6.973307      -4.067347
 val mom:        0.960394       1.911034      -0.950640    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef            -29.883514        16.164633       -13.718881
   rhoval*ves             -3.641501        -6.815258       -10.456759
   psnuc*ves              15.227247      -283.342863      -268.115616
   utot                    5.792873      -145.079060      -139.286188
   rho*exc                -8.130281        -0.732109        -8.862390
   rho*vxc               -10.646559        -1.018898       -11.665457
   valence chg             7.067347        -4.067347         3.000000
   valence mag             1.950639        -0.950640         1.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     3.00000   cores     2.00000   nucleii    -6.00000
    hom background     1.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       10.742832  sumtc=        62.962862   ekin=       73.705694
 rhoep=       -8.862390   utot=      -139.286188   ehks=      -74.442884
 mag. mom=     1.000000  (bands)        1.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.543787D+03-0.244231D-26 0.543787D+03       0
 mixrho: sum smrnew new  = 0.563624D+03-0.113376D-15 0.563624D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.199
 mixrho: dqsum rmsuns=  0.21298D-03  0.17296D-02  0.60908D-17
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.41e-3  last it=1.46e-3
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=7.07e-4
   tj: 0.07093   0.38421
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -6.20771549923047061E-002 -3.10385774961523627E-005
 add q= -0.062077 to preserve neutrality
 unscreened rms difference:  smooth  0.002446   local  0.004882
   screened rms difference:  smooth  0.002369   local  0.004882   tot  0.001414
 mixrho: warning. negative smrho; isp number min=           1       31067 -3.51959584487655076E-005
 mixrho: warning. negative smrho; isp number min=           2       59275 -3.65793281218495999E-005

 iors  : write restart file (binary, mesh density) 

   it 10  of 10    ehf=       0.552459   ehk=       0.552016
 From last iter    ehf=       0.545331   ehk=       0.552040
 diffe(q)=  0.007128 (0.001414)    tol= 0.000010 (0.000500)   more=F
x zbak=1 mmom=.9999997 ehf=.5524588 ehk=.5520162
 Exit 0 LMF 
