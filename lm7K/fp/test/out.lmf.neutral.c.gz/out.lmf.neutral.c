rdcmd:  lmfa --no-iactiv c -vzbak=0
HOST_INFORMATION platform: gfortran
HOST_INFORMATION compiler version: gcc version 4.3.4 (Ubuntu 4.3.4-10ubuntu1) 
HOST_INFORMATION FFLAGS (<=120): -O3 -fomit-frame-pointer -funroll-loops -ffast-math -ffixed-line-length-132 -DHASIARGC -DHASGETARG -DFDATE -DHASCPUTIME 
HOST_INFORMATION LIBLOC (<=120): /usr/lib64/libfftw3.a /usr/lib64/liblapack.so.3gf /usr/lib64/libblas.a
HOST_INFORMATION uname -a (<=120): Linux mar 2.6.32-25-generic #45-Ubuntu SMP Sat Oct 16 19:52:42 UTC 2010 x86_64 GNU/Linux
HOST_INFORMATION /etc/issue: Ubuntu 10.04.1 LTS \n \l
HOST_INFORMATION git branch: refs/heads/master
HOST_INFORMATION git commit: d040261476268c1a6f8442f30813ed4c12e48916
HOST_INFORMATION linked at: Sat Nov 13 16:41:48 JST 2010
 -----------------------  START LMFA     -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMFA  vn 7.00(LMFA 7.0)  verb 30,40,60
 pot:      spin-pol, XC:BH
 end of rdctrl2 in imfav7
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137
 goto mksym

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 end of mksym x
 goto defspc
 end of defspc
 goto freeat

conf:SPEC_ATOM= C : --- Table for atomic configuration ---
conf int(P)z = int(P) where P is replaced by PZ if it is semicore
conf:  isp  l  int(P) int(P)z    Qval    Qcore   CoreConf
conf:    1  0       2  2        1.000    1.000 => 1,
conf:    1  1       2  2        2.000    0.000 => 
conf:    1  2       3  3        0.000    0.000 => 
conf:    1  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------
conf:    2  0       2  2        1.000    1.000 => 1,
conf:    2  1       2  2        0.000    0.000 => 
conf:    2  2       3  3        0.000    0.000 => 
conf:    2  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001
 tailsm: init

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
 eee exi=           1  -1.0000000000000000     
 eee exi=           2  -2.0000000000000000     
 eee exi=           3  -4.0000000000000000     
 eee exi=           4  -6.0000000000000000     
 eee exi=           5  -9.0000000000000000     
 eee exi=           6  -15.000000000000000     
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753709   qtot  1.997279
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
 eee exi=           1  -1.0000000000000000     
 eee exi=           2  -2.0000000000000000     
 eee exi=           3  -4.0000000000000000     
 eee exi=           4  -6.0000000000000000     
 eee exi=           5  -9.0000000000000000     
 eee exi=           6  -15.000000000000000     
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 tailsm: end
 end of freats: spid=C       

  Write mtopara.* ...
 Exit 0 LMFA 
rdcmd:  lmf  --no-iactiv c -vzbak=0
HOST_INFORMATION platform: gfortran
HOST_INFORMATION compiler version: gcc version 4.3.4 (Ubuntu 4.3.4-10ubuntu1) 
HOST_INFORMATION FFLAGS (<=120): -O3 -fomit-frame-pointer -funroll-loops -ffast-math -ffixed-line-length-132 -DHASIARGC -DHASGETARG -DFDATE -DHASCPUTIME 
HOST_INFORMATION LIBLOC (<=120): /usr/lib64/libfftw3.a /usr/lib64/liblapack.so.3gf /usr/lib64/libblas.a
HOST_INFORMATION uname -a (<=120): Linux mar 2.6.32-25-generic #45-Ubuntu SMP Sat Oct 16 19:52:42 UTC 2010 x86_64 GNU/Linux
HOST_INFORMATION /etc/issue: Ubuntu 10.04.1 LTS \n \l
HOST_INFORMATION git branch: refs/heads/master
HOST_INFORMATION git commit: d040261476268c1a6f8442f30813ed4c12e48916
HOST_INFORMATION linked at: Sat Nov 13 16:41:48 JST 2010
 -----------------------  START LMF      -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMF  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 
 goto setcg
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 
 lstar xxx=          -2
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F
 lstar xxx=          -2

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 gvlist: cutoff radius  13.994 gives  45911   recips of max 125000
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363587    3.701843    2.363561    1.338282
 amom    1.810990    1.143831    1.810990    1.143831    0.667159

 Smooth charge on mesh:            2.661718    moment    1.332841
 Sum of local charges:             1.338282    moments   0.667159
 Total valence charge:             4.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           0.000000
 Deviation from neutrality:       -0.000000

 --- BNDFP:  begin iteration 1 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338282     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.063910   charge     2.661718
 smooth rhoeps =   -1.494901 (  -1.109320,  -0.385581)
         rhomu =   -1.946550 (  -1.522780,  -0.423770)
       avg vxc =   -0.191348 (  -0.218128,  -0.164568)
 smooth rhoeps =   -1.494901 (  -1.109320,  -0.385581)
         rhomu =   -1.946550 (  -1.522780,  -0.423770)
       avg vxc =   -0.191348 (  -0.218128,  -0.164568)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.341410   -3.941483  -14.282893     -2.908176   -0.943828   -3.852003

 local terms:     true           smooth         local
 rhoeps:        -9.536045      -1.428951      -8.107094
 rhomu:         -7.422765      -1.450795      -5.971970
 spin2:         -5.125221      -0.410320      -4.714901
 total:        -12.547986      -1.861115     -10.686870
 val*vef       -14.282893      -6.925497      -7.357396
 val chg:        3.701843       2.363561       1.338282
 val mom:        1.810990       1.143831       0.667159    core:  -0.000000
 core chg:       2.000000       2.000000      -0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.589352    0.102212   -0.581577
 1      3.000000    1.000000    -5.887832    7.119796    0.144160   -0.533282
 2      3.000000    1.000000     4.727244   27.134665    0.465946   -0.095778
 3      3.000000    1.000000     7.577135   37.213691    0.543677   -0.062061

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.437705    0.107908   -0.555887
 1      3.000000    1.000000    -5.887832    7.130043    0.153492   -0.500465
 2      3.000000    1.000000     4.727244   27.482684    0.468116   -0.093876
 3      3.000000    1.000000     7.577135   37.415022    0.544672   -0.061530

 Energy terms:             smooth           local           total
   rhoval*vef             -3.931613       -10.430885       -14.362499
   rhoval*ves             -5.058553        -5.181775       -10.240327
   psnuc*ves               9.186373      -278.836573      -269.650199
   utot                    2.063910      -142.009174      -139.945263
   rho*exc                -1.494901        -8.107094        -9.601995
   rho*vxc                -1.946550       -10.686870       -12.633421
   valence chg             2.661718         1.338282         4.000000
   valence mag             1.332841         0.667159         2.000000
   core charge             2.000000        -0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...
 Start second band pass ...
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4290
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686856    3.838083   -0.151227      1.796589    2.141131   -0.344542
       contr. to mm extrapolated for r>rmt:   0.163680 est. true mm = 1.960270
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85523  sum tc=    31.38701  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78555  sum tc=    31.54499  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.957935   -1.038744    2.900000    2.914621    2.500000    2.914621
 spn 2 0    0.945133   -0.836887    2.900000    2.908183    2.500000    2.908183
 1     1    1.783776   -0.429110    2.850000    2.889411    2.250000    2.850000
 spn 2 1    0.000000   -1.101865    2.850000    2.167565    2.250000    2.850000
 2     0    0.000011   -0.813692    3.180000    3.132790    3.147584    3.147584
 spn 2 0    0.000000   -1.175532    3.180000    3.108512    3.147584    3.147584
 3     0    0.000001   -0.763293    4.120000    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.128828    4.120000    4.085128    4.102416    4.102416

 Harris energy:
 sumev=       -2.743233  val*vef=     -14.362499   sumtv=      11.619265
 sumec=      -39.640777  cor*vef=    -102.572782   ttcor=      62.932005
 rhoeps=      -9.601995     utot=    -139.945263    ehar=     -74.995989

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00   -0.00    0.00    -0.00    0.00   -0.00
 shift forces to make zero average correction:           -0.00    0.00   -0.00

 srhov:     -7.491267     -6.856027    -14.347295 sumev=   -2.743233   sumtv=   11.604061
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.042660   -0.151227     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008341  avg sphere pot= 0.014058  vconst=-0.008341
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.531027   charge     4.151227
 smooth rhoeps =   -3.081515 (  -2.415640,  -0.665875)
         rhomu =   -4.025458 (  -3.336127,  -0.689331)
       avg vxc =   -0.206216 (  -0.237894,  -0.174538)
 smooth rhoeps =   -3.081515 (  -2.415640,  -0.665875)
         rhomu =   -4.025458 (  -3.336127,  -0.689331)
       avg vxc =   -0.206216 (  -0.237894,  -0.174538)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.331832   -3.946568  -14.278400     -7.320814   -1.729922   -9.050735

 local terms:     true           smooth         local
 rhoeps:        -9.525314      -3.014713      -6.510601
 rhomu:         -7.408850      -3.263013      -4.145837
 spin2:         -5.125107      -0.675917      -4.449191
 total:        -12.533957      -3.938930      -8.595028
 val*vef       -14.278400      -8.607508      -5.670893
 val chg:        3.686856       3.838083      -0.151227
 val mom:        1.796589       2.141131      -0.344542    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.130114        -5.227666       -14.357779
   rhoval*ves             -4.661428        -5.587080       -10.248508
   psnuc*ves              11.723481      -281.355166      -269.631684
   utot                    3.531027      -143.471123      -139.940096
   rho*exc                -3.081515        -6.510601        -9.592116
   rho*vxc                -4.025458        -8.595028       -12.620486
   valence chg             4.151227        -0.151227         4.000000
   valence mag             2.344542        -0.344542         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.604061  sumtc=        62.932006   ekin=       74.536067
 rhoep=       -9.592116   utot=      -139.940096   ehks=      -74.996145
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.249660D+03-0.119196D-25 0.249660D+03       0
 mixrho: sum smrnew new  = 0.405986D+03-0.142917D-16 0.405986D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho: dqsum rmsuns=  0.14895D-02  0.89309D-02  0.14527D-18
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=8.24e-3
 AMIX: nmix=0 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=4.12e-3
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  2.37886110365792547E-007  1.18943055182896294E-010
 unscreened rms difference:  smooth  0.012630   local  0.036279
   screened rms difference:  smooth  0.010354   local  0.036279   tot  0.008236
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       37543 -5.54208677154745034E-006

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=      -0.001089   ehk=      -0.001245
h zbak=0 mmom=1.9999996 ehf=-.0010887 ehk=-.0012453

 --- BNDFP:  begin iteration 2 of 10 ---
 all smrho is positive for isp=           1
 mkpot negative smrho; isp,number,min(smrho)=           2       37543 -5.54208677154745034E-006
 enforce positive smrho, to which we add srshift=  5.54208678154745017E-006

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.167431    0.593528     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008356  avg sphere pot= 0.016799  vconst=-0.008356
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.743317   charge     3.417557
 smooth rhoeps =   -2.249359 (  -1.726569,  -0.522789)
         rhomu =   -2.934415 (  -2.379640,  -0.554775)
       avg vxc =   -0.201612 (  -0.230232,  -0.172992)
 smooth rhoeps =   -2.249359 (  -1.726569,  -0.522789)
         rhomu =   -2.934415 (  -2.379640,  -0.554775)
       avg vxc =   -0.201612 (  -0.230232,  -0.172992)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336776   -3.945468  -14.282244     -4.949777   -1.314639   -6.264415

 local terms:     true           smooth         local
 rhoeps:        -9.532961      -2.180844      -7.352117
 rhomu:         -7.417504      -2.305475      -5.112029
 spin2:         -5.126437      -0.540186      -4.586251
 total:        -12.543941      -2.845661      -9.698281
 val*vef       -14.282244      -7.814990      -6.467254
 val chg:        3.697600       3.104073       0.593528
 val mom:        1.803790       1.642481       0.161309    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.914621 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.915138    7.418302    0.092820   -0.587641
 1      3.000000    1.000000    -5.887832    7.121418    0.144054   -0.533608
 2      3.000000    1.000000     6.000000   29.630950    0.492412   -0.085937
 3      3.000000    1.000000     9.000000   40.184999    0.569710   -0.056283

 potpus  spin 2 : pnu = 2.908183 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.110306    7.331756    0.102466   -0.559526
 1      3.000000    1.000000    -5.887832    7.130564    0.153438   -0.500623
 2      3.000000    1.000000     6.000000   29.973160    0.494326   -0.084382
 3      3.000000    1.000000     9.000000   40.379853    0.570594   -0.055847

 Energy terms:             smooth           local           total
   rhoval*vef             -6.347085        -8.017826       -14.364912
   rhoval*ves             -4.963242        -5.280235       -10.243477
   psnuc*ves              10.449875      -280.096506      -269.646631
   utot                    2.743317      -142.688371      -139.945054
   rho*exc                -2.249359        -7.352117        -9.601476
   rho*vxc                -2.934415        -9.698281       -12.632696
   valence chg             3.417557         0.593528         4.011084
   valence mag             1.838691         0.161309         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.01108   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.01108
 (warning) system not neutral, dq=0.011084

 Read qp weights ...  ef=-0.430662
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0413 -0.4295 -0.4295 -0.4295  0.1220  0.5243  0.5243  0.5243
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8399 -0.2386 -0.2386 -0.2386  0.1936  0.6187  0.6187  0.6187
 Est Ef = -0.431 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4295
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431288;   4.000000 electrons
         Sum occ. bands:   -2.746492, incl. Bloechl correction: -0.000185
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686196    3.834401   -0.148206      1.795570    2.119145   -0.323574
       contr. to mm extrapolated for r>rmt:   0.164299 est. true mm = 1.959869
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85641  sum tc=    31.38705  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78678  sum tc=    31.54486  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958094   -1.039238    2.914621    2.914698    2.500000    2.914698
 spn 2 0    0.945312   -0.837837    2.908183    2.908290    2.500000    2.908290
 1     1    1.782776   -0.429972    2.850000    2.889129    2.250000    2.850000
 spn 2 1    0.000000   -1.116964    2.850000    2.165383    2.250000    2.850000
 2     0    0.000012   -0.812935    3.147584    3.132784    3.147584    3.147584
 spn 2 0    0.000000   -1.179203    3.147584    3.108380    3.147584    3.147584
 3     0    0.000001   -0.762080    4.102416    4.096176    4.102416    4.102416
 spn 2 0    0.000000   -1.131551    4.102416    4.085079    4.102416    4.102416

 Harris energy:
 sumev=       -2.746492  val*vef=     -14.364912   sumtv=      11.618420
 sumec=      -39.643187  cor*vef=    -102.575192   ttcor=      62.932005
 rhoeps=      -9.601476     utot=    -139.945054    ehar=     -74.996105

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00   -0.00   -0.00    -0.00   -0.00    0.00     0.00    0.00   -0.00
 shift forces to make zero average correction:            0.00    0.00   -0.00

 srhov:     -8.353442     -5.999449    -14.352891 sumev=   -2.746492   sumtv=   11.606399
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.041808   -0.148206     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008178  avg sphere pot= 0.014111  vconst=-0.008178
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.513356   charge     4.148205
 smooth rhoeps =   -3.076535 (  -2.402665,  -0.673870)
         rhomu =   -4.018751 (  -3.318605,  -0.700146)
       avg vxc =   -0.206362 (  -0.238091,  -0.174632)
 smooth rhoeps =   -3.076535 (  -2.402665,  -0.673870)
         rhomu =   -4.018751 (  -3.318605,  -0.700146)
       avg vxc =   -0.206362 (  -0.238091,  -0.174632)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.331795   -3.948938  -14.280733     -7.282947   -1.760702   -9.043649

 local terms:     true           smooth         local
 rhoeps:        -9.525008      -3.009601      -6.515407
 rhomu:         -7.408042      -3.245273      -4.162769
 spin2:         -5.125515      -0.686777      -4.438738
 total:        -12.533557      -3.932050      -8.601507
 val*vef       -14.280733      -8.610232      -5.670501
 val chg:        3.686196       3.834401      -0.148206
 val mom:        1.795570       2.119145      -0.323574    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.123152        -5.237084       -14.360237
   rhoval*ves             -4.670985        -5.580250       -10.251236
   psnuc*ves              11.697698      -281.331463      -269.633765
   utot                    3.513356      -143.455857      -139.942500
   rho*exc                -3.076535        -6.515407        -9.591942
   rho*vxc                -4.018751        -8.601507       -12.620258
   valence chg             4.148205        -0.148206         4.000000
   valence mag             2.323574        -0.323574         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.606399  sumtc=        62.931909   ekin=       74.538308
 rhoep=       -9.591942   utot=      -139.942500   ehks=      -74.996134
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.328515D+03-0.379173D-26 0.328515D+03       0
 mixrho: sum smrnew new  = 0.404486D+03 0.424489D-16 0.404486D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho: dqsum rmsuns=  0.73065D-03  0.44228D-02  0.61000D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=4.07e-3  last it=8.24e-3
 AMIX: nmix=1 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=2.03e-3
   tj:-0.97479
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -1.09443824244951637E-002 -5.47219121224758327E-006
 add q= -0.010944 to preserve neutrality
 unscreened rms difference:  smooth  0.006255   local  0.017824
   screened rms difference:  smooth  0.005197   local  0.017824   tot  0.004069
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       44533 -9.41278857480916481E-006

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=      -0.001205   ehk=      -0.001234
 From last iter    ehf=      -0.001089   ehk=      -0.001245
 diffe(q)= -0.000117 (0.004069)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0012052 ehk=-.0012344

 --- BNDFP:  begin iteration 3 of 10 ---
 all smrho is positive for isp=           1
 mkpot negative smrho; isp,number,min(smrho)=           2       44533 -9.41278857480916481E-006
 enforce positive smrho, to which we add srshift=  9.41278858480916464E-006

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.039171   -0.138858     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.009537  avg sphere pot= 0.014145  vconst=-0.009537
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.500318   charge     4.157683
 smooth rhoeps =   -3.072865 (  -2.397715,  -0.675150)
         rhomu =   -4.013845 (  -3.311744,  -0.702101)
       avg vxc =   -0.210038 (  -0.240011,  -0.180064)
 smooth rhoeps =   -3.072865 (  -2.397715,  -0.675150)
         rhomu =   -4.013845 (  -3.311744,  -0.702101)
       avg vxc =   -0.210038 (  -0.240011,  -0.180064)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.332113   -3.951102  -14.283215     -7.251100   -1.756580   -9.007680

 local terms:     true           smooth         local
 rhoeps:        -9.528581      -3.002120      -6.526460
 rhomu:         -7.410743      -3.235484      -4.175259
 spin2:         -5.127466      -0.686720      -4.440745
 total:        -12.538209      -3.922204      -8.616004
 val*vef       -14.283215      -8.602413      -5.680802
 val chg:        3.691283       3.830141      -0.138858
 val mom:        1.795674       2.113137      -0.317463    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000004

 potpus  spin 1 : pnu = 2.914698 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.925419    7.421845    0.092692   -0.588007
 1      3.000000    1.000000    -5.887832    7.123404    0.143913   -0.534049
 2      3.000000    1.000000     6.000000   29.622562    0.492354   -0.085978
 3      3.000000    1.000000     9.000000   40.179008    0.569678   -0.056297

 potpus  spin 2 : pnu = 2.908290 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.122760    7.333202    0.102332   -0.559812
 1      3.000000    1.000000    -5.887832    7.131435    0.153332   -0.500934
 2      3.000000    1.000000     6.000000   29.967246    0.494286   -0.084410
 3      3.000000    1.000000     9.000000   40.375634    0.570571   -0.055857

 Energy terms:             smooth           local           total
   rhoval*vef             -9.092784        -5.275535       -14.368319
   rhoval*ves             -4.673672        -5.576103       -10.249775
   psnuc*ves              11.674308      -281.316981      -269.642673
   utot                    3.500318      -143.446542      -139.946224
   rho*exc                -3.072865        -6.526460        -9.599325
   rho*vxc                -4.013845        -8.616004       -12.629850
   valence chg             4.157683        -0.138858         4.018826
   valence mag             2.317463        -0.317463         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.01883   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.01883
 (warning) system not neutral, dq=0.018826

 Read qp weights ...  ef=-0.431288
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0423 -0.4304 -0.4304 -0.4304  0.1175  0.5221  0.5221  0.5221
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8414 -0.2400 -0.2400 -0.2400  0.1863  0.6155  0.6155  0.6155
 Est Ef = -0.431 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4304
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.432140;   4.000000 electrons
         Sum occ. bands:   -2.750742, incl. Bloechl correction: -0.000190
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686238    3.838411   -0.152173      1.795207    2.105230   -0.310023
       contr. to mm extrapolated for r>rmt:   0.164440 est. true mm = 1.959647
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85808  sum tc=    31.38702  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78851  sum tc=    31.54457  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958242   -1.040109    2.914698    2.914772    2.500000    2.914772
 spn 2 0    0.945515   -0.839207    2.908290    2.908399    2.500000    2.908399
 1     1    1.782468   -0.431027    2.850000    2.888983    2.250000    2.850000
 spn 2 1    0.000000   -1.123876    2.850000    2.164446    2.250000    2.850000
 2     0    0.000012   -0.811887    3.147584    3.132792    3.147584    3.147584
 spn 2 0    0.000000   -1.179356    3.147584    3.108378    3.147584    3.147584
 3     0    0.000001   -0.760727    4.102416    4.096182    4.102416    4.102416
 spn 2 0    0.000000   -1.132304    4.102416    4.085064    4.102416    4.102416

 Harris energy:
 sumev=       -2.750742  val*vef=     -14.368319   sumtv=      11.617578
 sumec=      -39.646595  cor*vef=    -102.578553   ttcor=      62.931957
 rhoeps=      -9.599325     utot=    -139.946224    ehar=     -74.996015

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00   -0.00    -0.00   -0.00    0.00
 shift forces to make zero average correction:           -0.00   -0.00    0.00

 srhov:     -9.137566     -5.226396    -14.363962 sumev=   -2.750742   sumtv=   11.613220
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.042927   -0.152173     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008107  avg sphere pot= 0.014138  vconst=-0.008107
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.502536   charge     4.152173
 smooth rhoeps =   -3.081140 (  -2.398822,  -0.682318)
         rhomu =   -4.024648 (  -3.313668,  -0.710979)
       avg vxc =   -0.206393 (  -0.238142,  -0.174645)
 smooth rhoeps =   -3.081140 (  -2.398822,  -0.682318)
         rhomu =   -4.024648 (  -3.313668,  -0.710979)
       avg vxc =   -0.206393 (  -0.238142,  -0.174645)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.334362   -3.951297  -14.285659     -7.273248   -1.791771   -9.065019

 local terms:     true           smooth         local
 rhoeps:        -9.525839      -3.014241      -6.511598
 rhomu:         -7.408633      -3.240328      -4.168305
 spin2:         -5.126020      -0.697665      -4.428355
 total:        -12.534653      -3.937993      -8.596660
 val*vef       -14.285659      -8.620653      -5.665006
 val chg:        3.686238       3.838411      -0.152173
 val mom:        1.795207       2.105230      -0.310023    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.144469        -5.220641       -14.365110
   rhoval*ves             -4.675456        -5.579701       -10.255157
   psnuc*ves              11.680529      -281.321758      -269.641229
   utot                    3.502536      -143.450729      -139.948193
   rho*exc                -3.081140        -6.511598        -9.592738
   rho*vxc                -4.024648        -8.596660       -12.621307
   valence chg             4.152173        -0.152173         4.000000
   valence mag             2.310023        -0.310023         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.613220  sumtc=        62.931592   ekin=       74.544812
 rhoep=       -9.592738   utot=      -139.948193   ehks=      -74.996119
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.404697D+03-0.238978D-26 0.404697D+03       0
 mixrho: sum smrnew new  = 0.403887D+03-0.756233D-17 0.403887D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho: dqsum rmsuns= -0.55106D-05  0.11797D-03  0.68252D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=9.77e-5  last it=4.07e-3
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=4.89e-5
   tj:-1.56863   0.76414
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -8.29161184178311972E-003 -4.14580592089156111E-006
 add q= -0.008292 to preserve neutrality
 unscreened rms difference:  smooth  0.000167   local  0.000345
   screened rms difference:  smooth  0.000159   local  0.000345   tot  0.000098
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       32143 -7.06366546677655949E-006

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=      -0.001115   ehk=      -0.001219
 From last iter    ehf=      -0.001205   ehk=      -0.001234
 diffe(q)=  0.000090 (0.000098)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0011148 ehk=-.0012194

 --- BNDFP:  begin iteration 4 of 10 ---
 all smrho is positive for isp=           1
 mkpot negative smrho; isp,number,min(smrho)=           2       32143 -7.06366546677655949E-006
 enforce positive smrho, to which we add srshift=  7.06366547677655932E-006

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044661   -0.158318     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008865  avg sphere pot= 0.014112  vconst=-0.008865
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.509421   charge     4.172445
 smooth rhoeps =   -3.093029 (  -2.408022,  -0.685007)
         rhomu =   -4.040192 (  -3.326443,  -0.713749)
       avg vxc =   -0.210519 (  -0.240300,  -0.180739)
 smooth rhoeps =   -3.093029 (  -2.408022,  -0.685007)
         rhomu =   -4.040192 (  -3.326443,  -0.713749)
       avg vxc =   -0.210519 (  -0.240300,  -0.180739)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.334205   -3.952230  -14.286436     -7.295819   -1.793842   -9.089662

 local terms:     true           smooth         local
 rhoeps:        -9.527502      -3.023191      -6.504311
 rhomu:         -7.409836      -3.250826      -4.159010
 spin2:         -5.126980      -0.698899      -4.428081
 total:        -12.536816      -3.949725      -8.587091
 val*vef       -14.286436      -8.627005      -5.659430
 val chg:        3.688744       3.847062      -0.158318
 val mom:        1.795170       2.110789      -0.315618    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914772 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.935315    7.422131    0.092626   -0.588097
 1      3.000000    1.000000    -5.887832    7.124145    0.143885   -0.534124
 2      3.000000    1.000000     6.000000   29.620267    0.492339   -0.085989
 3      3.000000    1.000000     9.000000   40.177356    0.569670   -0.056301

 potpus  spin 2 : pnu = 2.908399 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.135561    7.333160    0.102235   -0.559933
 1      3.000000    1.000000    -5.887832    7.132222    0.153295   -0.501025
 2      3.000000    1.000000     6.000000   29.964358    0.494266   -0.084423
 3      3.000000    1.000000     9.000000   40.373501    0.570560   -0.055862

 Energy terms:             smooth           local           total
   rhoval*vef             -9.173297        -5.196775       -14.370071
   rhoval*ves             -4.670449        -5.583718       -10.254167
   psnuc*ves              11.689291      -281.334378      -269.645087
   utot                    3.509421      -143.459048      -139.949627
   rho*exc                -3.093029        -6.504311        -9.597341
   rho*vxc                -4.040192        -8.587091       -12.627283
   valence chg             4.172445        -0.158318         4.014127
   valence mag             2.315618        -0.315618         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.01413   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.01413
 (warning) system not neutral, dq=0.014127

 Read qp weights ...  ef=-0.43214
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0424 -0.4304 -0.4304 -0.4304  0.1203  0.5235  0.5235  0.5235
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8414 -0.2399 -0.2399 -0.2399  0.1916  0.6179  0.6179  0.6179
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4304
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.432167;   4.000000 electrons
         Sum occ. bands:   -2.750915, incl. Bloechl correction: -0.000189
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686694    3.842330   -0.155635      1.795598    2.108593   -0.312996
       contr. to mm extrapolated for r>rmt:   0.164138 est. true mm = 1.959736
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85791  sum tc=    31.38678  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78831  sum tc=    31.54436  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958254   -1.040287    2.914772    2.914770    2.500000    2.914770
 spn 2 0    0.945548   -0.839344    2.908399    2.908407    2.500000    2.908407
 1     1    1.782880   -0.431080    2.850000    2.889061    2.250000    2.850000
 spn 2 1    0.000000   -1.123162    2.850000    2.164513    2.250000    2.850000
 2     0    0.000012   -0.811700    3.147584    3.132787    3.147584    3.147584
 spn 2 0    0.000000   -1.178997    3.147584    3.108375    3.147584    3.147584
 3     0    0.000001   -0.760545    4.102416    4.096178    4.102416    4.102416
 spn 2 0    0.000000   -1.131767    4.102416    4.085065    4.102416    4.102416

 Harris energy:
 sumev=       -2.750915  val*vef=     -14.370071   sumtv=      11.619157
 sumec=      -39.646220  cor*vef=    -102.577994   ttcor=      62.931774
 rhoeps=      -9.597341     utot=    -139.949627    ehar=     -74.996037

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00    0.00   -0.00     0.00   -0.00    0.00
 shift forces to make zero average correction:            0.00   -0.00    0.00

 srhov:     -9.162283     -5.204914    -14.367197 sumev=   -2.750915   sumtv=   11.616282
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043904   -0.155635     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008157  avg sphere pot= 0.014128  vconst=-0.008157
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.505425   charge     4.155635
 smooth rhoeps =   -3.085938 (  -2.403023,  -0.682915)
         rhomu =   -4.030949 (  -3.319509,  -0.711439)
       avg vxc =   -0.206322 (  -0.238050,  -0.174593)
 smooth rhoeps =   -3.085938 (  -2.403023,  -0.682915)
         rhomu =   -4.030949 (  -3.319509,  -0.711439)
       avg vxc =   -0.206322 (  -0.238050,  -0.174593)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336028   -3.951402  -14.287430     -7.285773   -1.793318   -9.079091

 local terms:     true           smooth         local
 rhoeps:        -9.526585      -3.019152      -6.507433
 rhomu:         -7.409524      -3.246304      -4.163220
 spin2:         -5.126109      -0.698136      -4.427972
 total:        -12.535633      -3.944440      -8.591193
 val*vef       -14.287430      -8.624491      -5.662939
 val chg:        3.686694       3.842330      -0.155635
 val mom:        1.795598       2.108593      -0.312996    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.158421        -5.208339       -14.366760
   rhoval*ves             -4.672872        -5.583113       -10.255985
   psnuc*ves              11.683722      -281.328057      -269.644336
   utot                    3.505425      -143.455585      -139.950161
   rho*exc                -3.085938        -6.507433        -9.593372
   rho*vxc                -4.030949        -8.591193       -12.622142
   valence chg             4.155635        -0.155635         4.000000
   valence mag             2.312995        -0.312996         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.616282  sumtc=        62.931133   ekin=       74.547415
 rhoep=       -9.593372   utot=      -139.950161   ehks=      -74.996117
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.405504D+03 0.246546D-26 0.405504D+03       0
 mixrho: sum smrnew new  = 0.404289D+03 0.159013D-16 0.404289D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho: dqsum rmsuns= -0.16810D-04  0.22679D-04 -0.63950D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.63e-5  last it=9.77e-5
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=8.13e-6
   tj:-0.04193   0.00413
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -6.95871947844489691E-003 -3.47935973922244933E-006
 add q= -0.006959 to preserve neutrality
 unscreened rms difference:  smooth  0.000032   local  0.000071
   screened rms difference:  smooth  0.000025   local  0.000071   tot  0.000016
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       25103 -5.49177030749735112E-006

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=      -0.001137   ehk=      -0.001217
 From last iter    ehf=      -0.001115   ehk=      -0.001219
 diffe(q)= -0.000022 (0.000016)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0011367 ehk=-.0012175

 --- BNDFP:  begin iteration 5 of 10 ---
 all smrho is positive for isp=           1
 mkpot negative smrho; isp,number,min(smrho)=           2       25103 -5.49177030749735112E-006
 enforce positive smrho, to which we add srshift=  5.49177031749735095E-006

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043975   -0.155888     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008648  avg sphere pot= 0.014124  vconst=-0.008648
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.505757   charge     4.166871
 smooth rhoeps =   -3.089337 (  -2.404995,  -0.684342)
         rhomu =   -4.035362 (  -3.322262,  -0.713099)
       avg vxc =   -0.209903 (  -0.239890,  -0.179916)
 smooth rhoeps =   -3.089337 (  -2.404995,  -0.684342)
         rhomu =   -4.035362 (  -3.322262,  -0.713099)
       avg vxc =   -0.209903 (  -0.239890,  -0.179916)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.335217   -3.952022  -14.287238     -7.286781   -1.793444   -9.080225

 local terms:     true           smooth         local
 rhoeps:        -9.527373      -3.020203      -6.507170
 rhomu:         -7.409937      -3.247211      -4.162726
 spin2:         -5.126716      -0.698596      -4.428120
 total:        -12.536654      -3.945807      -8.590846
 val*vef       -14.287238      -8.624888      -5.662350
 val chg:        3.688178       3.844065      -0.155888
 val mom:        1.795399       2.108766      -0.313367    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914770 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.935126    7.422436    0.092625   -0.588100
 1      3.000000    1.000000    -5.887832    7.124389    0.143881   -0.534126
 2      3.000000    1.000000     6.000000   29.619722    0.492335   -0.085991
 3      3.000000    1.000000     9.000000   40.176918    0.569667   -0.056302

 potpus  spin 2 : pnu = 2.908407 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.136503    7.333377    0.102227   -0.559941
 1      3.000000    1.000000    -5.887832    7.132493    0.153291   -0.501029
 2      3.000000    1.000000     6.000000   29.963727    0.494261   -0.084426
 3      3.000000    1.000000     9.000000   40.372985    0.570557   -0.055863

 Energy terms:             smooth           local           total
   rhoval*vef             -9.162853        -5.207014       -14.369867
   rhoval*ves             -4.672156        -5.582883       -10.255038
   psnuc*ves              11.683669      -281.329269      -269.645600
   utot                    3.505757      -143.456076      -139.950319
   rho*exc                -3.089337        -6.507170        -9.596507
   rho*vxc                -4.035362        -8.590846       -12.626208
   valence chg             4.166871        -0.155888         4.010984
   valence mag             2.313366        -0.313367         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.01098   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.01098
 (warning) system not neutral, dq=0.010984

 Read qp weights ...  ef=-0.432167
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0423 -0.4303 -0.4303 -0.4303  0.1223  0.5244  0.5244  0.5244
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8413 -0.2397 -0.2397 -0.2397  0.1952  0.6195  0.6195  0.6195
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4303
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.432082;   4.000000 electrons
         Sum occ. bands:   -2.750552, incl. Bloechl correction: -0.000188
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686891    3.843189   -0.156298      1.795803    2.110788   -0.314985
       contr. to mm extrapolated for r>rmt:   0.163986 est. true mm = 1.959789
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85773  sum tc=    31.38672  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78812  sum tc=    31.54433  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958245   -1.040279    2.914770    2.914761    2.500000    2.914761
 spn 2 0    0.945543   -0.839285    2.908407    2.908402    2.500000    2.908402
 1     1    1.783090   -0.430999    2.850000    2.889107    2.250000    2.850000
 spn 2 1    0.000000   -1.121472    2.850000    2.164740    2.250000    2.850000
 2     0    0.000012   -0.811647    3.147584    3.132784    3.147584    3.147584
 spn 2 0    0.000000   -1.178899    3.147584    3.108373    3.147584    3.147584
 3     0    0.000001   -0.760508    4.102416    4.096176    4.102416    4.102416
 spn 2 0    0.000000   -1.131440    4.102416    4.085068    4.102416    4.102416

 Harris energy:
 sumev=       -2.750552  val*vef=     -14.369867   sumtv=      11.619315
 sumec=      -39.645848  cor*vef=    -102.577302   ttcor=      62.931454
 rhoeps=      -9.596507     utot=    -139.950319    ehar=     -74.996057

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00   -0.00     0.00   -0.00    0.00
 shift forces to make zero average correction:            0.00   -0.00    0.00

 srhov:     -9.160080     -5.207535    -14.367615 sumev=   -2.750552   sumtv=   11.617063
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044091   -0.156298     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008184  avg sphere pot= 0.014121  vconst=-0.008184
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.507306   charge     4.156297
 smooth rhoeps =   -3.086978 (  -2.404590,  -0.682388)
         rhomu =   -4.032327 (  -3.321656,  -0.710670)
       avg vxc =   -0.206286 (  -0.238004,  -0.174568)
 smooth rhoeps =   -3.086978 (  -2.404590,  -0.682388)
         rhomu =   -4.032327 (  -3.321656,  -0.710670)
       avg vxc =   -0.206286 (  -0.238004,  -0.174568)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336603   -3.951192  -14.287795     -7.290004   -1.791170   -9.081174

 local terms:     true           smooth         local
 rhoeps:        -9.526852      -3.020238      -6.506614
 rhomu:         -7.409883      -3.248512      -4.161371
 spin2:         -5.126100      -0.697367      -4.428734
 total:        -12.535983      -3.945878      -8.590105
 val*vef       -14.287795      -8.624546      -5.663249
 val chg:        3.686891       3.843189      -0.156298
 val mom:        1.795803       2.110788      -0.314985    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.160455        -5.206621       -14.367076
   rhoval*ves             -4.671501        -5.584515       -10.256015
   psnuc*ves              11.686114      -281.331371      -269.645258
   utot                    3.507306      -143.457943      -139.950636
   rho*exc                -3.086978        -6.506614        -9.593592
   rho*vxc                -4.032327        -8.590105       -12.622431
   valence chg             4.156297        -0.156298         4.000000
   valence mag             2.314984        -0.314985         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.617063  sumtc=        62.931047   ekin=       74.548111
 rhoep=       -9.593592   utot=      -139.950636   ehks=      -74.996118
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.405015D+03-0.870259D-26 0.405015D+03       0
 mixrho: sum smrnew new  = 0.404455D+03-0.276022D-16 0.404455D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho: dqsum rmsuns= -0.10574D-04  0.17228D-04 -0.70844D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.21e-5  last it=1.63e-5
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=6.04e-6
   tj: 0.36441   0.04615
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -6.24536166659456216E-003 -3.12268083329728189E-006
 add q= -0.006245 to preserve neutrality
 unscreened rms difference:  smooth  0.000024   local  0.000052
   screened rms difference:  smooth  0.000018   local  0.000052   tot  0.000012
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       22091 -4.92043286462462172E-006

 iors  : write restart file (binary, mesh density) 

   it  5  of 10    ehf=      -0.001157   ehk=      -0.001218
 From last iter    ehf=      -0.001137   ehk=      -0.001217
 diffe(q)= -0.000021 (0.000012)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0011572 ehk=-.0012176

 --- BNDFP:  begin iteration 6 of 10 ---
 all smrho is positive for isp=           1
 mkpot negative smrho; isp,number,min(smrho)=           2       22091 -4.92043286462462172E-006
 enforce positive smrho, to which we add srshift=  4.92043287462462154E-006

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043986   -0.155927     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008603  avg sphere pot= 0.014123  vconst=-0.008603
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.506401   charge     4.165768
 smooth rhoeps =   -3.089167 (  -2.405328,  -0.683838)
         rhomu =   -4.035151 (  -3.322709,  -0.712442)
       avg vxc =   -0.209571 (  -0.239692,  -0.179450)
 smooth rhoeps =   -3.089167 (  -2.405328,  -0.683838)
         rhomu =   -4.035151 (  -3.322709,  -0.712442)
       avg vxc =   -0.209571 (  -0.239692,  -0.179450)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.335520   -3.951841  -14.287361     -7.288017   -1.792080   -9.080097

 local terms:     true           smooth         local
 rhoeps:        -9.527377      -3.020297      -6.507080
 rhomu:         -7.410029      -3.247876      -4.162154
 spin2:         -5.126631      -0.698064      -4.428567
 total:        -12.536660      -3.945940      -8.590721
 val*vef       -14.287361      -8.624614      -5.662747
 val chg:        3.688088       3.844014      -0.155927
 val mom:        1.795515       2.109718      -0.314204    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914761 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.933856    7.422612    0.092632   -0.588094
 1      3.000000    1.000000    -5.887832    7.124453    0.143881   -0.534124
 2      3.000000    1.000000     6.000000   29.619613    0.492334   -0.085992
 3      3.000000    1.000000     9.000000   40.176819    0.569667   -0.056302

 potpus  spin 2 : pnu = 2.908402 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.135832    7.333504    0.102231   -0.559935
 1      3.000000    1.000000    -5.887832    7.132561    0.153291   -0.501024
 2      3.000000    1.000000     6.000000   29.963640    0.494261   -0.084427
 3      3.000000    1.000000     9.000000   40.372897    0.570557   -0.055863

 Energy terms:             smooth           local           total
   rhoval*vef             -9.162359        -5.207264       -14.369623
   rhoval*ves             -4.671726        -5.583394       -10.255120
   psnuc*ves              11.684527      -281.330029      -269.645502
   utot                    3.506401      -143.456712      -139.950311
   rho*exc                -3.089167        -6.507080        -9.596247
   rho*vxc                -4.035151        -8.590721       -12.625871
   valence chg             4.165768        -0.155927         4.009841
   valence mag             2.314203        -0.314204         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00984   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00984
 (warning) system not neutral, dq=0.009841

 Read qp weights ...  ef=-0.432082
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0423 -0.4303 -0.4303 -0.4303  0.1230  0.5247  0.5247  0.5247
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8412 -0.2396 -0.2396 -0.2396  0.1966  0.6200  0.6200  0.6200
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4303
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.432042;   4.000000 electrons
         Sum occ. bands:   -2.750380, incl. Bloechl correction: -0.000188
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686953    3.843323   -0.156370      1.795873    2.111545   -0.315672
       contr. to mm extrapolated for r>rmt:   0.163935 est. true mm = 1.959808
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85767  sum tc=    31.38671  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78805  sum tc=    31.54434  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958241   -1.040266    2.914761    2.914756    2.500000    2.914756
 spn 2 0    0.945540   -0.839252    2.908402    2.908399    2.500000    2.908399
 1     1    1.783160   -0.430959    2.850000    2.889123    2.250000    2.850000
 spn 2 1    0.000000   -1.120613    2.850000    2.164860    2.250000    2.850000
 2     0    0.000012   -0.811634    3.147584    3.132783    3.147584    3.147584
 spn 2 0    0.000000   -1.178886    3.147584    3.108372    3.147584    3.147584
 3     0    0.000001   -0.760501    4.102416    4.096176    4.102416    4.102416
 spn 2 0    0.000000   -1.131327    4.102416    4.085069    4.102416    4.102416

 Harris energy:
 sumev=       -2.750380  val*vef=     -14.369623   sumtv=      11.619242
 sumec=      -39.645724  cor*vef=    -102.576975   ttcor=      62.931250
 rhoeps=      -9.596247     utot=    -139.950311    ehar=     -74.996065

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00    -0.00    0.00   -0.00     0.00   -0.00    0.00
 shift forces to make zero average correction:            0.00   -0.00    0.00

 srhov:     -9.159995     -5.207625    -14.367620 sumev=   -2.750380   sumtv=   11.617240
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044111   -0.156370     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008193  avg sphere pot= 0.014119  vconst=-0.008193
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.507972   charge     4.156370
 smooth rhoeps =   -3.087133 (  -2.405015,  -0.682118)
         rhomu =   -4.032535 (  -3.322233,  -0.710302)
       avg vxc =   -0.206274 (  -0.237988,  -0.174559)
 smooth rhoeps =   -3.087133 (  -2.405015,  -0.682118)
         rhomu =   -4.032535 (  -3.322233,  -0.710302)
       avg vxc =   -0.206274 (  -0.237988,  -0.174559)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336769   -3.951089  -14.287858     -7.291059   -1.790125   -9.081184

 local terms:     true           smooth         local
 rhoeps:        -9.526929      -3.020407      -6.506522
 rhomu:         -7.409993      -3.249107      -4.160886
 spin2:         -5.126091      -0.696998      -4.429093
 total:        -12.536085      -3.946105      -8.589979
 val*vef       -14.287858      -8.624310      -5.663548
 val chg:        3.686953       3.843323      -0.156370
 val mom:        1.795873       2.111545      -0.315672    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.160450        -5.206675       -14.367125
   rhoval*ves             -4.671042        -5.584942       -10.255983
   psnuc*ves              11.686986      -281.332507      -269.645522
   utot                    3.507972      -143.458724      -139.950752
   rho*exc                -3.087133        -6.506522        -9.593655
   rho*vxc                -4.032535        -8.589979       -12.622514
   valence chg             4.156370        -0.156370         4.000000
   valence mag             2.315672        -0.315672         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.617240  sumtc=        62.931050   ekin=       74.548289
 rhoep=       -9.593655   utot=      -139.950752   ehks=      -74.996118
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.404998D+03-0.404959D-26 0.404998D+03       0
 mixrho: sum smrnew new  = 0.404503D+03-0.462070D-16 0.404503D+03       0
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho: dqsum rmsuns= -0.93979D-05  0.15634D-04  0.19786D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.11e-5  last it=1.21e-5
 AMIX: condition of normal eqns >100000. Reducing nmix to 1
 AMIX: Reducing nmix to  0: t_j exceeds tm: tj=-10.08339
 AMIX: nmix=0 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=5.54e-6
 mixrealsmooth= T
 smrho qcell: add correction to smrho= -4.92026691682515005E-003 -2.46013345841257576E-006
 add q= -0.004920 to preserve neutrality
 unscreened rms difference:  smooth  0.000022   local  0.000048
   screened rms difference:  smooth  0.000016   local  0.000048   tot  0.000011
 mixrho: all smrho is positive for isp=           1
 mixrho: warning. negative smrho; isp number min=           2       16247 -3.80819059728518912E-006

 iors  : write restart file (binary, mesh density) 

   it  6  of 10    ehf=      -0.001165   ehk=      -0.001218
 From last iter    ehf=      -0.001157   ehk=      -0.001218
 diffe(q)= -0.000008 (0.000011)    tol= 0.000010 (0.000500)   more=F
c zbak=0 mmom=1.9999997 ehf=-.0011648 ehk=-.0012178
 Exit 0 LMF 
