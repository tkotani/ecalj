#!/bin/sh

echo "myrank init = " $1 "time = " `date`
sleep 1
echo "myrank end  = " $1 "time = " `date`

exit 0

