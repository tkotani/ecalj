#!/bin/bash
if [ $1 == 1]; then
./jobmoldimer1.py_-0.30,_fsmom=2@_rstar=0.9@__B_B2dis_alatpath15
fi
if [ $1 == 2]; then
./jobmoldimer1.py_-0.20,_fsmom=2@_rstar=0.9@__B_B2dis_alatpath15
fi
if [ $1 == 3]; then
./jobmoldimer1.py_-0.10,_fsmom=2@_rstar=0.9@__B_B2dis_alatpath15
fi
if [ $1 == 4]; then
./jobmoldimer1.py_0.00,_fsmom=2@_rstar=0.9@__B_B2dis_alatpath15
fi
