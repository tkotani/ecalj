rdcmd:  lmfa --no-iactiv c -vzbak=0
 -----------------------  START LMFA     -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMFA  vn 7.00(LMFA 7.0)  verb 30,40,60
 pot:      spin-pol, XC:BH
 end of rdctrl2 in imfav7
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137
 goto mksym

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 end of mksym x
 goto defspc
 end of defspc
 goto freeat

conf:SPEC_ATOM= C : --- Table for atomic configuration ---
conf int(P)z = int(P) where P is replaced by PZ if it is semicore
conf:  isp  l  int(P) int(P)z    Qval    Qcore   CoreConf
conf:    1  0       2  2        1.000    1.000 => 1,
conf:    1  1       2  2        2.000    0.000 => 
conf:    1  2       3  3        0.000    0.000 => 
conf:    1  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------
conf:    2  0       2  2        1.000    1.000 => 1,
conf:    2  1       2  2        0.000    0.000 => 
conf:    2  2       3  3        0.000    0.000 => 
conf:    2  3       4  4        0.000    0.000 => 
conf:-----------------------------------------------------

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001
 tailsm: init
 tailsm:xxx1
 tailsm:xxx2

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753709   qtot  1.997279
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 tailsm: end
 end of freats: spid=C       

  Write mtopara.* ...
 Exit 0 LMFA 
rdcmd:  lmf  --no-iactiv c -vzbak=0
 -----------------------  START LMF      -----------------------
 ptenv() is called with EXT=c
 ptenv() not supported, but continue.
 HEADER sc C atom
 C        xxx            1           1
  mxcst switch =           1           0 F F F
  LMF  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 
 goto setcg
 lattic:

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 zzz nclass=           1
 
 lstar xxx=          -2
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F
 lstar xxx=          -2

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 gvlist: cutoff radius  13.994 gives  45911   recips of max 125000
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363587    3.701843    2.363561    1.338282
 amom    1.810990    1.143831    1.810990    1.143831    0.667159

 Smooth charge on mesh:            2.661718    moment    1.332841
 Sum of local charges:             1.338282    moments   0.667159
 Total valence charge:             4.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           0.000000
 Deviation from neutrality:       -0.000000

 --- BNDFP:  begin iteration 1 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338282     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.063910   charge     2.661718
 smooth rhoeps =   -1.494901 (  -1.109320,  -0.385581)
         rhomu =   -1.946550 (  -1.522780,  -0.423770)
       avg vxc =   -0.191348 (  -0.218128,  -0.164568)
 smooth rhoeps =   -1.494901 (  -1.109320,  -0.385581)
         rhomu =   -1.946550 (  -1.522780,  -0.423770)
       avg vxc =   -0.191348 (  -0.218128,  -0.164568)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.341410   -3.941483  -14.282893     -2.908176   -0.943828   -3.852003

 local terms:     true           smooth         local
 rhoeps:        -9.536045      -1.428951      -8.107094
 rhomu:         -7.422765      -1.450795      -5.971970
 spin2:         -5.125221      -0.410320      -4.714901
 total:        -12.547986      -1.861115     -10.686870
 val*vef       -14.282893      -6.925497      -7.357396
 val chg:        3.701843       2.363561       1.338282
 val mom:        1.810990       1.143831       0.667159    core:  -0.000000
 core chg:       2.000000       2.000000      -0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.589352    0.102212   -0.581577
 1      3.000000    1.000000    -5.887832    7.119796    0.144160   -0.533282
 2      3.000000    1.000000     4.727244   27.134665    0.465946   -0.095778
 3      3.000000    1.000000     7.577135   37.213691    0.543677   -0.062061

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.437705    0.107908   -0.555887
 1      3.000000    1.000000    -5.887832    7.130043    0.153492   -0.500465
 2      3.000000    1.000000     4.727244   27.482684    0.468116   -0.093876
 3      3.000000    1.000000     7.577135   37.415022    0.544672   -0.061530

 Energy terms:             smooth           local           total
   rhoval*vef             -3.931613       -10.430885       -14.362499
   rhoval*ves             -5.058553        -5.181775       -10.240327
   psnuc*ves               9.186373      -278.836573      -269.650199
   utot                    2.063910      -142.009174      -139.945263
   rho*exc                -1.494901        -8.107094        -9.601995
   rho*vxc                -1.946550       -10.686870       -12.633421
   valence chg             2.661718         1.338282         4.000000
   valence mag             1.332841         0.667159         2.000000
   core charge             2.000000        -0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...
 Start second band pass ...
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4290
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686856    3.838083   -0.151227      1.796589    2.141131   -0.344542
       contr. to mm extrapolated for r>rmt:   0.163680 est. true mm = 1.960270
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85523  sum tc=    31.38701  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78555  sum tc=    31.54499  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.957935   -1.038744    2.900000    2.914621    2.500000    2.914621
 spn 2 0    0.945133   -0.836887    2.900000    2.908183    2.500000    2.908183
 1     1    1.783776   -0.429110    2.850000    2.889411    2.250000    2.850000
 spn 2 1    0.000000   -1.101865    2.850000    2.167565    2.250000    2.850000
 2     0    0.000011   -0.813692    3.180000    3.132790    3.147584    3.147584
 spn 2 0    0.000000   -1.175532    3.180000    3.108512    3.147584    3.147584
 3     0    0.000001   -0.763293    4.120000    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.128828    4.120000    4.085128    4.102416    4.102416

 Harris energy:
 sumev=       -2.743233  val*vef=     -14.362499   sumtv=      11.619265
 sumec=      -39.640777  cor*vef=    -102.572782   ttcor=      62.932005
 rhoeps=      -9.601995     utot=    -139.945263    ehar=     -74.995989

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00    -0.00   -0.00   -0.00
 shift forces to make zero average correction:           -0.00   -0.00   -0.00

 srhov:     -7.491267     -6.856027    -14.347295 sumev=   -2.743233   sumtv=   11.604061
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.042660   -0.151227     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008341  avg sphere pot= 0.014058  vconst=-0.008341
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.531027   charge     4.151227
 smooth rhoeps =   -3.081515 (  -2.415640,  -0.665875)
         rhomu =   -4.025458 (  -3.336127,  -0.689331)
       avg vxc =   -0.206216 (  -0.237894,  -0.174538)
 smooth rhoeps =   -3.081515 (  -2.415640,  -0.665875)
         rhomu =   -4.025458 (  -3.336127,  -0.689331)
       avg vxc =   -0.206216 (  -0.237894,  -0.174538)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.331832   -3.946568  -14.278400     -7.320814   -1.729922   -9.050735

 local terms:     true           smooth         local
 rhoeps:        -9.525314      -3.014713      -6.510601
 rhomu:         -7.408850      -3.263013      -4.145837
 spin2:         -5.125107      -0.675917      -4.449191
 total:        -12.533957      -3.938930      -8.595028
 val*vef       -14.278400      -8.607508      -5.670893
 val chg:        3.686856       3.838083      -0.151227
 val mom:        1.796589       2.141131      -0.344542    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.130114        -5.227666       -14.357779
   rhoval*ves             -4.661428        -5.587080       -10.248508
   psnuc*ves              11.723481      -281.355166      -269.631684
   utot                    3.531027      -143.471123      -139.940096
   rho*exc                -3.081515        -6.510601        -9.592116
   rho*vxc                -4.025458        -8.595028       -12.620486
   valence chg             4.151227        -0.151227         4.000000
   valence mag             2.344542        -0.344542         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.604061  sumtc=        62.932006   ekin=       74.536067
 rhoep=       -9.592116   utot=      -139.940096   ehks=      -74.996145
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.249660D+03-0.119196D-25 0.249660D+03       0
 mixrho: sum smrnew new  = 0.405986D+03-0.112617D-15 0.405986D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns=  0.14895D-02  0.89309D-02  0.80980D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=8.23e-3
 AMIX: nmix=0 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=4.12e-3
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  2.37885994680553381E-007  1.18942997340276717E-010
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=      -0.001089   ehk=      -0.001245
h zbak=0 mmom=1.9999996 ehf=-.0010887 ehk=-.0012453

 --- BNDFP:  begin iteration 2 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.167431    0.593528     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.007474  avg sphere pot= 0.016799  vconst=-0.007474
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1  -0.000000  |

 smooth rhoves      2.744959   charge     3.406472
 smooth rhoeps =   -2.245018 (  -1.724186,  -0.520833)
         rhomu =   -2.928780 (  -2.376334,  -0.552446)
       avg vxc =   -0.199514 (  -0.229068,  -0.169961)
 smooth rhoeps =   -2.245018 (  -1.724186,  -0.520833)
         rhomu =   -2.928780 (  -2.376334,  -0.552446)
       avg vxc =   -0.199514 (  -0.229068,  -0.169961)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336624   -3.944025  -14.280650     -4.949607   -1.313405   -6.263012

 local terms:     true           smooth         local
 rhoeps:        -9.530675      -2.178691      -7.351985
 rhomu:         -7.415802      -2.303847      -5.111955
 spin2:         -5.125164      -0.539014      -4.586150
 total:        -12.540966      -2.842861      -9.698105
 val*vef       -14.280650      -7.814336      -6.466314
 val chg:        3.694350       3.100822       0.593528
 val mom:        1.803790       1.642481       0.161309    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000004

 potpus  spin 1 : pnu = 2.914621 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.915138    7.420308    0.092781   -0.587822
 1      3.000000    1.000000    -5.887832    7.122106    0.143982   -0.533847
 2      3.000000    1.000000     6.000000   29.627208    0.492387   -0.085955
 3      3.000000    1.000000     9.000000   40.182472    0.569697   -0.056289

 potpus  spin 2 : pnu = 2.908183 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.110306    7.333840    0.102416   -0.559730
 1      3.000000    1.000000    -5.887832    7.130958    0.153352   -0.500889
 2      3.000000    1.000000     6.000000   29.968825    0.494298   -0.084402
 3      3.000000    1.000000     9.000000   40.376875    0.570579   -0.055854

 Energy terms:             smooth           local           total
   rhoval*vef             -6.342469        -8.017636       -14.360105
   rhoval*ves             -4.965010        -5.279441       -10.244451
   psnuc*ves              10.454927      -280.095869      -269.640942
   utot                    2.744959      -142.687655      -139.942696
   rho*exc                -2.245018        -7.351985        -9.597003
   rho*vxc                -2.928780        -9.698105       -12.626886
   valence chg             3.406472         0.593528         4.000000
   valence mag             1.838691         0.161309         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.430662
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0420 -0.4301 -0.4301 -0.4301  0.1300  0.5276  0.5276  0.5276
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8403 -0.2387 -0.2387 -0.2387  0.2084  0.6247  0.6247  0.6247
 Est Ef = -0.431 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4301
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431788;   4.000000 electrons
         Sum occ. bands:   -2.748503, incl. Bloechl correction: -0.000182
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687502    3.843274   -0.155772      1.796751    2.129300   -0.332549
       contr. to mm extrapolated for r>rmt:   0.163407 est. true mm = 1.960158
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85779  sum tc=    31.38712  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78816  sum tc=    31.54494  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958103   -1.040086    2.914621    2.914675    2.500000    2.914675
 spn 2 0    0.945375   -0.838529    2.908183    2.908298    2.500000    2.908298
 1     1    1.784011   -0.430478    2.850000    2.889367    2.250000    2.850000
 spn 2 1    0.000000   -1.105941    2.850000    2.167020    2.250000    2.850000
 2     0    0.000012   -0.813077    3.147584    3.132769    3.147584    3.147584
 spn 2 0    0.000000   -1.179180    3.147584    3.108366    3.147584    3.147584
 3     0    0.000001   -0.762287    4.102416    4.096165    4.102416    4.102416
 spn 2 0    0.000000   -1.130576    4.102416    4.085089    4.102416    4.102416

 Harris energy:
 sumev=       -2.748503  val*vef=     -14.360105   sumtv=      11.611602
 sumec=      -39.645953  cor*vef=    -102.577958   ttcor=      62.932005
 rhoeps=      -9.597003     utot=    -139.942696    ehar=     -74.996093

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00    0.00   -0.00     0.00    0.00    0.00     0.00   -0.00    0.00
 shift forces to make zero average correction:            0.00   -0.00    0.00

 srhov:     -8.377939     -5.986974    -14.364913 sumev=   -2.748503   sumtv=   11.616411
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043942   -0.155772     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008327  avg sphere pot= 0.014077  vconst=-0.008327
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.521775   charge     4.155771
 smooth rhoeps =   -3.087411 (  -2.413337,  -0.674075)
         rhomu =   -4.033057 (  -3.333377,  -0.699680)
       avg vxc =   -0.206142 (  -0.237811,  -0.174472)
 smooth rhoeps =   -3.087411 (  -2.413337,  -0.674075)
         rhomu =   -4.033057 (  -3.333377,  -0.699680)
       avg vxc =   -0.206142 (  -0.237811,  -0.174472)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337591   -3.949248  -14.286839     -7.313545   -1.759817   -9.073362

 local terms:     true           smooth         local
 rhoeps:        -9.527341      -3.020795      -6.506546
 rhomu:         -7.410834      -3.260435      -4.150399
 spin2:         -5.125792      -0.686334      -4.439459
 total:        -12.536626      -3.946769      -8.589857
 val*vef       -14.286839      -8.617452      -5.669386
 val chg:        3.687502       3.843274      -0.155772
 val mom:        1.796751       2.129300      -0.332549    core:   0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.152526        -5.213477       -14.366003
   rhoval*ves             -4.663560        -5.590960       -10.254520
   psnuc*ves              11.707110      -281.353874      -269.646764
   utot                    3.521775      -143.472417      -139.950642
   rho*exc                -3.087411        -6.506546        -9.593957
   rho*vxc                -4.033057        -8.589857       -12.622914
   valence chg             4.155771        -0.155772         4.000000
   valence mag             2.332549        -0.332549         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.616411  sumtc=        62.932059   ekin=       74.548469
 rhoep=       -9.593957   utot=      -139.950642   ehks=      -74.996130
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.327823D+03-0.884340D-26 0.327823D+03       0
 mixrho: sum smrnew new  = 0.405520D+03 0.655045D-16 0.405520D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns=  0.74930D-03  0.44837D-02 -0.19850D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=4.12e-3  last it=8.23e-3
 AMIX: nmix=1 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=2.06e-3
   tj:-1.00023
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  9.75126318858432484E-008  4.87563159429216371E-011
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=      -0.001193   ehk=      -0.001230
 From last iter    ehf=      -0.001089   ehk=      -0.001245
 diffe(q)= -0.000104 (0.004120)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0011928 ehk=-.0012297

 --- BNDFP:  begin iteration 3 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.043967   -0.155859     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008327  avg sphere pot= 0.014077  vconst=-0.008327
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.521871   charge     4.155859
 smooth rhoeps =   -3.087514 (  -2.413421,  -0.674093)
         rhomu =   -4.033191 (  -3.333494,  -0.699697)
       avg vxc =   -0.206143 (  -0.237812,  -0.174473)
 smooth rhoeps =   -3.087514 (  -2.413421,  -0.674093)
         rhomu =   -4.033191 (  -3.333494,  -0.699697)
       avg vxc =   -0.206143 (  -0.237812,  -0.174473)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337592   -3.949248  -14.286840     -7.313838   -1.759872   -9.073710

 local terms:     true           smooth         local
 rhoeps:        -9.527338      -3.020897      -6.506441
 rhomu:         -7.410829      -3.260552      -4.150277
 spin2:         -5.125794      -0.686351      -4.439443
 total:        -12.536623      -3.946903      -8.589720
 val*vef       -14.286840      -8.617540      -5.669301
 val chg:        3.687501       3.843360      -0.155859
 val mom:        1.796750       2.129356      -0.332606    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914675 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.922285    7.424206    0.092686   -0.588067
 1      3.000000    1.000000    -5.887832    7.124858    0.143874   -0.534134
 2      3.000000    1.000000     6.000000   29.618667    0.492326   -0.085997
 3      3.000000    1.000000     9.000000   40.176011    0.569662   -0.056304

 potpus  spin 2 : pnu = 2.908298 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.123646    7.335210    0.102303   -0.559880
 1      3.000000    1.000000    -5.887832    7.132888    0.153291   -0.501012
 2      3.000000    1.000000     6.000000   29.963104    0.494256   -0.084430
 3      3.000000    1.000000     9.000000   40.372381    0.570553   -0.055865

 Energy terms:             smooth           local           total
   rhoval*vef             -9.152874        -5.213131       -14.366005
   rhoval*ves             -4.663513        -5.591008       -10.254522
   psnuc*ves              11.707256      -281.353970      -269.646714
   utot                    3.521871      -143.472489      -139.950618
   rho*exc                -3.087514        -6.506441        -9.593955
   rho*vxc                -4.033191        -8.589720       -12.622911
   valence chg             4.155859        -0.155859         4.000000
   valence mag             2.332606        -0.332606         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Read qp weights ...  ef=-0.431788
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0422 -0.4301 -0.4301 -0.4301  0.1292  0.5275  0.5275  0.5275
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8409 -0.2391 -0.2391 -0.2391  0.2086  0.6251  0.6251  0.6251
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4301
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431878;   4.000000 electrons
         Sum occ. bands:   -2.749582, incl. Bloechl correction: -0.000186
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687632    3.847184   -0.159552      1.796591    2.119558   -0.322967
       contr. to mm extrapolated for r>rmt:   0.163406 est. true mm = 1.959997
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85748  sum tc=    31.38660  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78781  sum tc=    31.54438  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958209   -1.040328    2.914675    2.914725    2.500000    2.914725
 spn 2 0    0.945520   -0.839117    2.908298    2.908381    2.500000    2.908381
 1     1    1.783890   -0.430783    2.850000    2.889284    2.250000    2.850000
 spn 2 1    0.000000   -1.109027    2.850000    2.166551    2.250000    2.850000
 2     0    0.000012   -0.811667    3.147584    3.132773    3.147584    3.147584
 spn 2 0    0.000000   -1.178986    3.147584    3.108359    3.147584    3.147584
 3     0    0.000001   -0.760597    4.102416    4.096169    4.102416    4.102416
 spn 2 0    0.000000   -1.130454    4.102416    4.085082    4.102416    4.102416

 Harris energy:
 sumev=       -2.749582  val*vef=     -14.366005   sumtv=      11.616423
 sumec=      -39.645289  cor*vef=    -102.577321   ttcor=      62.932032
 rhoeps=      -9.593955     utot=    -139.950618    ehar=     -74.996118

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.174447     -5.195339    -14.369786 sumev=   -2.749582   sumtv=   11.620204
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.045009   -0.159552     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008290  avg sphere pot= 0.014095  vconst=-0.008290
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.515355   charge     4.159551
 smooth rhoeps =   -3.091772 (  -2.411230,  -0.680542)
         rhomu =   -4.038668 (  -3.330764,  -0.707904)
       avg vxc =   -0.206150 (  -0.237828,  -0.174472)
 smooth rhoeps =   -3.091772 (  -2.411230,  -0.680542)
         rhomu =   -4.038668 (  -3.330764,  -0.707904)
       avg vxc =   -0.206150 (  -0.237828,  -0.174472)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.339036   -3.950322  -14.289358     -7.308567   -1.783451   -9.092018

 local terms:     true           smooth         local
 rhoeps:        -9.527881      -3.025206      -6.502676
 rhomu:         -7.411279      -3.257848      -4.153431
 spin2:         -5.126058      -0.694597      -4.431461
 total:        -12.537336      -3.952445      -8.584892
 val*vef       -14.289358      -8.625464      -5.663894
 val chg:        3.687632       3.847184      -0.159552
 val mom:        1.796591       2.119558      -0.322967    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.171118        -5.197341       -14.368459
   rhoval*ves             -4.665896        -5.590412       -10.256309
   psnuc*ves              11.696606      -281.346001      -269.649396
   utot                    3.515355      -143.468207      -139.952852
   rho*exc                -3.091772        -6.502676        -9.594448
   rho*vxc                -4.038668        -8.584892       -12.623560
   valence chg             4.159551        -0.159552         4.000000
   valence mag             2.322967        -0.322967         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.620204  sumtc=        62.930978   ekin=       74.551182
 rhoep=       -9.594448   utot=      -139.952852   ehks=      -74.996118
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.405529D+03-0.913513D-26 0.405529D+03       0
 mixrho: sum smrnew new  = 0.405157D+03 0.117970D-16 0.405157D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns=  0.36926D-05  0.71352D-04  0.44457D-19
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=6.10e-5  last it=4.12e-3
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=3.05e-5
   tj:-1.32193   0.66096
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  2.12907457081135121E-007  1.06453728540567582E-010
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=      -0.001218   ehk=      -0.001218
 From last iter    ehf=      -0.001193   ehk=      -0.001230
 diffe(q)= -0.000025 (0.000061)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0012178 ehk=-.0012177

 --- BNDFP:  begin iteration 4 of 10 ---
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044850   -0.158991     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008296  avg sphere pot= 0.014092  vconst=-0.008296
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.516531   charge     4.158991
 smooth rhoeps =   -3.091125 (  -2.411663,  -0.679462)
         rhomu =   -4.037837 (  -3.331314,  -0.706524)
       avg vxc =   -0.206149 (  -0.237826,  -0.174473)
 smooth rhoeps =   -3.091125 (  -2.411663,  -0.679462)
         rhomu =   -4.037837 (  -3.331314,  -0.706524)
       avg vxc =   -0.206149 (  -0.237826,  -0.174473)

 locpot:
  i job kmax lfltwf=           0           1           3 T

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.338789   -3.950140  -14.288929     -7.309679   -1.779495   -9.089174

 local terms:     true           smooth         local
 rhoeps:        -9.527807      -3.024550      -6.503257
 rhomu:         -7.411212      -3.258393      -4.152819
 spin2:         -5.126027      -0.693210      -4.432817
 total:        -12.537240      -3.951603      -8.585637
 val*vef       -14.288929      -8.624184      -5.664745
 val chg:        3.687609       3.846600      -0.158991
 val mom:        1.796617       2.121262      -0.324644    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000005

 potpus  spin 1 : pnu = 2.914725 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.929076    7.423355    0.092661   -0.588038
 1      3.000000    1.000000    -5.887832    7.124980    0.143891   -0.534066
 2      3.000000    1.000000     6.000000   29.619043    0.492328   -0.085995
 3      3.000000    1.000000     9.000000   40.176193    0.569663   -0.056304

 potpus  spin 2 : pnu = 2.908381 2.850000 3.147584 4.102416

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.133448    7.333956    0.102256   -0.559862
 1      3.000000    1.000000    -5.887832    7.133182    0.153310   -0.500939
 2      3.000000    1.000000     6.000000   29.963416    0.494257   -0.084428
 3      3.000000    1.000000     9.000000   40.372480    0.570554   -0.055864

 Energy terms:             smooth           local           total
   rhoval*vef             -9.168285        -5.199755       -14.368040
   rhoval*ves             -4.665458        -5.590546       -10.256004
   psnuc*ves              11.698520      -281.348124      -269.649604
   utot                    3.516531      -143.469335      -139.952804
   rho*exc                -3.091125        -6.503257        -9.594382
   rho*vxc                -4.037837        -8.585637       -12.623474
   valence chg             4.158991        -0.158991         4.000000
   valence mag             2.324644        -0.324644         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.431878
 end of suham2
 -------- qplist --------
    1   0.000   0.000   0.000
    2   0.125   0.125  -0.125
    3   0.250   0.250  -0.250
    4   0.250   0.000   0.000
    5   0.375   0.125  -0.125
    6   0.500   0.250  -0.250
    7   0.500   0.000   0.000
    8   0.500   0.250   0.000
 sigmamode= F
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0419 -0.4299 -0.4299 -0.4299  0.1292  0.5276  0.5276  0.5276
  mode napw           0           0
  end of hambls mode=           0
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8406 -0.2389 -0.2389 -0.2389  0.2087  0.6253  0.6253  0.6253
 Est Ef = -0.432 < evl(4)=-0.430 ... using qval=4.0, revise to -0.4299
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0
  mode napw           0           0
  end of hambls mode=           0

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.431601;   4.000000 electrons
         Sum occ. bands:   -2.748479, incl. Bloechl correction: -0.000186
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.687408    3.843782   -0.156374      1.796413    2.117440   -0.321026
       contr. to mm extrapolated for r>rmt:   0.163546 est. true mm = 1.959960
 getcor:  qcore=  2.00  qsc=  2.00  konf = 2  2  3  4 
 sum q= 1.00  sum ec=   -19.85678  sum tc=    31.38650  rho(rmax) 0.00000
 sum q= 1.00  sum ec=   -19.78710  sum tc=    31.54427  rho(rmax) 0.00000

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958190   -1.040040    2.914725    2.914715    2.500000    2.914715
 spn 2 0    0.945497   -0.838848    2.908381    2.908372    2.500000    2.908372
 1     1    1.783709   -0.430517    2.850000    2.889253    2.250000    2.850000
 spn 2 1    0.000000   -1.108976    2.850000    2.166536    2.250000    2.850000
 2     0    0.000012   -0.811504    3.147584    3.132775    3.147584    3.147584
 spn 2 0    0.000000   -1.178841    3.147584    3.108360    3.147584    3.147584
 3     0    0.000001   -0.760438    4.102416    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.130323    4.102416    4.085082    4.102416    4.102416

 Harris energy:
 sumev=       -2.748479  val*vef=     -14.368040   sumtv=      11.619562
 sumec=      -39.643885  cor*vef=    -102.575390   ttcor=      62.931505
 rhoeps=      -9.594382     utot=    -139.952804    ehar=     -74.996120

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1   -0.00   -0.00   -0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.159764     -5.206453    -14.366217 sumev=   -2.748479   sumtv=   11.617738
 all smrho is positive for isp=           1
 all smrho is positive for isp=           2

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.044112   -0.156374     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008266  avg sphere pot= 0.014102  vconst=-0.008266
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.513777   charge     4.156373
 smooth rhoeps =   -3.087504 (  -2.407820,  -0.679684)
         rhomu =   -4.033069 (  -3.326011,  -0.707058)
       avg vxc =   -0.206181 (  -0.237866,  -0.174495)
 smooth rhoeps =   -3.087504 (  -2.407820,  -0.679684)
         rhomu =   -4.033069 (  -3.326011,  -0.707058)
       avg vxc =   -0.206181 (  -0.237866,  -0.174495)

 locpot:
  i job kmax lfltwf=           0           0           3 F

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=F
 === rho1 valence true density ===
 === rho2 valence counter density ===
 === rhol1 valence+core density ===
 === rho2 ->valence+smooth core density ===

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.337698   -3.950027  -14.287724     -7.297471   -1.780895   -9.078366

 local terms:     true           smooth         local
 rhoeps:        -9.527394      -3.020882      -6.506512
 rhomu:         -7.410735      -3.253029      -4.157705
 spin2:         -5.125961      -0.693744      -4.432217
 total:        -12.536696      -3.946773      -8.589922
 val*vef       -14.287724      -8.621175      -5.666549
 val chg:        3.687408       3.843782      -0.156374
 val mom:        1.796413       2.117440      -0.321026    core:  -0.000000
 core chg:       2.000000       2.000000       0.000000

 Energy terms:             smooth           local           total
   rhoval*vef             -9.157526        -5.209359       -14.366885
   rhoval*ves             -4.667267        -5.587978       -10.255245
   psnuc*ves              11.694821      -281.340799      -269.645978
   utot                    3.513777      -143.464388      -139.950612
   rho*exc                -3.087504        -6.506512        -9.594017
   rho*vxc                -4.033069        -8.589922       -12.622991
   valence chg             4.156373        -0.156374         4.000000
   valence mag             2.321026        -0.321026         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:     -0.00000

 Kohn-Sham energy:
 sumtv=       11.617738  sumtc=        62.930770   ekin=       74.548509
 rhoep=       -9.594017   utot=      -139.950612   ehks=      -74.996120
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
 mixrho: sum smrho  init = 0.405227D+03 0.205022D-26 0.405227D+03       0
 mixrho: sum smrnew new  = 0.404837D+03 0.123231D-16 0.404837D+03       0
  
 mixing: mode=A  nmix=2  beta=.5
 mixrho: dqsum rmsuns= -0.26176D-05  0.24184D-04 -0.69125D-20
 mixrealsmooth= T
 wgtsmooth=  2.82842712474619005E-003
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=2.16e-5  last it=6.10e-5
 AMIX: nmix=2 mmix=8  nelts=252052  beta=0.5  tm=5  rmsdel=1.08e-5
   tj:-0.14017   0.00557
 mixrealsmooth= T
 smrho qcell: add correction to smrho=  1.66486367081386533E-007  8.32431835406932867E-011
 mixrho: all smrho is positive for isp=           1
 mixrho: all smrho is positive for isp=           2

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=      -0.001220   ehk=      -0.001220
 From last iter    ehf=      -0.001218   ehk=      -0.001218
 diffe(q)= -0.000002 (0.000022)    tol= 0.000010 (0.000500)   more=F
c zbak=0 mmom=1.9999997 ehf=-.0012197 ehk=-.0012197
 Exit 0 LMF 
