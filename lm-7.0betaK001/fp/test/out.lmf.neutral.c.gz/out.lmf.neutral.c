rdcmd:  lmfa --no-iactiv c -vzbak=0
 -----------------------  START LMFA (80000K)  -----------------------
 HEADER sc C atom

 LMFA:     alat = 7.93701  nbas = 1  nspec = 1  vn 7.00(LMFA 7.0)  verb 30,40,|
 pot:      spin-pol, XC:BH

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion

 Species C:  Z=6  Qc=2  R=3.000000  Q=0  mom=2
 mesh:   rmt=3.000000  rmax=19.671121  a=0.02  nr=369  nr(rmax)=463
  Pl=  2.5     2.5     3.5     4.5     spn 2   2.5     2.5     3.5     4.5    
  Ql=  1.0     2.0     0.0     0.0     spn 2   1.0     0.0     0.0     0.0    

  iter     qint         drho          vh0          rho0          vsum     beta
    1    6.000000   5.461E+02       30.0000    0.2984E+02      -12.0633   0.30
   50    6.000000   3.935E-05       29.2312    0.1279E+03      -59.7470   0.30


 sumev=-2.876387  etot=-74.994908  eref=-74.994900  diff= -0.000008

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.425  -0.888      15.8     35.1   -1.07382  -1.07383    2.91   1.00
 1  31   1.429  -0.336      65.9    157.3   -0.46562  -0.46569    2.89   2.00
 eigenvalue sum:  exact  -2.00520    opt basis  -2.00507    error 0.00013

 Optimise free-atom basis for species C, rmt=3
 l  it    Rsm      Eh     stiffR   stiffE      Eval      Exact     Pnu    Ql
 0  41   1.461  -0.748      17.8     52.8   -0.87118  -0.87119    2.91   1.00
 1  28   1.494  -0.209      80.9    335.8   -0.27747  -0.27759    2.87   0.00
 eigenvalue sum:  exact  -0.87119    opt basis  -0.87118    error 0.00001

 tailsm: fit tails to 6 smoothed hankels, rmt= 3.00000, rsm= 1.50000
    q(fit):     0.243570    rms diff:   0.000004
    fit: r>rmt  0.243570   r<rmt  1.753711   qtot  1.997282
    rho: r>rmt  0.243570   r<rmt  2.756430   qtot  3.000000

 tailsm: spin 2 ...
    q(fit):     0.054561    rms diff:   0.000002
    fit: r>rmt  0.054561   r<rmt  0.609878   qtot  0.664439
    rho: r>rmt  0.054561   r<rmt  0.945439   qtot  1.000000
 Exit 0 LMFA 
 CPU time:    0.540s     Wed Feb 11 11:43:33 2009   on waldo.eas.asu.edu
 wkinfo:  used   101 K  workspace of 80000 K   in   0 K calls
rdcmd:  lmf  --no-iactiv c -vzbak=0
 -----------------------  START LMF (80000K)  -----------------------
 HEADER sc C atom

 LMF:      alat = 7.93701  nbas = 1  nspec = 1  vn 7.00(LMF 7.0)  verb 30,40,60
 special:  forces
 pot:      spin-pol, XC:BH
 bz:       metal(2), tetra, invit 

                Plat                                  Qlat
   1.000000   1.000000   0.000000        0.500000   0.500000  -0.500000
   1.000000   0.000000   1.000000        0.500000  -0.500000   0.500000
   0.000000   1.000000   1.000000       -0.500000   0.500000   0.500000
  Cell vol= 1000.000000

 LATTC:  as= 2.000   tol=1.00E-08   alat= 7.93701   awald= 0.200
         r1=  3.459   nkd=  79      q1=  2.571   nkg= 137

 SGROUP: 1 symmetry operations from 0 generators
 SYMLAT: Bravais system is cubic with 48 symmetry operations.
 SYMCRY: crystal invariant under 48 symmetry operations for tol=1e-5
 GROUPG: the following are sufficient to generate the space group:
         i*r3(-1,1,1) r4z
         i*r3(-1,1,1) r4z
 MKSYM:  found 48 space group operations ... includes inversion
 
 BZMESH:  8 irreducible QP from 64 ( 4 4 4 )  shift= F F F

 species data:  augmentation                           density
 spec       rmt   rsma lmxa kmxa      lmxl     rg   rsmv  kmxv foca   rfoca
 C        3.000  1.200    3    3         3  0.750  1.500    15    0   1.200

 GVLIST: gmax = 13.99 a.u. created 45911 vectors of 125000 (36%)
         mesh has 50 x 50 x 50 divisions; length 0.224, 0.224, 0.224
 SGVSYM: 1207 symmetry stars found for 45911 reciprocal lattice vectors
 

 Makidx:  hamiltonian dimensions Low, Int, High, Negl: 8 0 24 0
 suham :  16 augmentation channels, 16 local potential channels  Maximum lmxa=3

 sugcut:  make orbital-dependent reciprocal vector cutoffs for tol= 1.00E-06
 spec      l    rsm    eh     gmax    last term    cutoff
  C        0    1.30  -0.70   5.718    1.05E-06    3143 
  C        1    1.10  -0.20   7.226    1.06E-06    6375 
  C        0    0.80  -1.50   9.292    1.08E-06   13539 
  C        1    0.80  -1.00  10.038    1.00E-06   16961 

 iors  : read restart file (binary, mesh density) 
 iors  : empty file ... nothing read

 rdovfa: read and overlap free-atom densities (mesh density) ...
 rdovfa: expected C,       read C        with rmt=  3.0000  mesh   369  0.020

 Free atom and overlapped crystal site charges:
   ib    true(FA)    smooth(FA)  true(OV)    smooth(OV)    local
    1    3.701869    2.363589    3.701843    2.363564    1.338280
 amom    1.810990    1.143834    1.810990    1.143833    0.667157

 Smooth charge on mesh:            2.661720    moment    1.332843
 Sum of local charges:             1.338280    moments   0.667157
 Total valence charge:             4.000000    moment    2.000000
 Sum of core charges:              2.000000    moment    0.000000
 Sum of nuclear charges:          -6.000000
 Homogeneous background:           0.000000
 Deviation from neutrality:        0.000000

 --- BNDFP:  begin iteration 1 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.377522    1.338280     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.006607  avg sphere pot= 0.019541  vconst=-0.006607
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.063913   charge     2.661720
 smooth rhoeps =   -1.494903 (  -1.109322,  -0.385581)
         rhomu =   -1.946553 (  -1.522783,  -0.423770)
       avg vxc =   -0.191348 (  -0.218128,  -0.164568)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.341410   -3.941483  -14.282893     -2.908182   -0.943828   -3.852010

 local terms:     true           smooth         local
 rhoeps:        -9.536045      -1.428953      -8.107092
 rhomu:         -7.422765      -1.450798      -5.971967
 spin2:         -5.125221      -0.410320      -4.714900
 total:        -12.547986      -1.861118     -10.686867
 val*vef       -14.282893      -6.925500      -7.357392
 val chg:        3.701843       2.363564       1.338280
 val mom:        1.810990       1.143833       0.667157    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.900000 2.850000 3.180000 4.120000
 l        enu         v           c          srdel        qpar        ppar
 0     -1.054715   -1.268528   -1.158163    0.198868      2.7906    0.901141
 1     -0.471084   -1.054270   -0.468773    0.175050     19.1074    0.930214
 2     -0.328679   -0.621646    1.519432    0.353874     17.0973    6.142397
 3     -0.115033   -0.556834    3.369830    0.400985     24.4205   10.664440

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.589352    0.102212   -0.581577
 1      3.000000    1.000000    -5.887832    7.119796    0.144160   -0.533282
 2      3.000000    1.000000     4.727244   27.134665    0.465946   -0.095778
 3      3.000000    1.000000     7.577135   37.213691    0.543677   -0.062061

 potpus  spin 2 : pnu = 2.900000 2.850000 3.180000 4.120000
 l        enu         v           c          srdel        qpar        ppar
 0     -0.846590   -1.087566   -0.962512    0.211082      2.8067    0.936237
 1     -0.269118   -0.929135   -0.266498    0.186383     19.0749    0.984262
 2     -0.216979   -0.512409    1.659287    0.357600     16.9824    6.304590
 3     -0.011628   -0.454896    3.495411    0.402800     24.3466   10.791136

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000    -9.233051    7.437705    0.107908   -0.555887
 1      3.000000    1.000000    -5.887832    7.130043    0.153492   -0.500465
 2      3.000000    1.000000     4.727244   27.482684    0.468116   -0.093876
 3      3.000000    1.000000     7.577135   37.415022    0.544672   -0.061530

 Energy terms:             smooth           local           total
   rhoval*vef             -3.931620       -10.430878       -14.362499
   rhoval*ves             -5.058553        -5.181774       -10.240327
   psnuc*ves               9.186379      -278.836578      -269.650199
   utot                    2.063913      -142.009176      -139.945263
   rho*exc                -1.494903        -8.107092        -9.601995
   rho*vxc                -1.946553       -10.686867       -12.633421
   valence chg             2.661720         1.338280         4.000000
   valence mag             1.332843         0.667157         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Incompatible or missing qp weights file ...
 Start first of two band passes ...
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...
 Start second band pass ...
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0407 -0.4290 -0.4290 -0.4290  0.1321  0.5284  0.5284  0.5284
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8387 -0.2374 -0.2374 -0.2374  0.2088  0.6249  0.6249  0.6249
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4290

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430662;   4.000000 electrons
         Sum occ. bands:   -2.743233, incl. Bloechl correction: -0.000179
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.686856    3.838083   -0.151227      1.796589    2.141131   -0.344542
       contr. to mm extrapolated for r>rmt:   0.163680 est. true mm = 1.960270

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.957935   -1.038744    2.900000    2.914621    2.500000    2.914621
 spn 2 0    0.945133   -0.836887    2.900000    2.908183    2.500000    2.908183
 1     1    1.783776   -0.429110    2.850000    2.889411    2.250000    2.850000
 spn 2 1    0.000000   -1.101865    2.850000    2.167565    2.250000    2.850000
 2     0    0.000011   -0.813692    3.180000    3.132790    3.147584    3.147584
 spn 2 0    0.000000   -1.175532    3.180000    3.108512    3.147584    3.147584
 3     0    0.000001   -0.763293    4.120000    4.096170    4.102416    4.102416
 spn 2 0    0.000000   -1.128828    4.120000    4.085128    4.102416    4.102416

 Harris energy:
 sumev=       -2.743233  val*vef=     -14.362499   sumtv=      11.619265
 sumec=      -39.640777  cor*vef=    -102.572782   ttcor=      62.932005
 rhoeps=      -9.601995     utot=    -139.945263    ehar=     -74.995989

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -7.491271     -6.856024    -14.347295 sumev=   -2.743233   sumtv=   11.604061

 Kohn-Sham energy:
 sumtv=       11.604061  sumtc=        62.932006   ekin=       74.536067
 rhoep=       -9.592116   utot=      -139.940096   ehks=      -74.996145
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 0.  RMS DQ=1.35e-2
 mixrho: (warning) scr. and lin-mixed densities had 1625 and 405 negative points
 AMIX: nmix=0 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=6.75e-3
 unscreened rms difference:  smooth  0.010354   local  0.036279
   screened rms difference:  smooth  0.010366   local  0.036279   tot  0.013495

 iors  : write restart file (binary, mesh density) 

   it  1  of 10    ehf=      -0.001089   ehk=      -0.001245
h zbak=0 mmom=1.9999996 ehf=-.0010887 ehk=-.0012453

 --- BNDFP:  begin iteration 2 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1    0.167431    0.593526     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.008356  avg sphere pot= 0.016799  vconst=-0.008356
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      2.743364   charge     3.406474
 smvxcm (warning) mesh density negative at 37543 points:  rhomin=-5.54e-6
 smooth rhoeps =   -2.247132 (  -1.725337,  -0.521795)
         rhomu =   -2.930651 (  -2.376967,  -0.553684)
       avg vxc =   -0.176671 (  -0.195603,  -0.157740)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.336776   -3.945468  -14.282244     -4.949780   -1.314639   -6.264420

 local terms:     true           smooth         local
 rhoeps:        -9.532961      -2.180845      -7.352116
 rhomu:         -7.417504      -2.305477      -5.112028
 spin2:         -5.126437      -0.540186      -4.586251
 total:        -12.543941      -2.845662      -9.698279
 val*vef       -14.282244      -7.814991      -6.467253
 val chg:        3.697600       3.104074       0.593526
 val mom:        1.803790       1.642482       0.161307    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000003

 potpus  spin 1 : pnu = 2.914621 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -1.039326   -1.271736   -1.159329    0.200048      2.8088    0.891231
 1     -0.471549   -1.053722   -0.469241    0.174921     19.1023    0.929744
 2     -0.620206   -0.620206    1.604661    0.368909     16.3476    6.930912
 3     -0.555126   -0.555126    3.518185    0.416965     23.4276   11.933235

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.915138    7.418302    0.092820   -0.587641
 1      3.000000    1.000000    -5.887832    7.121418    0.144054   -0.533608
 2      3.000000    1.000000     6.000000   29.630950    0.492412   -0.085937
 3      3.000000    1.000000     9.000000   40.184999    0.569710   -0.056283

 potpus  spin 2 : pnu = 2.908183 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -0.837968   -1.090499   -0.963997    0.211860      2.8184    0.929793
 1     -0.270137   -0.929626   -0.267519    0.186317     19.0733    0.983998
 2     -0.512201   -0.512201    1.742491    0.372407     16.2570    7.102011
 3     -0.454507   -0.454507    3.641683    0.418658     23.3691   12.064392

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.110306    7.331756    0.102466   -0.559526
 1      3.000000    1.000000    -5.887832    7.130564    0.153438   -0.500623
 2      3.000000    1.000000     6.000000   29.973160    0.494326   -0.084382
 3      3.000000    1.000000     9.000000   40.379853    0.570594   -0.055847

 Energy terms:             smooth           local           total
   rhoval*vef             -6.343231        -8.017822       -14.361053
   rhoval*ves             -4.963149        -5.280236       -10.243385
   psnuc*ves              10.449878      -280.096509      -269.646631
   utot                    2.743364      -142.688372      -139.945008
   rho*exc                -2.247132        -7.352116        -9.599248
   rho*vxc                -2.930651        -9.698279       -12.628930
   valence chg             3.406474         0.593526         4.000000
   valence mag             1.838692         0.161307         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.430662
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0411 -0.4293 -0.4293 -0.4293  0.1400  0.5311  0.5311  0.5311
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8396 -0.2382 -0.2382 -0.2382  0.2119  0.6260  0.6260  0.6260
 Est Ef = -0.431 < evl(4)=-0.429 ... using qval=4.0, revise to -0.4293

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.430819;   4.000000 electrons
         Sum occ. bands:   -2.744302, incl. Bloechl correction: -0.000157
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.692559    3.929843   -0.237285      1.801924    2.217530   -0.415607
       contr. to mm extrapolated for r>rmt:   0.159852 est. true mm = 1.961776

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958124   -1.039221    2.914621    2.914712    2.500000    2.914712
 spn 2 0    0.945317   -0.837839    2.908183    2.908288    2.500000    2.908288
 1     1    1.789106   -0.428289    2.850000    2.890533    2.250000    2.850000
 spn 2 1    0.000000   -1.074197    2.850000    2.172044    2.250000    2.850000
 2     0    0.000011   -0.814107    3.147584    3.132705    3.147584    3.147584
 spn 2 0    0.000000   -1.179997    3.147584    3.108348    3.147584    3.147584
 3     0    0.000001   -0.764121    4.102416    4.096119    4.102416    4.102416
 spn 2 0    0.000000   -1.130139    4.102416    4.085107    4.102416    4.102416

 Harris energy:
 sumev=       -2.744302  val*vef=     -14.361053   sumtv=      11.616751
 sumec=      -39.643187  cor*vef=    -102.575192   ttcor=      62.932005
 rhoeps=      -9.599248     utot=    -139.945008    ehar=     -74.995499

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -8.611627     -5.770353    -14.381979 sumev=   -2.744302   sumtv=   11.637678

 Kohn-Sham energy:
 sumtv=       11.637678  sumtc=        62.931909   ekin=       74.569587
 rhoep=       -9.599619   utot=      -139.966068   ehks=      -74.996101
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 1.  RMS DQ=7.65e-3  last it=1.35e-2
 mixrho: (warning) scr. and lin-mixed densities had 321 and 321 negative points
 AMIX: nmix=1 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=3.83e-3
   tj:-1.30773
 unscreened rms difference:  smooth  0.005864   local  0.020516
   screened rms difference:  smooth  0.005866   local  0.020516   tot  0.007652

 iors  : write restart file (binary, mesh density) 

   it  2  of 10    ehf=      -0.000599   ehk=      -0.001201
 From last iter    ehf=      -0.001089   ehk=      -0.001245
 diffe(q)=  0.000489 (0.007652)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0005993 ehk=-.0012006

 --- BNDFP:  begin iteration 3 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.102998   -0.365119     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.010114  avg sphere pot= 0.013347  vconst=-0.010114
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.748451   charge     4.365119
 smvxcm (warning) mesh density negative at 32479 points:  rhomin=-8.1e-6
 smooth rhoeps =   -3.350788 (  -2.645317,  -0.705471)
         rhomu =   -4.377842 (  -3.653696,  -0.724146)
       avg vxc =   -0.185828 (  -0.207023,  -0.164632)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.355866   -3.945068  -14.300935     -8.092405   -1.839028   -9.931433

 local terms:     true           smooth         local
 rhoeps:        -9.535850      -3.285318      -6.250532
 rhomu:         -7.421418      -3.583442      -3.837976
 spin2:         -5.126380      -0.710650      -4.415730
 total:        -12.547798      -4.294092      -8.253706
 val*vef       -14.300935      -8.833379      -5.467555
 val chg:        3.694222       4.059341      -0.365119
 val mom:        1.801637       2.306011      -0.504375    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000004

 potpus  spin 1 : pnu = 2.914712 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -1.036692   -1.269356   -1.156883    0.200112      2.8087    0.891644
 1     -0.468951   -1.051263   -0.466642    0.175003     19.0891    0.930511
 2     -0.617748   -0.617748    1.606518    0.368845     16.3489    6.928810
 3     -0.552482   -0.552482    3.520089    0.416914     23.4291   11.930130

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.927361    7.419642    0.092793   -0.587377
 1      3.000000    1.000000    -5.887832    7.125572    0.144121   -0.533190
 2      3.000000    1.000000     6.000000   29.626189    0.492364   -0.085963
 3      3.000000    1.000000     9.000000   40.179919    0.569677   -0.056296

 potpus  spin 2 : pnu = 2.908288 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -0.835134   -1.088404   -0.961587    0.212115      2.8186    0.930655
 1     -0.267517   -0.928316   -0.264892    0.186565     19.0604    0.985561
 2     -0.511150   -0.511150    1.743605    0.372419     16.2565    7.103218
 3     -0.453448   -0.453448    3.642614    0.418650     23.3692   12.064371

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.122534    7.329835    0.102510   -0.558956
 1      3.000000    1.000000    -5.887832    7.134634    0.153642   -0.499802
 2      3.000000    1.000000     6.000000   29.975211    0.494324   -0.084375
 3      3.000000    1.000000     9.000000   40.379530    0.570586   -0.055849

 Energy terms:             smooth           local           total
   rhoval*vef            -10.008516        -4.369504       -14.378019
   rhoval*ves             -4.532622        -5.725651       -10.258272
   psnuc*ves              12.029523      -281.711709      -269.682186
   utot                    3.748451      -143.718680      -139.970229
   rho*exc                -3.350788        -6.250532        -9.601320
   rho*vxc                -4.377842        -8.253706       -12.631548
   valence chg             4.365119        -0.365119         4.000000
   valence mag             2.504374        -0.504375         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.430819
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0386 -0.4267 -0.4267 -0.4267  0.1386  0.5319  0.5319  0.5319
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8370 -0.2357 -0.2357 -0.2357  0.2114  0.6269  0.6269  0.6269
 Est Ef = -0.431 < evl(4)=-0.427 ... using qval=4.0, revise to -0.4267

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.428302;   4.000000 electrons
         Sum occ. bands:   -2.734373, incl. Bloechl correction: -0.000167
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.689968    3.888659   -0.198691      1.799857    2.190769   -0.390912
       contr. to mm extrapolated for r>rmt:   0.161206 est. true mm = 1.961064

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958047   -1.036735    2.914712    2.914675    2.500000    2.914675
 spn 2 0    0.945055   -0.835268    2.908288    2.908179    2.500000    2.908179
 1     1    1.786854   -0.426205    2.850000    2.890071    2.250000    2.850000
 spn 2 1    0.000000   -1.088078    2.850000    2.169583    2.250000    2.850000
 2     0    0.000011   -0.811212    3.147584    3.132732    3.147584    3.147584
 spn 2 0    0.000000   -1.178399    3.147584    3.108370    3.147584    3.147584
 3     0    0.000001   -0.760613    4.102416    4.096142    4.102416    4.102416
 spn 2 0    0.000000   -1.129136    4.102416    4.085106    4.102416    4.102416

 Harris energy:
 sumev=       -2.734373  val*vef=     -14.378019   sumtv=      11.643647
 sumec=      -39.628278  cor*vef=    -102.560235   ttcor=      62.931957
 rhoeps=      -9.601320     utot=    -139.970229    ehar=     -74.995946

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.474761     -4.872707    -14.347469 sumev=   -2.734373   sumtv=   11.613096

 Kohn-Sham energy:
 sumtv=       11.613096  sumtc=        62.929095   ekin=       74.542191
 rhoep=       -9.595126   utot=      -139.943198   ehks=      -74.996133
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 2.  RMS DQ=1.55e-3  last it=7.65e-3
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=7.76e-4
   tj: 0.36626  -0.12094
 unscreened rms difference:  smooth  0.001229   local  0.004131
   screened rms difference:  smooth  0.001224   local  0.004131   tot  0.001553

 iors  : write restart file (binary, mesh density) 

   it  3  of 10    ehf=      -0.001046   ehk=      -0.001233
 From last iter    ehf=      -0.000599   ehk=      -0.001201
 diffe(q)= -0.000446 (0.001553)    tol= 0.000010 (0.000500)   more=T
i zbak=0 mmom=1.9999997 ehf=-.0010456 ehk=-.0012328

 --- BNDFP:  begin iteration 4 of 10 ---

 rhomom:   ib   ilm      qmom        Qval       Qc        Z
            1     1   -0.061861   -0.219290     2.00     6.00

 after vesgcomp: forces are:
   1    0.000000    0.000000    0.000000

 avg es pot at rmt= 0.009692  avg sphere pot= 0.013862  vconst=-0.009692
 average electrostatic potential at MT boundaries after shift
 Site    ves
   1   0.000000  |

 smooth rhoves      3.589396   charge     4.219290
 smvxcm (warning) mesh density negative at 30407 points:  rhomin=-6.52e-6
 smooth rhoeps =   -3.173429 (  -2.497574,  -0.675855)
         rhomu =   -4.145254 (  -3.448670,  -0.696584)
       avg vxc =   -0.186493 (  -0.208403,  -0.164584)

 locpot:

 site  1  z=  6.0  rmt= 3.00000  nr=369   a=0.020  nlml=16  rg=0.750  Vfloat=T

 ilm                   rho*vtrue                              rho*vsm
             spin1       spin2       tot           spin1       spin2       tot
   1     -10.348653   -3.944011  -14.292664     -7.582200   -1.751806   -9.334006

 local terms:     true           smooth         local
 rhoeps:        -9.533691      -3.107713      -6.425978
 rhomu:         -7.418880      -3.377948      -4.040933
 spin2:         -5.126068      -0.683122      -4.442946
 total:        -12.544948      -4.061070      -8.483878
 val*vef       -14.292664      -8.687194      -5.605470
 val chg:        3.693801       3.913092      -0.219290
 val mom:        1.801152       2.205057      -0.403906    core:   0.000000
 core chg:       2.000000       2.000000       0.000000
 potential shift to crystal energy zero:    0.000004

 potpus  spin 1 : pnu = 2.914675 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -1.037880   -1.270304   -1.157931    0.200027      2.8086    0.891388
 1     -0.470070   -1.051921   -0.467763    0.174922     19.0916    0.930051
 2     -0.618296   -0.618296    1.605912    0.368837     16.3492    6.928269
 3     -0.553021   -0.553021    3.519550    0.416913     23.4292   11.929953

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.922319    7.420681    0.092783   -0.587568
 1      3.000000    1.000000    -5.887832    7.124782    0.144054   -0.533469
 2      3.000000    1.000000     6.000000   29.625181    0.492362   -0.085967
 3      3.000000    1.000000     9.000000   40.179727    0.569678   -0.056296

 potpus  spin 2 : pnu = 2.908179 2.850000 3.147584 4.102416
 l        enu         v           c          srdel        qpar        ppar
 0     -0.836490   -1.089306   -0.962662    0.211981      2.8183    0.930344
 1     -0.268682   -0.928770   -0.266060    0.186447     19.0639    0.984896
 2     -0.511469   -0.511469    1.743098    0.372396     16.2571    7.102022
 3     -0.453724   -0.453724    3.642215    0.418641     23.3695   12.063577

 l,E        a      <phi phi>       a*D        a*Ddot      phi(a)      phip(a)
 0      3.000000    1.000000   -10.109818    7.332287    0.102530   -0.559176
 1      3.000000    1.000000    -5.887832    7.133516    0.153545   -0.500160
 2      3.000000    1.000000     6.000000   29.972883    0.494313   -0.084385
 3      3.000000    1.000000     9.000000   40.378391    0.570582   -0.055851

 Energy terms:             smooth           local           total
   rhoval*vef             -9.411530        -4.958659       -14.370189
   rhoval*ves             -4.619466        -5.633062       -10.252528
   psnuc*ves              11.798257      -281.462452      -269.664195
   utot                    3.589396      -143.547757      -139.958361
   rho*exc                -3.173429        -6.425978        -9.599407
   rho*vxc                -4.145254        -8.483878       -12.629132
   valence chg             4.219290        -0.219290         4.000000
   valence mag             2.403905        -0.403906         2.000000
   core charge             2.000000         0.000000         2.000000

 Charges:  valence     4.00000   cores     2.00000   nucleii    -6.00000
    hom background     0.00000   deviation from neutrality:      0.00000

 Read qp weights ...  ef=-0.428302
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -1.0397 -0.4278 -0.4278 -0.4278  0.1375  0.5311  0.5311  0.5311
 bndfp:  kpt 1 of 8, k=  0.00000  0.00000  0.00000
 -0.8382 -0.2368 -0.2368 -0.2368  0.2112  0.6265  0.6265  0.6265
 Est Ef = -0.428 < evl(4)=-0.428 ... using qval=4.0, revise to -0.4278

 BZWTS : --- Tetrahedron Integration ---
 BZINTS: Fermi energy:     -0.429408;   4.000000 electrons
         Sum occ. bands:   -2.738885, incl. Bloechl correction: -0.000167
         Mag. moment:       2.000000

 Saved qp weights ...

 mkrout:  Qtrue      sm,loc       local        true mm   smooth mm    local mm
   1    3.690357    3.893659   -0.203302      1.799977    2.187147   -0.387169
       contr. to mm extrapolated for r>rmt:   0.161113 est. true mm = 1.961090

 Symmetrize density..

 Make new boundary conditions for phi,phidot..

 site    1   species   1:C       
 l  idmod     ql         ebar        pold        ptry        pfree        pnew
 0     0    0.958102   -1.037855    2.914675    2.914697    2.500000    2.914697
 spn 2 0    0.945189   -0.836416    2.908179    2.908239    2.500000    2.908239
 1     1    1.787053   -0.427356    2.850000    2.890079    2.250000    2.850000
 spn 2 1    0.000000   -1.088466    2.850000    2.169603    2.250000    2.850000
 2     0    0.000011   -0.811769    3.147584    3.132731    3.147584    3.147584
 spn 2 0    0.000000   -1.178871    3.147584    3.108362    3.147584    3.147584
 3     0    0.000001   -0.761191    4.102416    4.096141    4.102416    4.102416
 spn 2 0    0.000000   -1.129568    4.102416    4.085102    4.102416    4.102416

 Harris energy:
 sumev=       -2.738885  val*vef=     -14.370189   sumtv=      11.631304
 sumec=      -39.634797  cor*vef=    -102.565323   ttcor=      62.930526
 rhoeps=      -9.599407     utot=    -139.958361    ehar=     -74.995938

 Harris correction to forces: screened shift in core+nuclear density  
  ib         delta-n dVes             delta-n dVxc               total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 shift forces to make zero average correction:            0.00    0.00    0.00

 srhov:     -9.356303     -5.003495    -14.359798 sumev=   -2.738885   sumtv=   11.620913

 Kohn-Sham energy:
 sumtv=       11.620913  sumtc=        62.930428   ekin=       74.551341
 rhoep=       -9.596303   utot=      -139.951163   ehks=      -74.996126
 mag. mom=     2.000000  (bands)        2.000000  (output rho)

Forces:
  ib           estatic                  eigval                    total
   1    0.00    0.00    0.00     0.00    0.00    0.00     0.00    0.00    0.00
 Maximum Harris force = 0 mRy/au (site 1)

 Symmetrize forces ...
  
 mixing: mode=A  nmix=2  beta=.5  elind=.241
 mixrho:  sought 2 iter from file mixm; read 3.  RMS DQ=1.85e-4  last it=1.55e-3
 AMIX: nmix=2 mmix=8  nelts=93876  beta=0.5  tm=5  rmsdel=9.24e-5
   tj: 0.33301   0.08122
 unscreened rms difference:  smooth  0.000128   local  0.000502
   screened rms difference:  smooth  0.000124   local  0.000502   tot  0.000185

 iors  : write restart file (binary, mesh density) 

   it  4  of 10    ehf=      -0.001038   ehk=      -0.001226
 From last iter    ehf=      -0.001046   ehk=      -0.001233
 diffe(q)=  0.000008 (0.000185)    tol= 0.000010 (0.000500)   more=F
c zbak=0 mmom=1.9999997 ehf=-.001038 ehk=-.0012261
 Exit 0 LMF 
 CPU time:  101.776s     Wed Feb 11 11:45:18 2009   on waldo.eas.asu.edu
 wkinfo:  used 14885 K  workspace of 80000 K   in  30 K calls
